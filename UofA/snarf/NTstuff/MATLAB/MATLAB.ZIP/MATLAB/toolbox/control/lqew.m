function [l,p,e] = lqew(a,g,c,j,q,r)
%LQEW	Linear quadratic estimator design for the continuous-time 
%       system with process noise feedthrough
%		.
%		x = Ax + Bu + Gw	    {State equation}
%		z = Cx + Du + Jw + v	    {Measurements}
%
%	and with process noise and measurement noise covariances:
%	    E{w} = E{v} = 0,  E{ww'} = Q,  E{vv'} = R,  E{wv'} = 0
%
%	L = LQEW(A,G,C,J,Q,R) returns the gain matrix L such that the 
%	stationary Kalman filter:      .
%                                      x = Ax + Bu + L(z - Cx - Du)
%
%	produces an LQG optimal estimate of x. The estimator can be formed
%	with ESTIM.
%
%	[L,P,E] = LQEW(A,G,C,J,Q,R) returns the gain matrix L, the Riccati
%	equation solution P which is the estimate error covariance, and 
%	the closed loop eigenvalues of the estimator: E = EIG(A-L*C).
%
%	See also: LQE, LQE2, and ESTIM.

%	Clay M. Thompson  7-23-90
%	Copyright (c) 1986-93 by the MathWorks, Inc.

error(nargchk(6,6,nargin));

rr = r + j*q*j';
nn = q*j';
[l,p,e] = lqe(a,g,c,q,rr,nn);

