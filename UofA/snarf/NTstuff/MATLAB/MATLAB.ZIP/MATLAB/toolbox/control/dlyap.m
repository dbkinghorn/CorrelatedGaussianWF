function x = dlyap(a,c)
%DLYAP	Discrete Lyapunov equation solution.
%	X = DLYAP(A,C) solves the discrete Lyapunov equation:
%
%		A*X*A' + C = X
%
%	See also LYAP.

%	J.N. Little 2-1-86
%	Copyright (c) 1986-93 by The MathWorks, Inc.

[m,n] = size(a);
a = (a+eye(m))\(a-eye(m));
c = (eye(m)-a)*c*(eye(m)-a')/2;
x = lyap(a,c);
