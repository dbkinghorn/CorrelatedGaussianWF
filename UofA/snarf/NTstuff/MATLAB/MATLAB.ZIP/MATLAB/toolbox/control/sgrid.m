function [] = sgrid(zeta,wn)
%SGRID	Generate s-plane grid lines for a root locus or pole-zero map.
%
%	SGRID generates a grid over an existing continuous s-plane root 
%	locus or pole-zero map.  Lines of constant damping ratio (zeta)
%	and natural frequency (Wn) are drawn in.
%	
%	SGRID('new') clears the graphics screen before plotting the 
%	s-plane grid so that the root locus or pole-zero map can be 
%	plotted over the grid using (for example):
%
%		sgrid('new')
%		hold on
%		rlocus(num,den) or pzmap(num,den)
%
%	SGRID(Z,Wn) plots constant damping and frequency lines for the 
%	damping ratios in the vector Z and the natural frequencies in the
%	vector Wn.
%
%	See also: RLOCUS, ZGRID and PZMAP.

%	Clay M. Thompson
%	Revised ACWG 6-21-92
%	Copyright (c) 1986-93 by the MathWorks, Inc.

error(nargchk(0,2,nargin));

status = ishold;

zx = 0:.01:1;

if nargin==0,	% Use existing axis limits
	limits = axis;
	axis('manual')
	hold on

	% Round-up axis limits
	
%	wmax = 10 * 10 .^(floor(log10(max(abs(limits)))));
	wmax = 10 .^(floor(log10(max(abs(limits)))));
	dx = wmax/10;
	wn= 0:dx:wmax;
	zeta = [ 0 .1 .2 .3 .4 .5 .6 .7 .8 .9 1 ];

elseif nargin==1,	% Standard scale
	hold off
	wn = 0:1:10;
	zeta = [ 0 .1 .2 .3 .4 .5 .6 .7 .8 .9 1 ];

else,
	hold on

end

if ~isempty(wn),  % Plot natural frequency lines
	[w,z] = meshgrid(wn,zx);
	re = - w .* z;
	[mcols, nrows] = size(z);
	im = w .* sqrt( ones(mcols, nrows) - z .* z );
%        ix=find(im>limits(4)); im(ix)=ones(length(ix),1)*limits(4);
	plot(re,im,'w:',re,-im,'w:');
	hold on
end

if ~isempty(zeta), % Plot damping lines
	limits = axis;
	[w,z] = meshgrid([0;wn(:);2*max(limits(:))]',zeta);
	re = -w .* z;
	[mcols, nrows] = size(z);
	im = w .* sqrt( ones(mcols, nrows) - z .* z );
%        ix=find(im>limits(4)); im(ix)=ones(length(ix),1)*limits(4);
	plot(re',im','w:',re',-im','w:');
end

if (nargin~=1)&(~status), hold off, end	   % Return hold to previous status

% uncomment the following lines if you want damping ratio lines labeled.

% Now put wn labels on the curve
%n = length(wn);
%m = length(zeta);
%for i = 1:m
%  text(re(i,n),im(i,n),sprintf('%.3g',zeta(m-i+1)))
%end




