function [a,b,c,d] = parallel(a1,b1,c1,d1,a2,b2,c2,d2,e,f,g,h)
%PARALLEL  Parallel connection of two systems.  
%                +-->[System1]--+
%            u-->+              O--->y
%                +-->[System2]--+
%	[A,B,C,D] = PARALLEL(A1,B1,C1,D1,A2,B2,C2,D2)  produces a state-
%	space system consisting of the parallel connection of systems 1 
%	and 2 that connects all the inputs together and sums all the 
%	outputs of the two systems,  Y = Y1 + Y2.
%
%	[A,B,C,D] = PARALLEL(A1,B1,C1,D1,A2,B2,C2,D2,IN1,IN2,OUT1,OUT2) 
%	connects the two systems in parallel such that the inputs 
%	specified by IN1 and IN2 are connected and the outputs specified
%	by OUT1 and OUT2 are summed. The vectors IN1 and IN2 contain 
%	indexes into the input vectors of system 1 and system 2, 
%	respectively.  Similarly, the vectors OUT1 and OUT2 contain 
%	indexes into the outputs of the systems.  The parallel connection
%	is performed by appending the two systems, summing the specified
%	inputs and outputs, and removing the, now redundant, inputs and 
%	outputs of system 2.
%
%	[NUM,DEN] = PARALLEL(NUM1,DEN1,NUM2,DEN2) produces a parallel 
%	connection of the two transfer function systems.
%	See also: CLOOP, FEEDBACK, and SERIES. 

%	Clay M. Thompson 6-27-90
%	Copyright (c) 1986-93 by the MathWorks, Inc.

error(nargchk(4,12,nargin));

% --- Determine which syntax is being used ---
if (nargin == 4)  % Form Parallel connection of T.F. system ---
  [num1,den1] = tfchk(a1,b1); [num2,den2] = tfchk(c1,d1);
  [nn,mn] = size(num1);
  for k=1:nn
    a(k,:) = conv(num1(k,:),den2) + conv(num2(k,:),den1);
    b = conv(den1,den2);
  end

elseif ((nargin>=5) & (nargin<=7)) | ((nargin>=9) & (nargin<=11))
  error('Wrong number of input arguments.');

elseif (nargin==8) | (nargin==12)  % State space systems 
  error(abcdchk(a1,b1,c1,d1));
  error(abcdchk(a2,b2,c2,d2));
  [ny1,nu1] = size(d1);
  [ny2,nu2] = size(d2);
  if (nargin == 8) % State space systems w/o selection vectors
    inputs1 = [1:nu1];     outputs1 = [1:ny1];
    inputs2 = [1:nu2]+nu1; outputs2 = [1:ny2]+ny1; 
  end
  if (nargin == 12) % State space systems with selection vectors
    inputs1 = e;      outputs1 = g;
    inputs2 = f+nu1;  outputs2 = h+ny1;
  end
  
  % Check sizes
  if (length(inputs1)~=length(inputs2))
     error('Input sizes don''t match.'); end
  if (length(outputs1)~=length(outputs2))
     error('Output size don''t match.'); end

  % --- Parallel Connection ---
  [a,b,c,d] = append(a1,b1,c1,d1,a2,b2,c2,d2);

  % Connect inputs
  if ~isempty(b), b(:,inputs1)=b(:,inputs1)+b(:,inputs2); end
  if ~isempty(d), d(:,inputs1)=d(:,inputs1)+d(:,inputs2); end
 
  % Connect outputs
  if ~isempty(c), c(outputs1,:)=c(outputs1,:)+c(outputs2,:); end
  if ~isempty(d), d(outputs1,:)=d(outputs1,:)+d(outputs2,:); end

  [a,b,c,d] = ssdelete(a,b,c,d,inputs2,outputs2);

end
