function [sv] = sigma2(Z1,Z2,Z3,Z4,Z5,Z6)
%
% Singular Value Frequency Response.
%
% SV = SIGMA2(A, B, C, D, TYPE, W) (or optional SV = SIGMA2(SS_,TYPE,W)
% in RCT) produces the matrix SV containing singular values of the 
% square system : 
%                .
%                x = Ax + Bu
%                y = Cx + Du
%                                               -1
% with the frequency response G(jw) = C(jwI - A)  B + D
%
% SIGMA calculates the SVD of one of the following types:
%
%     Type = 1   ----   G(jw) 
%     Type = 2   ----   inv(G(jw))
%     Type = 3   ----   I + G(jw)
%     Type = 4   ----   I + inv(G(jw)) 
%
% Vector W contains the frequencies at which the frequency response
% is to be evaluated. The SV matrix has rows which correspond to the 
% singular values in descending order.
%
% See also SIGMA for an alternate syntax.

% R. Y. Chiang & M. G. Safonov 5/16/85 & 10/25/90
% Revised by W. Wang 7/24/92
% Copyright (c) 1986-93 by the MathWorks, Inc.
% All Rights Reserved.
% -------------------------------------------------------------------
%

if exist('mkargs') == 2, %If RCT installed
  cmd = [];
  inargs='(a,b,c,d,Type,w)';
  eval('cmd=mkargs(inargs,nargin,''ss'');')
  eval(cmd)
else
   if nargin<4,
     error('Too few input arguments')
   else
    a=Z1; b=Z2; c=Z3; d=Z4;
    if nargin > 5
      w = Z6;
    elseif nargin > 4,
      Type=Z5;
    end;
   end;
end;

disp('  ')
disp('          ..... Working ...... please wait .....')
[mg] = freqrc(a,b,c,d,w);
[rmg,cmg] = size(mg);
[rb,cb] = size(b);
[rc,cc] = size(c);
gg = ones(rc,cb);
for is = 1 : cmg
  gg(:) = mg(:,is);
  if (Type == 1)
    sv(:,is) = svd(gg);
  end
  if (Type == 2)
    sv(:,is) = svd(inv(gg));
  end
  if (Type == 3)
    sv(:,is) = svd(eye(cb) + gg);
  end
  if (Type == 4)
    sv(:,is) = svd(eye(cb) + inv(gg));
  end
end
%
% ----- End of SIGMA.M ---- RYC/MGS 5/16/85 %
