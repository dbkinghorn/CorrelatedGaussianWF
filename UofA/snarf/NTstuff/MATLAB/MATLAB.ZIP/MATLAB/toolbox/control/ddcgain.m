function k = ddcgain(a,b,c,d)
%DDCGAIN D.C. gain of discrete system.
%	K = DDCGAIN(A,B,C,D) computes the steady state (D.C. or low 
%	frequency) gain of the discrete state-space system (A,B,C,D).
%
%	K = DDCGAIN(NUM,DEN) computes the steady state gain of the 
%	discrete polynomial transfer function system G(z) = NUM(z)/DEN(z)
%	where NUM and DEN contain the polynomial coefficients in 
%	descending powers of z.
%
%	See also: DCGAIN.

%	Clay M. Thompson  7-6-90
%	Copyright (c) 1986-93 by the MathWorks, Inc.

error(nargchk(2,4,nargin));

if (nargin==2), % Transfer function description
  [num,den] = tfchk(a,b);
  if (length(num) & length(den))
    k = sum(num')'/sum(den);
  else
    k = [];
  end

elseif nargin==4, % State space description
  error(abcdchk(a,b,c,d));
  [nx,na] = size(a);
  if any(abs(eig(a)-1)<eps), % System is singular.
    % Use LU decomposition to solve system.  Put a very small number in place
    % of the singularity.  Set to INF if necessary after calculation.
    [l,u] = lu(eye(nx)-a);
    ndx = find(abs(diag(u))<eps);
    if length(ndx)>0, u(ndx,ndx) = 1.e-300; end % A very small number.
    k = c*(u\(l\b)) + d;
    out = find(abs(k)>1.e+200);
    if length(out)>0, k(out) = inf*sign(k(out)); end
  else
    k = c/(eye(nx)-a)*b + d;
  end

else
  error('Wrong number of input arguments.');
end
