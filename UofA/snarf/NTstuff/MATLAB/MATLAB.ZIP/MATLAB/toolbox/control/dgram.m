function g = dgram(a,b)
%DGRAM	Discrete controllability and observability gramians.
%	DGRAM(A,B) returns the discrete controllability gramian.
%	DGRAM(A',C') returns the observability gramian.
%	See also GRAM.

%	J.N. Little 9-6-86
%	Copyright (c) 1986-93 by the MathWorks, Inc.

%	Kailath, T. "Linear Systems", Prentice-Hall, 1980.
%	Laub, A., "Computation of Balancing Transformations", Proc. JACC
%	  Vol.1, paper FA8-E, 1980.

[u,s,v] = svd(b);
g = u*dlyap(u'*a*u,s*s')*u';
