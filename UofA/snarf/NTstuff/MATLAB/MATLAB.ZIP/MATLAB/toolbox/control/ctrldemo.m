echo on
clc
echo off
%	Copyright (c) 1986-93 by the MathWorks, Inc.
echo on
%	This demo shows the use of some of the control system design
%	and analysis tools available in MATLAB.
%
pause % Strike any key to continue.
clc
%	Suppose we start with a plant description in transfer function
%	form:                 2
%	                  .2 s  +  .3 s  +  1
%	       H(s)  =   -----------------------
%	                  2
%	                (s  +  .4 s  +  1) (s + .5)
%
%	We enter the numerator and denominator coefficients separately
%	into MATLAB:

num = [.2  .3  1];
den1 = [1 .4 1];
den2 = [1 .5];

pause % Strike any key to continue.
clc
%	The denominator polynomial is the product of the two terms. We
%	use convolution to obtain the polynomial product:

den = conv(den1,den2)
printsys(num,den)

pause % Strike any key to continue.
clc
%	We can look at the natural frequencies and damping factors of the
%	plant poles:

damp(den)

%	A root-locus can be obtained by using RLOCUS

% Press any key to continue ...

rlocus(num,den); pause  % Press any key after plot ...

clc
%	The plant may be converted to a state space representation
%	      .
%	      x = Ax + Bu
%	      y = Cx + Du
%
%	using the tf2ss command:

[a,b,c,d] = tf2ss(num,den)
pause % Strike any key to continue.
clc
%	For systems described in state-space or by transfer functions,
%	the step response is found by using the STEP command:
step(a,b,c,d,1); title('Step response'), pause % Press any key after plot

clc
%	The frequency response is found by using the BODE command:

bode(a,b,c,d,1); pause % Press any key after plot
clc
%	A linear quadratic regulator could be designed for this plant.
%	For control and state penalties:

r = 1;
[m,n] = size(a); 
q = eye(m,n)
%	the quadratic optimal gains, the associated Riccati solution,
%	and the closed-loop eigenvalues are:

[k,s,e] = lqr(a,b,q,r)                  % Working, please wait...
pause % Strike any key to end.

echo off
