function [] = zgrid(zeta,wn,s)
%ZGRID	Generate z-plane grid lines for a root locus or pole-zero map.
%
%	ZGRID generates a grid over an existing discrete z-plane root 
%	locus or pole-zero map.  Lines of constant damping factor (zeta)
%	and natural frequency (Wn) are drawn in within the unit Z-plane 
%	circle.
%
%	ZGRID('new') clears the graphics screen before plotting the 
%	z-plane grid and sets the HOLD ON so that the root locus or pole-
%	zero map can be plotted over the grid using (for example):
%
%		zgrid('new')
%		rlocus(num,den) or pzmap(num,den)
%
%	ZGRID(Z,Wn) plots constant damping and frequency lines for the 
%	damping ratios in the vector Z and the natural frequencies in the
%	vector Wn.  ZGRID(Z,Wn,'new') clears the screen first.
%
%	See also: RLOCUS, SGRID, and PZMAP.

%	Marc Ullman   May 27, 1987
%	Revised JNL 7-10-87, CMT 7-13-90, ACWG 6-21-92
%	Copyright (c) 1986-93 by the MathWorks, Inc.

error(nargchk(0,3,nargin));

status = ishold;

if nargin==0,	% Plot on existing graph
	zeta = 0:.1:.9;
	wn = 0:pi/10:pi;
	axis(axis)
	hold on

elseif nargin==1, % Clear screen then plot standard grid
	zeta = 0:.1:.9;
	wn = 0:pi/10:pi;
	hold off

elseif nargin==2, % Use zeta and wn specified
	hold on

elseif nargin==3, % Clear screen and use zeta and wn specified
	hold off

end

% Plot Unit circle
t=0:.1:6.3;
plot(sin(t),cos(t),'w-')
hold on

% Plot damping lines
if ~isempty(zeta),
	m = tan(asin(zeta));
	zz = exp((0:pi/20:pi)'*(-m + sqrt(-1)*ones(1,length(m))));
	plot(real(zz),imag(zz),'w:',real(zz),-imag(zz),'w:');
	hold on
end

% Plot natural frequency lines
if ~isempty(wn),
	e_itheta = exp(sqrt(-1)*(pi/2:pi/20:pi)');
	e_r = exp(wn);
	zw = (ones(length(e_itheta), 1)*e_r).^(e_itheta*ones(1,length(e_r)));
	plot(real(zw),imag(zw),'w:',real(zw),-imag(zw),'w:');
end

% Return hold to previous status
if ((nargin==0)|(nargin==2))&(~status), hold off, end

