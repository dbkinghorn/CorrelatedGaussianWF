function [k,s,e] = lqry(a,b,c,d,q,r)
%LQRY	Linear quadratic regulator design with output weighting
%	for continuous-time systems.
%
%	[K,S,E] = LQRY(A,B,C,D,Q,R) calculates the optimal feedback
%	gain matrix K such that the feedback law  u = -Kx  minimizes
%	the cost function:
%
%	   J = Integral {y'Qy + u'Ru} dt
%
%	subject to the constraint equation: 
%	   .
%	   x = Ax + Bu,  y = Cx + Du
%                
%	Also returned is S, the steady-state solution to the associated 
%	algebraic Riccati equation and the closed loop eigenvalues
%	E = EIG(A-B*K).
%
%	The controller can be formed using REG.
%
%	See also: LQR, LQR2 and REG.

%	J.N. Little 7-11-88
%	Revised: 7-18-90 Clay M. Thompson
%	Copyright (c) 1986-93 by the MathWorks, Inc.

error(nargchk(6,6,nargin));
qq = c'*q*c;
rr = r + d'*q*d;
nn = c'*q*d;
[k,s,e] = lqr(a,b,qq,rr,nn);
