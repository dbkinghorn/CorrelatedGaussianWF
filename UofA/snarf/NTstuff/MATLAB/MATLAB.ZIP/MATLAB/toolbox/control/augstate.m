function [ab,bb,cb,db] = augstate(a,b,c,d)
%AUGSTATE Augment states to the outputs of a state space system.
% 	[Ab,Bb,Cb,Db] = AUGSTATE(A,B,C,D) appends the states to the
%	outputs of the system (A,B,C,D).  The resulting system is:
%	         .
%	         x = Ax + Bu
%
%	        |y| = |C| x + |D| u
%	        |x|   |I|     |0|
%
%	This command prepares the plant so that the FEEDBACK command can
%	be used to form the closed loop system with a full state feedback
%	gain matrix.
%
%	See also: PARALLEL,SERIES,FEEDBACK, and CLOOP

%	Clay M. Thompson 6-26-90
%	Copyright (c) 1986-93 by the MathWorks, Inc.

error(nargchk(4,4,nargin));
error(abcdchk(a,b,c,d));

[na,ma] = size(a);
[n,m] = size(b);
ab = a; bb = b;
cb = [c;eye(na)];
db = [d;zeros(na,m)];
