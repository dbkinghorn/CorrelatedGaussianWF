function [l,m,p,e] = dlqew(a,g,c,j,q,r)
%DLQEW	Discrete linear quadratic estimator design for the system:
%		x[n+1] = Ax[n] + Bu[n] + Gw[n]	          {State equation}
%		z[n]   = Cx[n] + Du[n] + Jw[n] + v[n]     {Measurements}
%	with process noise and measurement noise covariances:
%		E{w} = E{v} = 0,  E{ww'} = Q,  E{vv'} = R,  E{wv'} = 0
%
%	L = DLQEW(A,G,C,J,Q,R) returns the gain matrix L such that the 
%	discrete, stationary Kalman filter with time and observation 
%	update equations:
%	   _         *               *      _                _
%	   x[n+1] = Ax[n] + Bu[n]    x[n] = x[n] + L(z[n] - Cx[n] - Du[n])
%	produces an LQG optimal estimate of x.  The estimator can be
%	formed using DESTIM.
%
%	[L,M,P,E] = DLQEW(A,G,C,J,Q,R) returns the gain matrix L, the
%	Riccati equation solution M, the estimate error covariance after
%	the measurement update:          *    *
%                                 P = E{[x-x][x-x]'}
%	and the closed-loop eigenvalues of the estimator, E=EIG(A-A*L*C).
%
%	See also: DLQE, LQED and DESTIM.

%	Clay M. Thompson  7-23-90
%	Copyright (c) 1986-93 by the MathWorks, Inc.

error(nargchk(6,6,nargin));

rr = r + j*q*j';
nn = q*j';
[l,m,p,e] = dlqe(a,g,c,q,rr,nn);
