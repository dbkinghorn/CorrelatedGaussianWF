% README file for the Control System Toolbox
% 26 August 1992
% 
% New Control System Toolbox M-Files.
%
% Here are some M-files that are NOT described in the user's guide
% because they were added after printing:
%
%   stepfun - Step function.
%
% Use HELP on these files or TYPE them for more information.