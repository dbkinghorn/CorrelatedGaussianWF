function [sv] = dsigma2(Z1,Z2,Z3,Z4,Z5,Z6,Z7)
%function [sv] = dsigma2(a,b,c,d,Type,w,Ts)
%
% Discrete Singular Value Frequency Response.
%
% SV = DSIGMA2(A,B,C,D,TYPE,W,Ts) (or optional 
% SV = DSIGMA2(SS_,TYPE,W,Ts) in RCT) produces the matrix SV
% containing the singular values of the square system 
%
%			x[n+1] = Ax[n] + Bu[n]		          
%			y[n]   = Cx[n] + Du[n]
%                                          -1
%     with frequency response G(z) = C(zI-A) B + D.
%
% DSIGMA2 calculates the SVD of one of the following depending on the 
% value of TYPE : 
%
%     Type = 1   ----   G(z)  
%     Type = 2   ----   inv(G(z))
%     Type = 3   ----   I + G(z)
%     Type = 4   ----   I + inv(G(z)) 
%
% Vector W contains the frequencies at which the frequency response
% is to be evaluated. The SV matrix has rows which correspond to the 
% singular values in descending order.
%
% See also DSIGMA for an alternate syntax.

% R. Y. Chiang & M. G. Safonov 6/23/87
% Revised W. Wang 7/24/92
% Copyright (c) 1986-93 by the MathWorks, Inc.
% All Rights Reserved.
% ------------------------------------------------------------------------
%

if exist('mkargs') == 2, %If RCT installed
  cmd=[];
  inargs = '(a,b,c,d,Type,w,Ts)';
  eval('cmd=mkargs(inargs,nargin,''ss'');')
  eval(cmd)
else                       % If RCT not installed
  % assign a=Z1;...,Type=Z5;w=Z6;Ts=Z7;
  if nargin<4,
    error('Too few input arguments')
  else
    a=Z1; b=Z2; c=Z3; d=Z4;
    if nargin>6,
      Ts=Z7;
    elseif nargin>5,
      w=Z6;
    elseif nargin>4,
      Type=Z5;
    end
  end
end;

disp('  ')
disp('          ..... Working ...... please wait .....')
[mg] = dfreqrc(a,b,c,d,w,Ts);
[rmg,cmg] = size(mg);
[rb,cb] = size(b);
[rc,cc] = size(c);
gg = ones(rc,cb);
for is = 1 : cmg
  gg(:) = mg(:,is);
  if (Type == 1)
    sv(:,is) = svd(gg);
  end
  if (Type == 2)
    sv(:,is) = svd(inv(gg));
  end
  if (Type == 3)
    sv(:,is) = svd(eye(cb) + gg);
  end
  if (Type == 4)
    sv(:,is) = svd(eye(cb) + inv(gg));
  end
end
%
% ----- End of DSIGMA.M ---- RYC/MGS 6/23/87 %
