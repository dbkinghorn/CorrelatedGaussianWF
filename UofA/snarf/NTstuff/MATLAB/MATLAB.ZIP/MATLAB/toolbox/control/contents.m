% Control System Toolbox.
% Version 3.0b   3-Mar-93
% Copyright (c) 1986-93 by The MathWorks, Inc.
%   
% Model building.
%   append     - Append system dynamics.
%   augstate   - Augment states as outputs.
%   blkbuild   - Build state-space system from block diagram.
%   cloop      - Close loops of system.
%   connect    - Block diagram modeling.
%   conv       - Convolution of two polynomials.
%   destim     - Form discrete state estimator from gain matrix.
%   dreg       - Form discrete controller/estimator from gain matrices.
%   drmodel    - Generate random discrete model.
%   estim      - Form continuous state estimator from gain matrix.
%   feedback   - Feedback system connection.
%   ord2       - Generate A,B,C,D for a second-order system.
%   pade       - Pade approximation to time delay.
%   parallel   - Parallel system connection.
%   reg        - Form continuous controller/estimator from gain matrices.
%   rmodel     - Generate random continuous model.
%   series     - Series system connection.
%   ssdelete   - Delete inputs, outputs, or states from model.
%   ssselect   - Select subsystem from larger system.
%   
% Model conversions.
%   c2d        - Continuous to discrete-time conversion.
%   c2dm       - Continuous to discrete-time conversion with method.
%   c2dt       - Continuous to discrete conversion with delay.
%   d2c        - Discrete to continuous-time conversion.
%   d2cm       - Discrete to continuous-time conversion with method.
%   poly       - Roots to polynomial conversion.
%   residue    - Partial fraction expansion.
%   ss2tf      - State-space to transfer function conversion.
%   ss2zp      - State-space to zero-pole conversion.
%   tf2ss      - Transfer function to state-space conversion.
%   tf2zp      - Transfer function to zero-pole conversion.
%   zp2tf      - Zero-pole to transfer function conversion.
%   zp2ss      - Zero-pole to state-space conversion.
%   
% Model reduction.
%   balreal    - Balanced realization.
%   dbalreal   - Discrete balanced realization.
%   dmodred    - Discrete model order reduction.
%   minreal    - Minimal realization and pole-zero cancellation.
%   modred     - Model order reduction.
%   
% Model realizations.
%   canon      - Canonical form.
%   ctrbf      - Controllability staircase form.
%   obsvf      - Observability staircase form.
%   ss2ss      - Apply similarity transform.
%   
% Model properties.
%   covar      - Continuous covariance response to white noise.
%   ctrb       - Controllability matrix.
%   damp       - Damping factors and natural frequencies.
%   dcgain     - Continuous steady state (D.C.) gain.
%   dcovar     - Discrete covariance response to white noise.
%   ddamp      - Discrete damping factors and natural frequencies.
%   ddcgain    - Discrete steady state (D.C.) gain.
%   dgram      - Discrete controllability and observability gramians.
%   dsort      - Sort discrete eigenvalues by magnitude.
%   eig        - Eigenvalues and eigenvectors.
%   esort      - Sort continuous eigenvalues by real part.
%   gram       - Controllability and observability gramians.
%   obsv       - Observability matrix.
%   printsys   - Display system in formatted form.
%   roots      - Polynomial roots.
%   tzero      - Transmission zeros.
%   tzero2     - Transmission zeros using random perturbation method.
%   
% Time response.
%   dimpulse   - Discrete unit sample response.
%   dinitial   - Discrete initial condition response.
%   dlsim      - Discrete simulation to arbitrary inputs.
%   dstep      - Discrete step response.
%   filter     - SISO z-transform simulation.
%   impulse    - Impulse response.
%   initial    - Continuous initial condition response.
%   lsim       - Continuous simulation to arbitrary inputs.
%   ltitr      - Low level time response function.
%   step       - Step response.
%   stepfun    - Step function.
%   
% Frequency response.
%   bode       - Bode plot (frequency response).
%   dbode      - Discrete Bode plot (frequency response).
%   dnichols   - Discrete Nichols plot.
%   dnyquist   - Discrete Nyquist plot.
%   dsigma     - Discrete singular value frequency plot.
%   fbode      - Fast Bode plot for continuous systems.
%   freqs      - Laplace-transform frequency response.
%   freqz      - Z-transform frequency response.
%   ltifr      - Low level frequency response function.
%   margin     - Gain and phase margins.
%   nichols    - Nichols plot.
%   ngrid      - Draw grid lines for Nichols plot.
%   nyquist    - Nyquist plot.
%   sigma      - Singular value frequency plot.
%   
% Root locus.
%   pzmap      - Pole-zero map.
%   rlocfind   - Interactive root locus gain determination.
%   rlocus     - Evans root-locus.
%   sgrid      - Draw continuous root locus wn,z grid.
%   zgrid      - Draw discrete root locus wn,z grid.
%   
% Gain selection.
%   acker      - SISO pole placement.
%   dlqe       - Discrete linear-quadratic estimator design.
%   dlqew      - General discrete linear quadratic estimator design.
%   dlqr       - Discrete linear-quadratic regulator design.
%   dlqry      - Discrete regulator design with weighting on outputs.
%   lqe        - Linear-quadratic estimator design.
%   lqed       - Discrete estimator design from continuous cost function.
%   lqe2       - Linear quadratic estimator design using Schur method.
%   lqew       - General linear-quadratic estimator design.
%   lqr        - Linear-quadratic regulator design.
%   lqrd       - Discrete regulator design from continuous cost function.
%   lqry       - Regulator design with weighting on outputs.
%   lqr2       - Linear quadratic regulator design using Schur method.
%   place      - Pole placement.
%   
% Equation solution.
%   are        - Algebraic Riccati equation solution.
%   dlyap      - Discrete Lyapunov equation solution.
%   lyap       - Continuous Lyapunov equation solution.
%   lyap2      - Lyapunov equation solution using diagonalization.
%
% Demonstrations.
%   ctrldemo   - Introduction to the Control Toolbox.
%   boildemo   - LQG design of boiler system.
%   jetdemo    - Classical design of jet transport yaw damper.
%   diskdemo   - Digital control design of hard disk controller.
%   kalmdemo   - Kalman filter design and simulation.

% Utilities.
%   abcdchk    - Check consistency of (A,B,C,D) set.
%   chop       - Round to n significant places.
%   dexresp    - Discrete example response function.
%   dfrqint    - Auto-ranging algorithm for discrete Bode response.
%   dfrqint2   - Auto-ranging algorithm for discrete Nyquist response.
%   dmulresp   - Discrete multivariable response function.
%   distsl     - Distance to straight line.
%   dric       - Discrete Riccati equation residual calculation.
%   dsigma2    - DSIGMA utility function.
%   dtimvec    - Auto-ranging algorithm for discrete-time response.
%   exresp     - Example response function.
%   freqint    - Auto-ranging algorithm for Bode frequency response.
%   freqint2   - Auto-ranging algorithm for Nyquist frequency response.
%   freqresp   - Low level frequency response function.
%   givens     - Givens rotation.
%   housh      - Construct Householder transformation .
%   imargin    - Gain and phase margin by interpolation.
%   lab2str    - Convert label to string.
%   mulresp    - Multivariable response function.
%   nargchk    - Check number of M-file arguments.
%   perpxy     - Find nearest perpendicular point.
%   poly2str   - Convert polynomial to string.
%   printmat   - Print matrix with row and column labels.
%   ric        - Riccati equation residual calculation.
%   schord     - Ordered schur decomposition .
%   sigma2     - SIGMA utility function.
%   tfchk      - Check consistency of transfer functions.
%   timvec     - Auto-ranging algorithm for continuous-time response.
%   tzreduce   - Reduce system when computing transmission zeros.
%   vsort      - Match two vectors for rlocus.
