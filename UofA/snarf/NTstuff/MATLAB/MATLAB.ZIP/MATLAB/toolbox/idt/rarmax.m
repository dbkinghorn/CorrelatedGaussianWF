function [thm,p,phi,psi] = rarmax(z,nn,adm,adg,th0,p0,phi,psi)
%RARMAX	Computes estimates recursively for an ARMAX model using the
%	Recursive Prediction Error Method
%
%	THM = rarmax(Z,NN,adm,adg)
%
%	Z: The output-input data z=[y u] (single input only!)
%	NN : NN=[na nb nc nk], The orders and delay of an ARMAX
%	     input-output model (see HELP ARMAX)
%	adm: Adaptation mechanism. adg: Adaptation gain
%	 adm='ff', adg=lam:  Forgetting factor algorithm, with forg factor lam
%	 adm='kf', adg=R1: The Kalman filter algorithm with R1 as covariance 
%		matrix of the parameter changes per time step
%	 adm='ng', adg=gam: A normalized gradient algorithm, with gain gam
%	 adm='ug', adg=gam: An Unnormalized gradient algorithm with gain gam
%	THM: The resulting estimates. Row k contains the estimates "in alpha-
%	     betic order" corresponding to data up to time k (row k in Z)
%
%	Initial value of parameters(TH0) and of "P-matrix" (P0) can be given by
%	[THM,P] = rarmax(Z,NN,adm,adg,TH0,P0)
%	Initial and last values of auxiliary data vectors phi and psi are 
%	obtained by [THM,P,phi,psi]=rarmax(Z,NN,adm,adg,TH0,P0,phi0,psi0). 
%	
%	See also RARX, ROE, RBJ, RPEM and RPLR.

%	L. Ljung 10-1-89
%	Copyright (c) 1989 by the MathWorks, Inc.
%	All Rights Reserved.


na=nn(1);nb=nn(2);nc=nn(3);nk=nn(4);nu=1;
if nk<1,error('Sorry, this routine requires nk>0; Shift input sequence if necessary!'),end
d=sum(nn(1:3));
[nz,ns]=size(z);
if ns>2,error('Sorry, this routine is for single input only!'),end

nam=max([na,nc]);nbm=max([nb+nk-1,nc]);
tic=na+nb+1:na+nb+nc;
ia=1:na;iac=1:nc;
ib=nam+nk:nam+nb+nk-1;ibc=nam+1:nam+nc;
ic=nam+nbm+1:nam+nbm+nc;

iia=1:nam-1;iib=nam+1:nam+nbm-1;iic=nam+nbm+1:nam+nbm+nc-1;
dm=nam+nbm+nc;
ii=[iia iib iic];i=[ia ib ic];

if nargin<8, psi=zeros(dm,1);end
if nargin<7, phi=zeros(dm,1);end
if nargin<6, p0=10000*eye(d);end
if nargin<5, th0=eps*ones(d,1);end
p=p0;th=th0;
if adm(1)=='f', R1=zeros(d,d);lam=adg;end
if adm(1)=='k', [sR1,SR1]=size(adg);
     if sR1~=d | SR1~=d,error('The R1 matrix should be a square matrix with dimension equal to number of parameters!'),end
     R1=adg;lam=1;
end
if adm(2)=='g', grad=1;else grad=0;end

for k=1:nz

epsi=z(k,1)-phi(i)'*th;
if ~grad,K=p*psi(i)/(lam + psi(i)'*p*psi(i));
         p=(p-K*psi(i)'*p)/lam+R1;
else K=adg*psi(i);end
if adm(1)=='n', K=K/(eps+psi(i)'*psi(i));end
th=th+K*epsi;
c=fstab([1;th(tic)])';
th(tic)=c(2:nc+1);
epsilon=z(k,1)-phi(i)'*th;

ztil=[[z(k,1),psi(iac)'];[z(k,2),-psi(ibc)'];[epsilon,-psi(ic)']]*c;

phi(ii+1)=phi(ii);psi(ii+1)=psi(ii);
if na>0,phi(1)=-z(k,1);psi(1)=-ztil(1);end
if nb>0,phi(nam+1)=z(k,2);psi(nam+1)=ztil(2);end 
if nc>0,phi(nam+nbm+1)=epsilon;psi(nam+nbm+1)=ztil(3);end

thm(k,:)=th';
end
