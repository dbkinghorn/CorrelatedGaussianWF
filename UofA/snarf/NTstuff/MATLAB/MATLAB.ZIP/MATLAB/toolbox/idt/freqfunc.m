function freqfunc
%FREQFUNC Frequency functions are created by SPA, ETFE, TRF, TRFSD and TRFCONT
%	They are used by BODEPLOT.
%
%	The format of a frequency function associated with one transfer
%	function or a noise spectrum is as follows. It has between two and
%	five columns, and the number of rows equals the number of frequences
%	plus one. The first row contains integers n with input information:
%
%	n = 0: means that the column is a spectrum
%	n = 20: The column contains the standard deviation of the spectrum
%	n =100: The column contains the frequencies for the spectrum.
%	n = k (with k between 1 and 19): the column contains amplitude
%	      values for the transfer function corresponding to input k.
%	n = 20 + k: the column contains phase values for input number k.
%	n = 50 + k: the column contains amplitude standard deviation, input k.
%	n = 70 + k: the column contains phase standard deviation, input k.
%	n = 100+ k: the column contains the frequency values for input k.
%
%	For each input (spectrum) the columns are ordered as follows:
%	Frequencies, amplitude, amplitude s.d., phase, phase s.d.
%
