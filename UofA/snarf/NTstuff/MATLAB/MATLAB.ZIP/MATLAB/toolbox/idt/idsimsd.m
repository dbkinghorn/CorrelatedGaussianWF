function idsimsd(u,th,n,noise)
%IDSIMSD Illustrates the uncertainty in simulated model responses
%
%	idsimsd(U,TH)
%
%	U is a column vector (matrix) containing the input(s).
%	TH is a model given in the THETA format (See HELP THETA).
%	10 random models are created, consistent with the covariance informa-
%	tion in TH, and the responses of each of these models to U are plotted
%	in the same diagram.
%	
%	The number 10 can be changed to N by idsimsd(U,TH,N).
%
%	With idsimsd(U,TH,N,'noise'), additive noise (e) is added to the simu-
%	lation	in accordance with the noise model of TH.

%	L.Ljung 7-8-87
%	Copyright (c) The MathWorks, Inc.
%	All Rights Reserved

if nargin <4,noise='nonoise';end
if nargin<3,n=10;end,if n<0,n=10;end

nu=th(1,3);Tsamp=th(1,2);
d=sum(th(1,4:6+nu*2));
[N,nz]=size(u);
if nu~=nz, error('The input matrix U has not the correct number of columns!'),
return,end
rand('normal')
[m1,m2]=size(th);
if m1<4, disp('No covariance information given in TH'),P=zeros(d,d);end
if m1>3,P=chol(th(4:m1,1:m1-3));end
par=th(3,1:m1-3);
yh=idsim(u,th);
ndu=length(yh);y1=max(yh);y2=min(yh);
y12=y1-y2;y1=y1+0.2*y12;y2=y2-0.2*y12;
axis([Tsamp ndu*Tsamp y2 y1]);plot([1:ndu]*Tsamp,yh),hold on
u1=u;
for k=1:n
	th1=th; th1(3,1:m1-3)=par+rand(1,m1-3)*P;
	if noise(3)=='i', u1=[u rand(N,1)];end
	yh=idsim(u1,th1);
	plot([1:ndu]*Tsamp,yh)
end
hold off


