function y=idsim(ue,th)
%IDSIM  simulates a given system
%
%	Y = idsim(Z,TH)
%
%	TH: contains the parameters of the general input-output model
%	A(q) y(t) =[B(q)/F(q)] u(t-nk) + [C(q)/D(q)] e(t)
%	in the format described by HELP THETA.
%
%	Z: the input-noise data Z=[u e]. For multi-input systems
%	u=[u1 u2 ... un], with ui and e being column vectors. If
%	the e-vector is omitted, a noise-free simulation is obtained.
%	The noise contribution is scaled by the variance information con-
%	tained in TH.

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

[N,nue]=size(ue);
if nue>N, error(' The data should be organized in columns!'),return,end

[a,b,c,d,f]=polyform(th);
nu=th(1,3);
LAM=th(1,1);

y=zeros(N,1);
for k=1:nu
   y=y + filter(b(k,:),f(k,:),ue(:,k));
end

if nue>nu, y=y+sqrt(LAM)*filter(c,d,ue(:,nu+1));end

y=filter([1],a,y);
