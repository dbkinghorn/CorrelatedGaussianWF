function yh = compare(z,th,m,nr,za)
% COMPARE  Compares the simulated/predicted output with the measured output
%
%	YH = compare(Z,TH,M)
%
%	Z : The output - input data for which the comparison is made (the
%	    validation data set.
%	TH: The model in the THETA format (see help theta)
%	M : The prediction horizon. Old outputs up to time t-M are used to
%	    predict the output at time t. All relevant inputs are used.
%	    M = inf gives a pure simulation of the system.(Default M=inf).
%	YH: The resulting simulated/predicted output.
%	COMPARE also plots YH together with the measured output in Z, and
%	    displays the mean square fit between these to signals.
%	    (solid/red is YH. dashed/green id measured output)
%
%	[YH,FIT] = compare(Z,TH,M,SAMPNR,LEVELADJUST)  
%	gives access to some options:
%	FIT: The mean square fit.
%	SAMPNR: The sample numbers from Z to be plotted and used for the
%	   computation of FIT. (Default: SAMPNR = all rows of Z)
%	LEVELADJUST: 'yes' adjusts the first values of YH and Z(:,1) to
%	  zero before plot and computation of FIT. 'no' is default.

%	L. Ljung 10-1-89
%	Copyright (c) 1989 by the MathWorks, Inc.
%	All Rights Reserved.
	
[nrow,nc]=size(z);
if nargin<5,za='n';end

if nargin<4,nr=1:nrow;end
if nr<0, nr=1:nrow;end
if nargin<3, m=inf;end
if m<0, m=inf;end
if m==inf,yh=idsim(z(:,2:nc),th);else yh=predict(z,th,m);end
if za(1)=='y' | za(1)=='Y'
yh(nr)=yh(nr)-yh(nr(1)); z(nr,1)=z(nr,1)-z(nr(1),1);end
plot([yh(nr) z(nr,1)])
	
title(['Output fit: ', num2str(norm(yh(nr)-z(nr,1))/sqrt(length(nr)))])
