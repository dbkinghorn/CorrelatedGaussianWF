function [t1,w,vl,v,V1,f,st]=searchoe(z,t,g,lim,Vcap,nb,nf,nk,ni)
%SEARCHOE   searches for lower values of the prediction error criterion.
%	
%	[T1,W,VL,V,V1,F,ST]=searchoe(Z,T,G,LIM,V,NB,NF,NK)
%
%	The routine searches for a lower value of the prediction error cri-
%	terion for the output-error model, starting at T, looking in the
% 	G-direction. T1 is returned as the parameters that give a lower value V1.
%	If no lower value is found, ST=1. F is the F-polynomial associated
%	with T1, and W, VL, v are the filtered data sequences.
%	The routine is to be used as a subroutine to OE. See OE for
%	an explanation of the other arguments.

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

l=0;,k=1;V1=Vcap+1; n=nf+nb;st=0;
ll=ones(z(:,2))*lim;
while [V1 > Vcap l<10],
t1=t+k*g; if l==9,t1=t;end
f=fstab([1 t1(nb+1:n)']);t1(nb+1:n)=f(2:nf+1)'; 

     w=pefilt([zeros(1,nk) t1(1:nb)'],f,z(:,2),z(1:ni,1));
     v=z(:,1)-w;
     vl=max(min(v,ll),-ll);
     V1=v'*vl/(length(v)-ni);

home, disp(int2str(l))
k=k/2;
l=l+1; if l==10, st=1;end
end
