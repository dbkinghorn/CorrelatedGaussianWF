function B = fstab(A);
%FSTAB	FSTAB(A) stabilizes a MONIC polynomial with respect to the
%	unit circle, i.e. roots whose magnitudes are greater than
%	one are reflected into the unit circle.  The result is a monic
%	polynomial as well.  Used by YULEWALK.
v = roots(A); ind=(abs(v)>eps);
vs = 0.5*(sign(abs(v(ind))-1)+1);
v(ind) = (1-vs).*v(ind) + vs./ (conj(v(ind)));
B = real(poly(v));
