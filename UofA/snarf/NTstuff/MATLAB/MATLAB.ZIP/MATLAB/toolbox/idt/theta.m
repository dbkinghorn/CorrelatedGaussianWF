function theta
% THETA is a matrix containing information about the result of parametric
%	identification of a general input-output model
%	A(q) y(t) = [B(q)/F(q)] u(t-nk) + [C(q)/D(q)] e(t)
%	A, B, C, D and F are polynomials in the delay operator of orders
%	na, nb, nc, nd and nf, respectively. If the system has nu inputs, u has
%	nu columns and nb, nf and nk are then row vectors of dimension nu, con-
%	taining information about the orders and delays associated with each of
%	the inputs. In the case of a time series (no u) B and F are not defined.
%	Let n be the sum of all the orders (=the number of estimated 
%	parameters). Let r=max(n,7,6+3*nu). Then THETA is a (3+n) x r matrix
%	organized as follows:
%	Row 1 has entries: Estimated variance of e, sampling interval, nu,na,
%	nb,nc,nd,nf,nk. Row 2 has entries, FPE, year, month, date, hour, minute
%	and command by which the model was generated. Row 3 is the vector of
%	estimated parameters A,B,C,D and F (excluding leading 1's and zeros).
%	Rows 4 to 3+n contain the estimated covariance matrix.
%
%	THETA-matrices are created by the commands MKTHETA, PEM, IV, IV4, ARX,
%	ARMAX, OE, BJ, AR and IVAR. They are transformed to other representa-
%	tions by the commands PRESENT, TRF, ZP, CONTIN, and POLYFORM.

