echo off
%	The SYSTEM IDENTIFICATION TOOLBOX is an analysis module
%	that contains tools for building mathematical models of 
%	dynamical systems, based upon observed input-output data.
%	The toolbox contains both PARAMETRIC and NON-PARAMETRIC
%	MODELING methods.
%
%	Identification Toolbox demonstrations:
%
%	1) Build simple models from real laboratory process data.
%	2) Compare different identification methods.
%	3) Model structure determination case study.
%	4) Spectrum estimation (Marple's test case).
%	5) Adaptive/Recursive algorithms.
%	6) Segmentation of data and models.
%
%	0) Quit

while (1)
	clc,clg, help iddemo
	k = input('Select a demo number: ');
	if k == 0, break, end
	if k==1, iddemo1, end
	if k==2, iddemo2, end
	if k==3, iddemo3, end
	if k==4, iddemo4, end
	if k==5, iddemo5, end
	if k==6, iddemo6, end
end
