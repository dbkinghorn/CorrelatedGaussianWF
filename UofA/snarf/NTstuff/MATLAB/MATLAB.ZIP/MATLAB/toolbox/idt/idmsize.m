function maxdef = idmsize(N,d)
%IDMSIZE	Sets default value for the variable maxsize (see help AUXVAR)
%
%	maxdef = idmsize(N,d)
%
%	N : Number of data points to be processed
%	d : Number of parameters to be estimated
% 	maxdef : Default value of maxsize
%
%	USERS WHO WORK WITH VERY LARGE DATA RECORDS AND LARGE MODELS SHOULD
%	TRIM THIS ALGORITHM TO HIS OR HER COMPUTER

%	L. Ljung 10-1-89
%	Copyright (c) 1989 by the MathWorks, Inc.
%	All Rights Reserved.

if nargin<2,d=6;end
[cmp,mem]=computer;
if mem<8192, maxdef=4096;
 else maxdef=100000;end
% The value of maxdef that gives the most efficient computing time
% in the parameter estimation algorithms depends on the memory available
% in the computer.
% The algorithms will work with matrices that are N by d, provided the
% number of elements is less than maxsize. Note that the number d is
% not provided by all of the estimation algorithms.

