function pz(dum,dum1)
%PZ	I guess you mean ZP
disp('I guess you mean ZP!')

