function present(th)
%PRESENT  presents a parametric model on the screen
%
%	present(TH)
%
%	This function displays the polynomials of the model TH together
%	with their standard deviations, loss function and Akaike's Final
%	Prediction Error criterion (FPE).

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

s=1:6;text(1,s)='ARX   ';text(2,s)='BJ    '; text(3,s)='IV    ';
text(4,s)='IV4   ';text(5,s)='PEM   '; text(6,s)='MKTHET';
text(7,s)='ARMAX ';text(8,s)='OE    '; text(9,s)='INIVAL';
text(10,s)='IVAR  ';text(11,s)='IVX   ';text(12,s)='AR    ';
nu=th(1,3); T=th(1,2);
[n1,n2]=size(th); 
if nu>0
    na=th(1,4);nb=th(1,5:4+nu);nc=th(1,5+nu);
    nd=th(1,6+nu);nf=th(1,7+nu:6+2*nu); nk=th(1,7+2*nu:6+3*nu);
else na=th(1,4);nb=0;nc=th(1,5);nd=th(1,6);nf=0;nk=0;end

NAcum=na;,NBcum=NAcum+sum(nb);, NCcum=NBcum+nc;, NDcum=NCcum+nd;
NFcum=NDcum+sum(nf);

clc
disp(['This matrix was created by the command 'text(th(2,7),:) ' on ' int2str(th(2,3)) '/' int2str(th(2,4)) ' ' int2str(th(2,2)*100) ' at ' int2str(th(2,5)) ':' int2str(th(2,6))])
disp(['Loss fcn: ' num2str(th(1,1)) '   Akaike`s FPE: ' num2str(th(2,1)) ' Sampling interval ' num2str(th(1,2))])
disp(['The polynomial coefficients and their standard deviations are'])
if n1>=NFcum+3,for k=1:NFcum,pd(k)=sqrt(th(3+k,k));,end,end
if n1<NFcum+3,for k=1:NFcum,pd(k)=0;end,end
if (nu==1)
if (nb>0), B=[zeros(1,nk) th(3,na+1:NBcum);zeros(1,nk) pd(na+1:NBcum)],end
end
if (nu>1) 
   s=1;
    for rr=1:nu
    if nb(rr)>0,
     disp(['B-polynomial from input # ' int2str(rr)])
     B=[zeros(1,nk(rr)) th(3,na+s:na+s+nb(rr)-1);zeros(1,nk(rr)) pd(na+s:na+s+nb(rr)-1)]
 s=s+nb(rr);
   end
    end
end
if (na>0),A=[1 th(3,1:NAcum);0 pd(1:NAcum)],end
if (nu==1)
if (nf>0),F=[1 th(3,NDcum+1:NFcum);0 pd(NDcum+1:NFcum)],end
end
if (nu>1),
s=1;
for rr=1:nu
if nf(rr)>0,
  disp(['F-polynomial from input # ' int2str(rr)])
  F=[1 th(3,NDcum+s:NDcum+s+nf(rr)-1); 0 pd(NDcum+s:NDcum+s+nf(rr)-1)]
  s=s+nf(rr);
end
end
end
if (nc>0),C=[1 th(3,NBcum+1:NCcum);0 pd(NBcum+1:NCcum)],end
if (nd>0),D=[1 th(3,NCcum+1:NDcum);0 pd(NCcum+1:NDcum)],end
