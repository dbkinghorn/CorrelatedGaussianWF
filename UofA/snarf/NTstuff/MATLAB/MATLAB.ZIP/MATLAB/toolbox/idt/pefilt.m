function y=pefilt(b,a,u,t)
%PEFILT
%
%	y = pefilt(b,a,u,t)
%
%	y is obtained as the filtered output to the system b/a with
%	input u. The initial conditions are chosen so that the first
%	values of y equal the entries in the vector t.

%	L. Ljung 87-08-08	
%	Copyright (c) The Mathworks Inc.
% 	All Rights Reserved

if nargin<4, t=[];end
na=length(a)-1;nb=length(b)-1;
n=max([na nb length(t)]);
t=[t(:);zeros(n,1)];
f1=filter(a,1,t(1:n));

f2=filter(b,1,u(1:n));
x=f1(:)-f2(:);
y=filter([b zeros(1,n-nb)],[a zeros(1,n-na)],u,x);
end
