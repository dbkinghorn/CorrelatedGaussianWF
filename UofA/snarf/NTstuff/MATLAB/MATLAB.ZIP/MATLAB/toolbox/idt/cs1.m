echo on
%CASE STUDY NUMBER 1 : A GLASS TUBE DRAWING FACTORY
% (See readme4 if you encounter out-of-memory problems)
%
% In this Case Study we shall study data from a glass tube factory. The
% experiments and the data are discussed in
%
% V. Wertz, G. Bastin and M. Heet: Identification of a glass tube
% drawing bench. Proc. of the 10th IFAC Congress, Vol 10, pp 334-339
% Paper number 14.5-5-2. Munich August 1987.
%
% The the output of the process is the thickness and the diameter of
% the manufactured tube. The inputs are the air-pressure inside the
% tube and the drawing speed.
%
% We shall in this tutorial study the process from the input speed
% to the output thickness.
%
load thispe25.mat
% 
% First we look at the data. We split it into two halves, one for
% estimation and one for validation:
%

ze=thispe25(1001:1500,:);
zv=thispe25(1501:2000,:);pause
idplot(ze),pause
% A close-up:
pause
idplot(ze,101:200),pause
% Let us remove the mean values:

ze=dtrend(ze);
zv=dtrend(zv);

% The sampling interval of the data is one second. We may perhaps
% detect some rather high frequencies in the output. Let us therefore
% first compute the input and output spectra:

sy=spa(ze(:,1));
su=spa(ze(:,2));
pause

bodeplot(sy)
grid,pause
bodeplot(su)
grid,pause

% We may note that the input has very little relative energy above 1 rad/sec
% while the output has quite some energy there. There are thus some high
% frequency disturbancies that may cause some problem for the model building.

% We also as a preliminary test compute the spectral analysis estimate:

[gs,phiv]=spa(ze);
pause
bodeplot(gs,3),pause

% We note, among other things, that the hight frequency behavior is quite
% uncertain.
% Let us go on to find some suitable model structures. First we look
% for a good value of the delay:

V = arxstruc(ze,zv,struc(2,2,1:30));
nn=selstruc(V,0) % The best fit to the validation set
pause

% We now try a number of models with different orders and delays around 12:

V = arxstruc(ze,zv,struc(1:6,1:6,8:12));
%
% We shall now take a look at the fits. Choose yourself what you think gives
% a good fit.
pause 
nn=selstruc(V)


% Let's compute the model:
m1 = arx(ze,nn);

% How well does it simulate the true system?
pause
compare(zv,m1);pause

% A close up:
pause
compare(zv,m1,inf,101:200);pause

%
% There are clear difficulties to deal with the high frequency components
% of the output. That in conjunction with the long delay suggests that we
% decimate the data  by four (i.e. low-pass filter it and pick every fourth 
% value):

zd(:,1)=decimate(dtrend(thispe25(:,1)),4);
zd(:,2)=decimate(dtrend(thispe25(:,2)),4);

zde=zd(1:500,:);
zdv=zd(501:length(zd),:);
pause

% Let us find a good structure for the decimated data using the same
% strategy as before:

V = arxstruc(zde,zdv,struc(2,2,1:30));
nn=selstruc(V,0)
V = arxstruc(zde,zdv,struc(1:5,1:5,nn(3)-1:nn(3)+1));
pause,
nn=selstruc(V)
% Let's compute and check the model for whatever model you just preferred:

m2=arx(zde,nn);
m2(1,2)=4; % The sampling interval
compare(zdv,m2,inf,21:150);pause

% This seems much better!

% We may also compare the bodeplots of the model m1 and m2:

g1=trf(m1);
g2=trf(m2);
pause
bodeplot([g1 g2]),pause

% We see that the two models agree well up to the Nyqusti frequency of
% the slower sampled data.

% Let's test the residuals:
pause
resid(zdv,m2);pause

% This seems OK.
% Let us however also check if we can do better by modeling the noise
% separately in a Box-Jenkins model:

mb=bj(zde,[nn(2) 2 2 nn(1) nn(3)]);
mb(1,2)=4; % The sampling interval

% Is this better than the ARX-model in simulation ?
% (press key)
pause
clg
subplot(211)
compare(zdv,m2);
compare(zdv,mb);pause

% The Box-Jenkins model is thus capable of describing the validation 
% data set somewhat better. How about the Bode plots?

gb=trf(mb);
pause
bodeplot([g2 gb]),pause

% The models agree quite well, apart from the funny twist in the BJ model.
% This twist, however, seems to have some physical relevance, since we
% get better simulations in the latter case.
% Finally we may compare the FPE:s of the two models:

[m2(2,1) mb(2,1)]

% To summarize: After decimation it is quite possible to build simple models
% that are capable of reproducing the validation set in a good manner.

