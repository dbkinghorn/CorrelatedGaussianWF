echo on
clc
%	The command SEGMENT segments data that are generated from
%	systems that may undergo abrupt changes. Typical applications
%	for data segmentation are segmentation of speech signals (each
%	segment corresponds to a phonem), failure detection (the segments
%	correspond to operation with and without failures) and estimating
%	different working modes of a system.  We shall study a system
%	whose time delay changes from two to one.

load iddemo6.mat

%	First, take a look at the data:

pause, idplot(z), pause   % Press any key for plot.
clc
%	The change takes place at sample number 20, but this is not
%	so easy to see.
%
%	We would like to estimate the system as an ARX-structure model
%	with one a-parameter, two b-parameters and one delay:

%	y(t) + a*y(t-1) = b1*u(t-1) + b2*u(t-2)

%	The information to be given is the data, the model orders
%	and a guess of the variance (r2) of the noise that affects
%	the system. If this is entirely unknown, it may be estimated
%	automatically: 

nn = [1 2 1];
seg = segment(z,nn);

pause % Press any key to continue.
clc
%	Let's take a look at the segmented model. Solid/red line
%	is for the a-parameter. Dashed/green is for b1 and dotted/blue
%	for the parameter b2. 

pause, plot(seg), pause     % Press any key for plot.
hold on
clc
% 	We see clearly the jump at sample number 20. b1 goes from
%	0 to 1 and b2 vice versa, which shows the change of the
%	delay. The true values can also be shown:

pause, plot(pars), pause   % Press any key for plot.
hold off
clc
%	It is usually better to provide a guess of the variance r2
%	than to estimate it, and the rule of thumb is that it is
%	better to overestimate it than to underestimate it. Assuming
%	that the variance r2 is 0.1 gives

[seg,v,tvmod] = segment(z,[1 2 1],0.1);

pause % Press any key for plot.
plot(seg), hold on, plot(pars), hold off, pause
clc
%	The method for segmentation is based on AFMM (adaptive
%	forgetting through multiple models), Andersson, Int. J.
%	Control Nov 1985.  A multi-model approach is used in a first
%	step to track the time varying system. The resulting tracking
%	model could be of interest in its own right, and are given by
%	the third output argument of SEGMENT (tvmod in our case). They
%	look as follows:

pause, plot(tvmod), pause     % Press any key for plot.
clc
%	The SEGMENT M-file is thus an alternative to the recursive
%	algorithms RPEM, RARX etc for tracking time varying systems.
%	It is particularily suited for systems that may change rapidly.

%	From the tracking model, SEGMENT estimates the time points when
%	jumps have occured, and constructs the segmented model by a
%	smoothing procedure over the tracking model.

%	The two most important "knobs" for the algorithm are r2, as
%	mentioned before, and the guessed probability of jumps, q, the
%	fourth input argument to SEGMENT.  The smaller r2 and the larger
%	q, the more willing SEGMENT will be to indicate segmentation
%	points. In an off line situation, the user will have to try a
%	couple of choices (r2 is usually more sensitive than q). The
%	second output argument to SEGMENT, v, is the loss function for
%	the segmented model (i.e. the estimated prediction error variance
%	for the segmented model). A goal will be to minimize this value.

pause	% Press any key to continue.
clc
%	OBJECT DETECTION IN LASER RANGE DATA
%
%	The reflected signal from a laser (or radar) beam contains
%	information about the distance to the reflecting object. The
%	signals can be quite noisy.  The presence of objects affects
%	both the distance information and the correlation between
%	neighbouring points. (A smooth object increases the 
%	correlation between nearby points.)
%
%	In the following we study some quite noisy laser range data.
%	They are obtained by one horisontal sweep, like one line on
%	a TV-screen. The value is the distance to the reflecting object.
%	We happen to know that an object of interest hides between
%	sample numbers 17 and 48. 

pause, plot(hline), pause   % Press any key for plot.
clc
%	The eye is not good at detecting the object. We shall use
%	"segment".  First we detrend and normalize the data to a
%	variance about one. (This is not necessary, but it means that
%	the default choices in the algorithm are better tuned.)

hline = dtrend(hline)/200;

%	We shall now build a model of the kind:
%
%	   y(t) + a y(t-1) = b
%
%	The coefficient 'a' will pick up correlation information.  The
%	value 'b' takes up the possible changes in level. We thus
%	introduce a fake input of all ones:

zline = [hline ones(hline)];
s = segment(zline,[1 1 1],0.2);

pause	% Press any key to check segmentation.
subplot(211),plot(hline),title('LASER RANGE DATA'),plot(s)
title('SEGMENTED MODELS, solid/red: correlation, dashed/green: distance'),pause
clc
%	The segmentation has thus been quite successful.

%	SEGMENT is capable of handling multi-input systems, and of using
%	ARMAX models for the added noise.  We may try this on the test
%	data iddata1.mat (which contains no jumps):

load iddata1.mat
s = segment(z1(1:100,:),[2 2 2 1],1);

pause, plot(s),hold on, pause  % Press any key for plot.
clc
%	Compare this with the true values: 

pause	% Press any key for plot.
plot([ ones(100,1)*[-1.5 0.7],ones(100,1)*[1 0.5],ones(100,1)*[-1 0.2]]),pause
hold off
clc

%	SEGMENT thus correctly finds that no jumps have occured, and
%	also gives good estimates of the parameters.

pause	% Press any key to continue.

