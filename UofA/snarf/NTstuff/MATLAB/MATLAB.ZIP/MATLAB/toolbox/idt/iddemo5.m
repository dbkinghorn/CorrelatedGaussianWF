hold off
%IDDEMO5
echo on
clc
%	This demo describes the group of RECURSIVE (ON-LINE)
%	algorithms.  The recursive M-files include: RPEM, RPLR,
%	RARMAX, RARX, ROE, and RBJ.   These algorithms implement
%	all the recursive algorithms described in Chapter 11 of
%	Ljung(1987).
%
%	RPEM is the general Recursive Prediction Error Algorithm
%	(11.44) for arbitrary multiple-input-single-output models
%	(the same models as PEM works for).
%
%	PRLR is the general Recursive PseudoLinear Regression method
%	(11.57) for the same family of models.
%
%	RARX is a more efficient version of RPEM (and RPLR) for the
%	ARX-case.
%
%	ROE, RARMAX and RBJ are more efficient versions of RPEM for
%	the OE, ARMAX, and BJ cases (compare these functions to the
%	off-line methods).

pause	% Press any key to continue.
clc
%	ADAPTATION MECHANISMS:  Each of the algorithms implement the
%	four most common adaptation principles:
%
%	KALMAN FILTER approach: The true parameters are supposed to
%	vary like a random walk with incremental covariance matrix
%	R1. See (11.66)-(11.67).
%
%	FORGETTING FACTOR approach: Old measurements are discounted
%	exponentially. The base of the decay is the forgetting factor
%	lambda. See (11.63)
%
%	GRADIENT method: The update step is taken as a gradient step
%	of length gamma (th_new=th_old + gamma*psi*epsilon). See (11.45).
%
%	NORMALIZED GRADIENT method: As above, but gamma is replaced by
%	gamma/(psi'*psi). See (11.46).  The Gradient methods are also
%	known as LMS (least mean squares) for the ARX case.

pause   % Press any key to continue.
clc
%	Let's pick a model and generate some input-output data:

rand('normal')
u = sign(rand(50,1)); e = 0.2*rand(50,1);
th0 = mktheta([1 -1.5 0.7],[0 1 0.5],[1 -1 0.2]);
y = idsim([u e],th0); z = [y u];

pause, idplot(z), pause   % Press a key to see data.
clc
%	First we build an Output-Error model of the data we just
%	plotted.  Use a second order model with one delay, and apply
%	the forgetting factor algorithm with lambda = 0.98:

thm1 = roe(z,[2 2 1],'ff',0.98); % This takes a while on slow machines

%	The four parameters can now be plotted as functions of time.

pause, plot(thm1), pause  % Press a key to see plot.
clc
%	The true values are as follows: (Press a key for plot)

pause, hold, plot(ones(50,1)*[1 0.5 -1.5 0.7]), pause
hold off
clc
%	Now let's try a second order ARMAX model, using the RPLR
%	approach (i.e ELS) with Kalman filter adaptation, assuming
%	a parameter variance of 0.001:

thm2 = rplr(z,[2 2 2 0 0 1],'kf',0.001*eye(6));

pause   % Press any key for plot.
axis([0 50 -2 2]), plot(thm2), pause
clc
% The true values are as follows: (Press any key for plot)

pause, hold, plot(ones(50,1)*[-1.5 0.7 1 0.5 -1 0.2]), pause
hold off
clc
%	So far we have assumed that all data are available at once.
%	We are thus studying the variability of the system rather
%	than doing real on-line calculations. The algorithms are
%	also prepared for such applications, but they must then
%	store more update information. The conceptual update then 
%	becomes:

%  1. Wait for measurements y and u.
%  2. Update: [th,p,phi] = rarx([y u],[na nb nk],'ff',0.98,th',p,phi)
%  3. Use th for whatever on-line application required.
%  4. Go to 1.

%	Thus the previous estimate th is fed back into the algorithm
%	along with the previous value of the "P-matrix" and the data
%	vector phi.

%	We now do an example of this where we plot just the current
%	value of th. You can look at the code after the plot is done.

pause   % Press any key to continue

[th,p,phi] = rarx(z(1,:),[2 2 1],'ff',0.98);
axis([1 50 -2 2])
plot(1,th(1),'*',1,th(2),'+',1,th(3),'o',1,th(4),'*'), hold

for k = 2:50
	 [th,p,phi] = rarx(z(k,:),[2 2 1],'ff',0.98,th',p,phi);
	 plot(k,th(1),'*',k,th(2),'+',k,th(3),'o',k,th(4),'*')
end, pause
hold off
echo off

