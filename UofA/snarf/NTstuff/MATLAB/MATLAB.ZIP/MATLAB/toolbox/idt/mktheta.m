function th=mktheta(a,b,c,d,f,LAM,T)
%MKTHETA constructs a "theta-matrix" from given polynomials
%
%	TH = mktheta(A,B,C,D,F,LAM,T)
%
%	TH: returned as a matrix of the standard format, describing the model
%	A(q) y(t) = [B(q)/F(q)] u(t-nk) + [C(q)/D(q)] e(t)
%	The exact format is given in HELP THETA.
%
%	A,B,C,D and F are entered as the polynomials. A,C,D and F start with
%	1 , while B contains leading zeros to indicate the delay(s).
%	For multi-input systems B and F are matrices with the number of rows
%	equal to the number of inputs. For a time series, B and F are entered
%	as []. MKTHETA is thus the inverse of POLYFORM.
%
%	LAM is the variance of the noise term e, and T is the sampling interval.
%	Trailing C,D,F, LAM, and T can be omitted, in which case they are
%	taken as 1's (if B=[], F=[]).

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

[nu,nb1]=size(b); nu=nu(1);


if nargin<7, T=1;end
if nargin<6, LAM=1;end
if nargin<5, f=ones(nu,1);end
if nargin<4, d=1;end
if nargin<3, c=1;end
 
na=length(a)-1;nc=length(c)-1;nd=length(d)-1;
if nu>0,ib=b~=0; nk=sum(cumsum(ib')==0);
	ib=(b(:,nb1:-1:1)~=0); nb=-sum(cumsum(ib')==0)-nk+nb1;end
if nu==0, nb=0;nk=0;end

[nuf,nf1]=size(f);
if nuf~=nu, error('f and b must have the same number of rows!'),return,end

if nf1==1, nf=zeros(1,nu);
else
ih=(f(:,nf1:-1:1)~=0); nf=-sum(cumsum(ih')==0)+nf1-1;
end

n=na+sum(nb)+nc+nd+sum(nf);

th=zeros(3+n,max([7 6+3*nu n]));
if nu>0
    th(1,1:6+3*nu)=[LAM T nu na nb nc nd nf nk];
else
    th(1,1:6)=[LAM T nu na nc nd];
end

if na>0, th(3,1:na)=a(2:na+1);end
 if nc>0, th(3,na+sum(nb)+1:na+nc+sum(nb))=c(2:nc+1);end
if nd>0, th(3,na+nc+1+sum(nb):na+nc+nd+sum(nb))=d(2:nd+1);end

sb=na;sf=na+sum(nb)+nc+nd;
for k=1:nu
   if nb(k)>0,th(3,sb+1:sb+nb(k))=b(k,nk(k)+1:nk(k)+nb(k));end
   if nf(k)>0,th(3,sf+1:sf+nf(k))=f(k,2:nf(k)+1);end
   sb=sb+nb(k);
   sf=sf+nf(k);
end
ti=fix(clock); ti(1)=ti(1)/100;
th(2,2:6)=ti(1:5); th(2,7)=6;
