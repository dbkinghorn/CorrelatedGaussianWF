function zpsdpl(zepo,sd,w,iz,mark1,mark2)
%ZPSDPL	plots standard deviations in zepo-pole plots
%
%	zpsdpl(zepo,sd,w,iz,mark1,mark2)
%
%	This is a help function to zpplot.

%	L.Ljung 7-2-87
%	Copyright (c) 1987 by the Mathworks, Inc.
%	All rights reserved

for k=iz
    if imag(zepo(k,1))==0
    rp=real(zepo(k,1)+sd*zepo(k,2)*[-1 1]);
    plot(rp,zeros(rp),mark1)
    else if imag(zepo(k,1))>0
         r1=real(zepo(k,2));r2=imag(zepo(k,2));r3=zepo(k+1,2);
	 p1=r1*r1;p2=r2*r2;p3=r3*r1*r2;
	 SM=[p1 p3;p3 p2]; [V,D]=eig(SM); z1=real(w)*sd*sqrt(D(1,1));
	 z2=imag(w)*sd*sqrt(D(2,2)); X=V*[z1;z2];
	 X=[X(1,:)+real(zepo(k,1));X(2,:)+imag(zepo(k,1))];
	 plot(X(1,:),X(2,:),mark2,X(1,:),-X(2,:),mark2)
         end
    end
end
