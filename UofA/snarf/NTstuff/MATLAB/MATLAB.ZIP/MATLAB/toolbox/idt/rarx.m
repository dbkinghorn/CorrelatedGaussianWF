function [thm,p,phi] = rarx(z,nn,adm,adg,th0,p0,phi)
%RARX	Computes estimates recursively for an ARX model using the
%	Recursive Least Squares Method
%
%	THM = rarx(Z,NN,adm,adg)
%
%	Z: The output-input data z=[y u]
%	NN : NN=[na nb nk], The orders and delay of an ARX model (see HELP ARX)
%	adm: Adaptation mechanism. adg: Adaptation gain
%	 adm='ff', adg=lam:  Forgetting factor algorithm, with forg factor lam
%	 adm='kf', adg=R1: The Kalman filter algorithm with R1 as covariance 
%		matrix of the parameter changes per time step
%	 adm='ng', adg=gam: A normalized gradient algorithm, with gain gam
%	 adm='ug', adg=gam: An Unnormalized gradient algorithm with gain gam
%	THM: The resulting estimates. Row k contains the estimates "in alpha-
%	     betic order" corresponding to data up to time k (row k in Z)
%
%	Initial value of parameters(TH0) and of "P-matrix" (P0) can be given by
%	[THM,P] = rarx(Z,NN,adm,adg,TH0,P0)
%	Initial and last values of auxiliary data vector phi  are 
%	obtained by [THM,P,phi]=rarx(Z,NN,adm,adg,TH0,P0,phi0). 
%	
%	See also RARMAX, ROE, RBJ, RPEM and RPLR.

%	L. Ljung 10-1-89
%	Copyright (c) 1989 by the MathWorks, Inc.
%	All Rights Reserved.


[nz,ns]=size(z);
if 2*ns-1~=length(nn),error('Incorrect number of orders specified in nn. nn=[na nb nk]'),end
na=nn(1);nb=nn(2:ns);nk=nn(ns+1:2*ns-1);nu=1;
if any(nk<1),error('Sorry, this routine requires nk>0; Shift input sequence if necessary!'),end
d=na+sum(nb);
nbm=nb+nk-1;ncbm=na+cumsum([0 nbm]);
ii=[1:na+sum(nbm)];
i=[1:na];
for ku=1:ns-1,i=[i ncbm(ku)+nk(ku):ncbm(ku+1)];end 

dm=na+sum(nbm);

if nargin<7, phi=zeros(dm,1);end
if nargin<6, p0=10000*eye(d);end
if nargin<5, th0=eps*ones(d,1);end
p=p0;th=th0;
if adm(1)=='f', R1=zeros(d,d);lam=adg;end
if adm(1)=='k', [sR1,SR1]=size(adg);
     if sR1~=d | SR1~=d,error('The R1 matrix should be a square matrix with dimension equal to number of parameters!'),end
     R1=adg;lam=1;
end
if adm(2)=='g', grad=1;else grad=0;end

for k=1:nz

epsi=z(k,1)-phi(i)'*th;
if ~grad,K=p*phi(i)/(lam + phi(i)'*p*phi(i));
         p=(p-K*phi(i)'*p)/lam+R1;
else K=adg*phi(i);end
if adm(1)=='n', K=K/(eps+phi(i)'*phi(i));end
th=th+K*epsi;

epsilon=z(k,1)-th'*phi(i);

phi(ii+1)=phi(ii);
if na>0,phi(1)=-z(k,1);end
phi(ncbm(1:ns-1)+1)=z(k,2:ns)';

thm(k,:)=th';
end
