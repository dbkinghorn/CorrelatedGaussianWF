function [G,PV]=trf(th,nnu,w)
%TRF	Computes the transfer function of a model.
%
%	G = trf(TH)  or  [G,NSP] = trf(TH)
%
%	TH: A matrix defining a model, as described in HELP THETA
%
%	G is returned as the transfer function estimate, and NSP (if specified)
%	as the noise spectrum, corresponding to the model TH. These functions
%	are  of the standard frequency function format (see HELP FREQFUNC)
%	If TH describes a time series, G is returned as its spectrum.
%	
%	If the model TH has several inputs, G will be returned as the transfer
%	functions of selected inputs # j1 j2 .. jk by 
%	G = trf(TH,[j1 j2 ... jk])  [default is all inputs]
%	The functions are computed at 128 equally spaced frequency-values
%	between 0 (excluded) and pi/T, where T is the sampling interval
%	specified by TH. The functions can be computed at arbitrary
%	frequencies w (a row vector, generated e.g. by LOGSPACE) by
%	G = trf(TH,ku,w)   or  [G,NSP] = trf(TH,ku,w)
%	The transfer function can be plotted by BODEPLOT. bodeplot(trf(TH)) is
%	a possible construction. See also TRFSD and TRFCONT.

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.
 
T=th(1,2); nu=th(1,3);

% *** Set up default values ***

if nargin<3, w=pi*[1:128]/128/T;,end
if nargin<2 , nnu=1:th(1,3);end
if length(w)==1, if w<0, w=pi*[1:128]/128/T;end,end
if length(nnu)==1, if nnu<0, nnu=1:th(1,3);end,end

% *** Compute the model polynomials and form the basic
%      matrix of frequencies ***

[a,b,c,d,f]=polyform(th);
nm=max([length(a)+length(f)-1 length(b) length(c) length(d)+length(a)-1]);
   i=sqrt(-1);
OM=exp(-i*[0:nm-1]'*w*T);

% *** Compute the transfer function(s) GC=B/AF ***
nrc=length(w)+1;
sc=1;
for k=nnu
    G(1,sc:sc+2)=[100+k,k,20+k];	
    G(2:nrc,sc)=w';
     gn=conv(a,f(k,:));
     GC=(b(k,:)*OM(1:length(b(k,:)),:))./(gn*OM(1:length(gn),:));
    G(2:nrc,sc+1)=abs(GC');
    G(2:nrc,sc+2)=phase(GC)'*180/pi;
    sc=sc+3;
end
if nargout==1 & nu>0, return, end

% *** Compute the transfer function H=C/AD ***

hn=conv(a,d);
H=(c*OM(1:length(c),:))./(hn*OM(1:length(hn),:));
PV(1,[1,2])=[100,0];
PV(2:nrc,1)=w';
PV(2:nrc,2)=(abs(H).^2)'*th(1,1);

if nu==0, G=PV;end
