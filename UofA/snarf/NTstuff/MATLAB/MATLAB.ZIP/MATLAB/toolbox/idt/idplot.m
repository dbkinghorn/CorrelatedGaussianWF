function idplot(z,int,T,PC)
%IDPLOT	Plots input - output data
%
%	idplot(Z)   or   idplot(Z,INT)
%
%	Z is the input - output data [y u]. This is plotted with output over
%	input. The data points specified in the row vector INT are selected.
%	The default value is all data.
%	If the sampling interval is T, correct time axes are obtained by
%
%	idplot(Z,INT,T)
%
%	It is assumed that the input is piecewise constant between sampling
%	instants, and it is plotted accordingly. If linear interpolation
%	between input data points is preferred, use
%	
%	idplot(Z,INT,T,'LI')

%	L. Ljung 87-7-8
%	Copyright (c) The MathWorks, Inc.
%	All Rights Reserved

if nargin<4, PC='PC';end
if nargin<3, T=1;end,if T<0,T=1;end
if nargin<2, int=1:length(z(:,1));end
if int<0,int=1:length(z(:,1));end
[N,nz]=size(z);
subplot(111)
if nz==1,plot(T*int,z(int,1)),title('OUTPUT'),return,end
subplot(211)
for kk=2:nz
   plot(T*int,z(int,1))
   title('OUTPUT')
   if PC~='PC',plot(T*int,z(int,kk)),end
   if PC=='PC'
   	ax=axis;
	xa(1:2:2*length(int)-1)=T*int;
	xa(2:2:2*length(int)-1)=T*int(2:length(int));
	ya(1:2:2*length(int)-1)=z(int,kk);
	ya(2:2:2*length(int)-1)=z(int(1:length(int)-1),kk);
	y1=min(ya);y1=y1-0.1*abs(y1);
	y2=max(ya);y2=y2+0.1*abs(y2);
	axis([ax(1:2) y1 y2]);
	plot(xa,ya)
	axis;
    end
    title(['INPUT #',num2str(kk-1)])
    if kk<nz,pause,end

end
subplot(111)


