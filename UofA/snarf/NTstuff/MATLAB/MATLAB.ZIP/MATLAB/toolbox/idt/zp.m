function [zepo,Kg]=zp(th,ku)
%ZP	Computes zeros, poles and static gains associated with a model
%
%	[ZEPO,K] = zp(TH)
%
%	For a model defined by TH (in the format described by HELP THETA)
%	ZEPO is returned as the zeros and poles and K as the static gains
%	of the model. The first rows in these matrices contain integers with
%	information about the column in question. For the zeros and the gains
%	this integer is simply the input number, while for the poles it is
%	20 + the input number. The noise source e is in this context counted
%	as input number 0.
%
%	With  [ZEPO,K] = zp(TH,KU) the zeros and poles associated with
%	the input numbers given by the entries of the row vector KU are computed
%	The default value is KU=[1:number of inputs].
%
%	The zeros and poles can be plotted by ZPPLOT. zpplot(zp(TH)) is a
%	possible construction.
%	See also zpsd.

%	L. Ljung 10-1-86, revised 7-3-87.
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

% *** Set up default values ***
nu=th(1,3);
if nu==0,kudef=0;else kudef=1:nu;end
if nargin<2, ku=kudef;end
if length(ku)==1, if ku<0, ku=kudef;end,end
if max(ku)>nu | min(ku)<0, error('Input indices outside # of inputs in theta')
return,end


   [a,b,c,d,f]=polyform(th);


  if length(find(ku==0))>0
       b(nu+1,1:length(c))=c;
       f(nu+1,1:length(d))=d;
  end

  [n1,nb]=size(b); [n1,nf]=size(f);

  nzp=max(nb-1,nf+length(a)-2);

 zepo=zeros(nzp+1,2*length(ku));

      cc=1;
    for k=ku
      zepo(1,cc:cc+1)=[k 20+k];Kg(1,(cc+1)/2)=k;
      if k==0,k=nu+1;end
      dg=conv(a,f(k,:));
      zb=roots(b(k,:)); nzb=length(zb);
      if nzb>0, zepo(2:nzb+1,cc)=zb;end
      zg=roots(dg); nzg=length(zg);
      if nzg>0, zepo(2:nzg+1,cc+1)=zg;end
      [tmp1,tmp2]=size(b(k,:));
      Kg(2,(cc+1)/2)=(b(k,:)*ones(tmp1,tmp2)')/(dg*ones(dg)');
      cc=cc+2;
    end
