function readme4(n)

% There are the following changes and additions:
%
% Note that the SITB DETREND is now called DTREND to avoid naming clash
% with the function DETREND in the main MATLAB system.
%
% The "hair-dryer" data analysed in Section 17.2 in Ljung(1987) is
% available as dryer2.mat (cf Fig 17.11) and dryer5.mat (cf Fig 17.12).
% 
% Six demos have been added. Type iddemo and select one of six options.
% Use "help sitb" to list available commands.
%
% The following commands have been added (not yet documented in the manual):
%
% nyqplot	predict	compare	idfilt	rpem	rplr	rarx	rarmax
% roe		rbj	segment	cs1	cs2  	idmsize
%
% nyqplot: plots Nyquist diagrams
% predict: computes predictions of future outputs
% compare: computes, plots and compares predicted/simulated outputs with
%          actually measured outputs
% idfilt:  filters input-output data
% idmsize: sets default values for the 'maxsize' varible
%
% rpem, rplr, rarx, rarmax, roe and rbj are recursive (on-line) versions
% of the corresponding off-line algorithms pem, arx and so on.
% See demo number 5 (or print iddemo5.m) for details.
%
% segment: performs segmentation of data and models, i.e. it detects
%          jumps and abrupt changes in dynamics and estimates different
%	   models over the different segments. See demo number 6 (or print
%	   iddemo6.m) for details.
%
% Two identification case-studies have been added as tutorials. Execute
% cs1 or cs2. The former one deals with glass tube manufactoring and the
% second one with data from a power line. If you encounter out-of-memory
% problems when you execute these, print cs1.m and cs2.m and follow
% the steps "by hand". Then pack and clear as required.
%
%
% For those who have upgraded from version 1.1, note these items:
%
% The following commands have been added:
%
% ar	arxstruc	dtrend	etfe	idplot	idsimsd	ivar	ivstruc	
% ivx	selstruc	struc	trfcont	trfsd	zpform	zpsd
%
%
% The following commands have been changed and/or given some additional
% features
%
% bodeplot	contin	resid	spa	zpplot
%
%
% The freqfunc-format and the zero-pole format have also been changed
% in order to accomodate the information about standard deviations.
%
% Some minor algorithmic changes have been introduced in armax, bj, oe
% and pem, in order to deal with narrowband systems in a better way.
%
% A change from version 2.0 is that a more flexible use of the memory-
% speed trade-off has been included. If you work with very large data
% sets and/or with very large models, it may be worth while to optimize
% the MAXSIZE-default in the .m-file "idmsize".
%
% Another change from version 2.0 is that "bodeplot" does not restore
% the subplot mode. This allows for examining spectra in diagrams
% of various scales afterwards. (See demo number 4).
%	
% FINAL NOTE: This version of the SYSTEM IDENTIFICATION TOOLBOX has been
% adapted to MATLAB version 3.5. It thus makes use of some files that are 
% not present in earlier versions of MATLAB.

disp('System Identification Toolbox Version 2.11  12-Mar-1990')
if ~nargin
	disp('Press any key to see readme file'),pause
	clc, help readme4
end
