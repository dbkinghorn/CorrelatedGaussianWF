function [yhat,thpred]=predict(z,theta,m)
%PREDICT Computes the m-step ahead prediction
%	
%	YP = predict(Z,TH,M)
%	
%	Z : The output - input data for which the prediction is computed.
%	    Z = [Y U], where Y and U are column vectors (one for each input)
%	TH: The model in the THETA format (see help theta)
%	M : The prediction horizon. Old outputs up to time t-M are used to
%	    predict the output at time t. All relevant inputs are used.
%	    M = inf gives a pure simulation of the system.(Default M=1).
%	YP: The resulting predicted output.
% 
% 	With [YP,THPRED] = predict(Z,TH,M) the predictor is returned in the
%	THETA format

%	L. Ljung 10-1-89
%	Copyright (c) 1989 by the MathWorks, Inc.
%	All Rights Reserved.

if nargin<3, m=1;end
[a,b,c,d,f]=polyform(theta);
nu=theta(1,3);

if nu>0,ff=1;for ku=1:nu, ff=conv(ff,f(ku,:));end
a=conv(conv(a,ff),d);c=conv(c,ff);else a=conv(a,d);end


na=length(a);nc=length(c);nn=max(na,nc);
a=[a,zeros(1,nn-na)];c=[c,zeros(1,nn-nc)];
[f,g]=deconv(conv([1 zeros(1,m-1)],c),a);
ng=length(g);

if nu>0,
df=conv(d,f);
for ku=1:nu
bf(ku,:)=conv(b(ku,:),df);
end
nbf=length(bf(1,:));nn=max(ng,nbf);
gg=[[g,zeros(1,nn-ng)];[bf,zeros(nu,nn-nbf)]];
else gg=g;end

thpred=mktheta(c,gg);
yhat=idsim(z,thpred);

