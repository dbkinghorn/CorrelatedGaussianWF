%iddemo4

clc, echo on
%	In this demo we consider spectrum estimation, using Marple's
%	test case (The complex data in L. Marple: S.L. Marple, Jr, 
%	Digital Spectral Analysis with Applications, Prentice-Hall,
%	Englewood Cliffs, NJ 1987.)

load marple

%	Select the real part of the data for further
%	analysis.  Several of the routines in the SITB support
%	complex data, however.

marple = marple(:,1);

%	First, take a look at the data:

pause, idplot(marple), pause   % Press a key for plot.
clc
%	Let's first check the periodogram of the data;

sp = etfe(marple);

pause, bodeplot(sp), pause    % Press a key for plot.
clc
%	Let's now try the Blackman-Tukey approach to spectrum estimation:

ss = spa(marple);

pause, bodeplot([sp ss]), pause    % Press key for plot.

%	The default window length gives a very narrow lag window for this
%	small amount of data. We can choose a larger lag window by

ss20 = spa(marple,20);

pause, bodeplot([sp ss20]), pause  % Press a key for plot.
clc
%	A parametric 5-order AR-model is computed by

t5 = ar(marple,5);

%	and its spectrum is:

s5 = trf(t5);

%	Compare with the periodogram estimate:

pause, bodeplot([sp s5]), pause   % Press key for plot. 
clc
% 	The AR-command in fact covers 20 different methods for
%	spectrum estimation.  The above one was what is known
%	as 'the modified covariance estimate' in Marple's book.
%	Some other well known ones are obtained with:

tb5 = ar(marple,5,'burg');	% Burg's method
ty5 = ar(marple,5,'yw');  	% The Yule-Walker method
sb5 = trf(tb5);sy5 = trf(ty5);	% The spectra

       % Press key for plot: solid/red: Modified covariance
       %                     dashed/green: Burg
pause  %                     dotted/blue : Yule-Walker

bodeplot([s5 sb5 sy5]), pause
clc
%	AR-modeling can also be done using the Instrumental
%	Variable approach:

ti = ivar(marple,5);

        % Press key for plot: solid/red: Modified covariance
pause   %                     dashed/green : Instrumental Variable     	

si = trf(ti);
bodeplot([s5 si]),pause
clc
%	Furthermore, the SITB covers ARMA-modeling of spectra:

ta53 = armax(marple,[5 3]);   % 5 AR-parameters and 3 MA-parameters

sa53 = trf(ta53);             % The spectrum

       % press key for plot. solid/red: Modified covariance
pause  %                     dashed/green : ARMA

bodeplot([s5 sa53]),pause
echo off
