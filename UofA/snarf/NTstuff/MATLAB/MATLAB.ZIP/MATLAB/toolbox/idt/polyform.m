function [a,b,c,d,f]=polyform(th)
%POLYFORM computes the polynomials associated with a given model
%
%	[A,B,C,D,F]=polyform(TH)
%
%	TH is the model with format described by HELP THETA.
%
%	A,B,C,D, and F are returned as the corresponding polynomials
% 	in the general input-output model. A, C and D are then row
%	vectors, while B and F have as many rows as there are inputs.

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

nu=th(1,3);
na=th(1,4);,if nu>0,nb=th(1,5:4+nu);,end,nc=th(1,5+nu);,nd=th(1,6+nu);, if nu>0,nf=th(1,7+nu:6+2*nu);,nk=th(1,7+2*nu:6+3*nu);,end
Nacum=na;,Nbcum=Nacum+sum(nb);,Nccum=Nbcum+nc;,Ndcum=Nccum+nd;
Nfcum=Ndcum+sum(nf);
a=[1 th(3,1:Nacum)];
c=[1 th(3,Nbcum+1:Nccum)];
d=[1 th(3,Nccum+1:Ndcum)];
if nu==0, b=0;,f=1;,end
b=zeros(nu,max(nb+nk));f=zeros(nu,max(nf));
s=1;,s1=1;
for k=1:nu
      if nb(k)>0,
      b(k,nk(k)+1:nk(k)+nb(k))=th(3,na+s:na+s+nb(k)-1);
      end
      if nf(k)>0,
      f(k,1:nf(k)+1)=[1 th(3,Ndcum+s1:Ndcum+nf(k)+s1-1)];
      else f(k,1)=1;,end
      s=s+nb(k);,s1=s1+nf(k);
end
