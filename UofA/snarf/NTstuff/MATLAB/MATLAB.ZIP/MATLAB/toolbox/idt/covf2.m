function R=covf2(z,M)
%COVF2   Computes covariance function estimates
%
%	R = covf2(Z,M)
%
%	The routine is a subroutine to COVF. See COVF for further
%	details.

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

[N,nz]=size(z);
z=[z;zeros(M,nz)];
j=[1:N];
for k=1:M
a=z(j,:)'*z(j+k-1,:);
R(:,k)=a(:)/N;
end
