function TH=iv(z,nn,NF,MF,maxsize,T,p)
%IV	Computes instrumental variable estimates for ARX-models.
%
%	TH = iv(Z,NN,NF,MF)
%
%	TH: returned as the IV-estimate of the ARX-model
%	A(q) y(t) = B(q) u(t-nk) + v(t)
%	along with relevant structure information. See HELP THETA for
%	the exact structure of TH.
%
%	Z : the output-input data Z=[y u], with y and u as column vectors.
%	For multi-input systems u=[u1 u2 ... un]
%
%	NN: NN=[na nb nk] gives the orders and delays associated with the
%	above model.
%	NF and MF define the instruments X as
%	NF(q) x(t) = MF(q) u(t)
%
% 	See IV4 for good, automatic choices of instruments.
%
%	TH=iv(Z,NN,NF,MF,maxsize,T)
%	allows access to some parameters associated with the algorithm.
%	See HELP AUXVAR for an explanation of these.

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

[Ncap,nz]=size(z); nu=nz-1;
na=nn(1);nb=nn(2:1+nu);nk=nn(2+nu:1+2*nu);n=na+sum(nb);
% 
% *** Some initial tests on the input arguments ***
maxsdef=idmsize(Ncap,n);

if nargin<7, p=1;end
if nargin<6, T=1;end
if nargin<5, maxsize=maxsdef;end
if T<0,T=1;end,if maxsize<0,maxsize=maxsdef;end

% *** construct instruments (see (7.111)-(7.112)) ***
 
     x=zeros(Ncap,1);
     for k=1:nu
         x=x+filter(MF(k,:),NF,z(:,k+1));
     end
%

TH=ivx(z,nn,x,maxsize,T,p);
if p~=0,TH(2,7)=3;end

