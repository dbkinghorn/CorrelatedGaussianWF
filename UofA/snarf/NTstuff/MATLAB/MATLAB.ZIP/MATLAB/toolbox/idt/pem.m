function th=pem(z,nn,maxiter,tol,lim,maxsize,Tsamp)
%PEM	Computes the prediction error estimate of a general linear model
%
%	TH=pem(Z,NN)
%
%	TH : returned as the estimated parameters of the model
%	A(q) y(t) = [B(q)/F(q)] u(t-nk) + [C(q)/D(q)] e(t)
%	along with estimated covariances and structure information. 
%	For the exact format of TH see HELP THETA.
%
%	Z : the output input data [y u], with y and u as column vectors
%	For multi-input systems, u=[u1 u2 ... un]
%
%	NN : the initial value and structure information given either as
%	NN = [na nb nc nd nf nk] which initiates the estimation with the
%	indicated orders in the above model, or as
%	NN = THI, with THI being a theta-matrix of the standard format. In the
%	latter case the minimization is initialized at THI.
%
%	Some parameters associated with the algorithm are accessed by
%	TH = pem(Z,NN,maxiter,tol,lim,maxsize,T)
%	See HELP AUXVAR for an explanation of these and their default values.

%	L. Ljung 10-1-86
%	Copyright (c) 1986-89 by the MathWorks, Inc.
%	All Rights Reserved.

%  *** Set up default values ***
[Ncap,nz]=size(z);
maxsdef=idmsize(Ncap);

if nargin<7, Tsamp=1;end
if nargin<6, maxsize=maxsdef;end
if nargin<5, lim=1.6;end
if nargin<4, tol=0.01;end
if nargin<3, maxiter=10;end

if Tsamp<0, Tsamp=1;end,if maxsize<0,maxsize=maxsdef;end,
if lim<0, lim=1.6;end, if tol<0, tol=0.01;end 
if maxiter<0, maxiter=10;end

% *** Do some consistency tests ***

[nr,cc]=size(nn); nu=nz-1;
if nz>Ncap, error('The data should be organized in column vectors!')
return,end
nb=nn(2:nz); if nz==1 
error('HINT: It is better to use ARMAX for a time series!')
return,end
if nr==1 & cc~=3+3*nu,
    disp('Incorrect number of orders specified:')
    disp('You should have nn=[na nb nc nd nf nk],')
    disp('where nb, nf and nk are row vectors of length equal to')
    disp(' the number of inputs'),error('see above')
return,end


%*** if nn has more than 1 row, then it is a theta matrix
%    and we jump directly to mincrit ***
%
if nr>1,th=nn;end


if nr==1
   th=inival(z,nn,maxsize,Tsamp);
end
 
% *** Display the initial estimate ***

clc, disp([' INITIAL ESTIMATE'])
disp(['Current loss:' num2str(th(1,1))])
disp(['th-vector'])
nu=th(1,3); n=sum(th(1,4:6+2*nu));
theta=th(3,1:n)'

if maxiter==0,return,end

% *** Minimize the prediction error criterion ***

th=mincrit(z,th,maxiter,tol,lim,maxsize,Tsamp);
