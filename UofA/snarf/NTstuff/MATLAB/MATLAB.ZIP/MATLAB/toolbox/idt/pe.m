function [e,v,w,a,b,c,d,f]=pe(z,th)
%PE	Computes prediction errors.
%
%	E = pe(Z,TH)
%
%	E : The prediction errors
%	Z : The output-input data Z=[y u]
%	TH: The model. Format as in HELP THETA
%
%	A more complete set of information associated with the model TH and the
%	data Z is obtained by
%
%	[E,V,W,A,B,C,D,F]=pe(Z,TH)
%
%	Here A,B,C,D,and F are the polynomials associated with TH and
%	W = B/F u and V = A[y - W].

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

nu=th(1,3);
[a,b,c,d,f]=polyform(th);[nu,nb]=size(b);[nu,nf]=size(f);
nc=length(c);nd=length(d);
ni=max([length(a)+nd-2 nb+nd-2 nf+nc-2]);
v=filter(a,1,z(:,1));
for k=1:nu, w(:,k)=filter(b(k,:),f(k,:),z(:,k+1));v=v-w(:,k);end

e=pefilt(d,c,v,zeros(1,ni));
