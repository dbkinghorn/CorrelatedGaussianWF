function [zf,thf]=idfilt(z,N,Wn,hs)
%IDFILT	Filters data through Butterworth filters
%
%	ZF = idfilt(Z,N,Wn)
%
%	Z  : The output-input data matrix Z = [Y U]. Multi-input systems are
%	     allowed
%	ZF : The filtered data. The columns of ZF correspond to those of Z.
%	N  : The order of the Butterworth filter to be used.
%	Wn : The cut-off frequency(ies) in fractions of the Nyquist frequency.
%            If Wn is a scalar a Low-Pass filter will be used.
%	     If Wn = [Wl Wh] a Band-Pass filter with pass-band  Wn will be used
%
%	With ZF = idfilt(Z,N,Wn,'high') or ZF = idfilt(Z,N,[Wl Wh],'stop')
%	High-Pass and Band-Stop filters will be used instead. (Same syntax as
%	for the command BUTTER)
%
%	With [ZF,THFILT] = idfilt(Z,N,Wn), also the filter will be returned
% 	in the THETA-format as THFILT. (See help theta).

%	L. Ljung 10-1-89
%	Copyright (c) 1989 by the MathWorks, Inc.
%	All Rights Reserved.
 
[ndat,nyu]=size(z);
if nargin==3, [b,a]=butter(N,Wn); else [b,a]=butter(N,Wn,'hey');end
for k=1:nyu
zf(:,k)=filtfilt(b,a,z(:,k));
end
if nargout>1, thf=mktheta(a,b);end

