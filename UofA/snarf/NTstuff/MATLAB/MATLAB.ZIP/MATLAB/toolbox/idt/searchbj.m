function [t1,e,el,vlc,w,V1,c,d,h,st]=searchbj(z,t,g,lim,V,nb,nc,nd,nf,nk,ni)
%SEARCHBJ searches for lower values of the prediction error criterion
%
%	[T1,E,EL,V,W,V1,C,D,H,ST] = searchbj(Z,T,G,LIM,V,NB,NC,ND,NF,NK)
%
%	The routine searches for a lower value than V of the prediction error
%	criterion for the Box-Jenkins model, starting at T, looking in the
%	G-direction. T1 is returned as the parameters that give a lower value V1
%	If no lower value is found, ST=1. C, D and H (=C*F) are the poly-
%	nomials associated with T1, and E, EL, V and W are filtered data
%	sequences. The routine is to be used as a subroutine to BJ. See
%	BJ for an explanation of the other arguments.

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.
 
l=0;,k=1;V1=V+1; n=nb+nc+nd+nf; st=0;
ll=ones(z(:,1))*lim;
while [V1 > V l<10],
t1=t+k*g; if l==9,t1=t;end
      c=fstab([1 t1(nb+1:nb+nc)']);t1(nb+1:nb+nc)=c(2:nc+1)';
      f=fstab([1 t1(nb+nc+nd+1:n)']);t1(nb+nc+nd+1:n)=f(2:nf+1)';
      h=conv(c,f);
      d=[1 t1(nb+nc+1:nb+nc+nd)']; 
      b=[zeros(1,nk) t1(1:nb)'];
     w=filter(b,f,z(:,2)); vlc=z(:,1)-w; e=pefilt(d,c,vlc,zeros(ni,1));
     el=max(min(e,ll),-ll);
     V1=e'*el/(length(e)-ni);

home, disp(int2str(l))
k=k/2;
l=l+1; if l==10,st=1;end
end
