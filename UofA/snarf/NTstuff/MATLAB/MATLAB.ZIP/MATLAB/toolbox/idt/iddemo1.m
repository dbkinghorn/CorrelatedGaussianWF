echo on,clc
%	This case study concerns data collected from a laboratory scale
%	"hairdryer". (Feedback's Process Trainer PT326; See also page
%	440 in Ljung,1987). The process works as follows: Air is fanned
%	through a tube and heated at the inlet. The air temperature is
%	measured by a thermocouple at the outlet. The input (u) is the 
%	voltage over the heating device, which is just a mesh of resistor
%	wires. The output is the outlet air temperature (or rather the
%	voltage from the thermocouple).

%	First load the data:

load dryer2

%	Vector y2, the output, now contains 1000 measurements of
%	temperature in the outlet airstream.  Vector u2 contains 1000
%	input data points, consisting of the voltage applied to the
%	heater. The input was generated as a binary random sequence
%	that switches from one level to the other with probability 0.2.
%	The sampling interval is 0.08 seconds.

pause % Press a key to continue
clc
%	Select the 300 first values for building a model:

z2 = [y2(1:300) u2(1:300)];

%	Plot the interval from sample 200 to 300:
%	(0.08 is the sampling interval -- for correct scales--)

pause,  idplot(z2,200:300,0.08), pause  % Press any key for plot.
clc
%	Remove the constant levels and make the data zero-mean:

z2 = dtrend(z2);

%	Compute a model with two poles, one zero, and three delays:

th = arx(z2,[2 2 3]);
th(1,2) = 0.08;      % Set the correct sampling interval.

%	Let's take a look at the model:

pause, present(th)     % Press any key to see model.

pause    % Press any key to continue.
clc
%	How good is this model? One way to find out is to simulate it
%	and compare the model output with measured output. We then
%	select a portion of the original data that was not used to build
%	the model, viz from sample 800 to 900:

u = dtrend(u2(800:900)); y = dtrend(y2(800:900));
yh = idsim(u,th);

pause   % Press any key for plot.
plot([yh y]), pause
clc
%	The agreement is quite good. Compute the poles and zeros of
%	the model:

zpth = zp(th);

pause, zpplot(zpth), pause    % Press any key for plot.
clc
%	Now compute the transfer function of the model:

gth = trf(th);

pause, bodeplot(gth), pause    % Press any key for Bode plot.
clc
%	We may compare this transfer function with what is obtained
%	by a non-parametric spectral analysis method:
%	(The negative arguments give default values of some variables.
%	0.08 is the sampling interval -- for correct frequency scales--
%	Trailing arguments with default values can be omitted.)

gs = spa(z2,-1,-1,-1,0.08);

%	Press a key for a comparison with the transfer function from the
%	parametric model.

pause, bodeplot([gs gth]), pause
clc
%	Finally we can plot the step response of the model. The model comes
%	with an estimate of its own uncertainty. In this case 10 different 
%	step responses are plotted, corresponding to models drawn from the
%	distribution of the true system (according to our model). Press a
%	key for the plot.

step = ones(30,1);

pause, idsimsd(step,th), pause  % Press any key for plot.
echo off
