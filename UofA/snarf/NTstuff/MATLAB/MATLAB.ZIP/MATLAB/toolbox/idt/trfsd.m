function [G,PV]=trfsd(th,nnu,w)
%TRFSD	Computes a model's transfer function, along with its standard deviation
%
%	G = trfsd(TH)  or  [G,NSP] = trfsd(TH)
%
%	TH: A matrix defining a model, as described in HELP THETA
%	G is returned as the transfer function estimate, and NSP (if specified)
%	as the noise spectrum, corresponding to the model TH. These matrices
%	contain also estimated standard deviations, calculated from the
%	covariance matrix in TH, and are  of the standard frequency function
%	format (see HELP FREQFUNC).If TH describes a time series, G is returned
%	as its spectrum.
%	
%	If the model TH has several inputs, G will be returned as the transfer
%	functions of selected inputs # j1 j2 .. jk by 
%	G = trfsd(TH,[j1 j2 ... jk])  [default is all inputs]. The functions 
%	are computed at 128 equally spaced frequency-values between 0(excluded)
%	and pi/T, where T is the sampling interval specified by TH. The func-
%	tions can be computed at arbitrary frequencies w (a row vector, gene-
%	rated e.g. by LOGSPACE) by G = trfsd(TH,ku,w). The transfer function
%	can be plotted by BODEPLOT. bodeplot(trfsd(TH),sd) is a possible 
%	construction. See also TRF and TRFCONT.

%	L. Ljung 7-7-87
%	Copyright (c) 1987 by the MathWorks, Inc.
%	All Rights Reserved.
 
T=th(1,2); nu=th(1,3);

% *** Set up default values ***

if nargin<3, w=pi*[1:128]/128/T;,end
if nargin<2 , nnu=1:th(1,3);end
if length(w)==1, if w<0, w=pi*[1:128]/128/T;end,end
if length(nnu)==1, if nnu<0, nnu=1:th(1,3);end,end

% *** Compute the model polynomials and form the basic
%      matrix of frequencies ***

[a,b,c,d,f]=polyform(th);
na=th(1,4);nb=th(1,5:4+nu);nc=th(1,5+nu);nd=th(1,6+nu);
nf=th(1,7+nu:6+2*nu);nk=th(1,7+2*nu:6+3*nu);
nm=max([length(a)+length(f)-1 length(b) length(c) length(d)+length(a)-1]);
   i=sqrt(-1);
OM=exp(-i*[0:nm-1]'*w*T);

% *** Compute the transfer function(s) GC=B/AF ***

sc=1;kf=0;ks=0;nrc=length(w)+1;
for k=nnu
    G(1,sc:sc+4)=[100+k,k,k+50,k+20,k+70];	
    G(2:nrc,sc)=w';
     gn=conv(a,f(k,:));
     GC=(b(k,:)*OM(1:length(b(k,:)),:))./(gn*OM(1:length(gn),:));
    G(2:nrc,sc+1)=abs(GC');
    G(2:nrc,sc+3)=phase(GC)'*180/pi;
% 
% *** Now compute the standard deviations ***
%
%	D3 = " dGC/dTHETA "
%
    D3=[((-GC./(a*OM(1:na+1,:)))'*ones(1,na)).*OM(2:na+1,:)',((GC./(b(k,:)*OM(1:length(b(k,:)),:)))'*ones(1,nb(k))).*OM(nk(k)+1:nk(k)+nb(k),:)',((-GC./(f(k,:)*OM(1:nf(k)+1,:)))'*ones(1,nf(k))).*OM(2:nf(k)+1,:)'];

    ll=[1:na,na+ks+1:na+ks+nb(k),na+ks+nb(k)+nc+nd+kf+1:na+ks+nb(k)+nc+nd+kf+nf(k)];
    ks=ks+nb(k);kf=kf+nf(k);
    P=th(3+ll,ll);
    D4=D3*P;
%
%   The matrix [C1 C3;conj(C3) C2] is the covariance matrix of [Re GC; Im GC]
%   according to Gauss' approximation formula
%    
    C1=sum((real(D4).*real(D3))')';
    C2=sum((imag(D4).*imag(D3))')';
    C3=sum((imag(D4).*real(D3))')';
%
%   Now translate these covariances to those of abs(GC) and arg(GC)
%
    G(2:nrc,sc+2)=sqrt((real(GC').^2).*C1+2*((real(GC')).*(imag(GC'))).*C3+(imag(GC').^2).*C2)./abs(GC');
    G(2:nrc,sc+4)=(180/pi)*sqrt((imag(GC').^2).*C1-2*((real(GC')).*imag(GC')).*C3+(real(GC').^2).*C2)./(abs(GC').^2);

sc=sc+5;
end
if nargout==1 & nu>0, return, end

% *** Compute the transfer function H=C/AD ***

hn=conv(a,d);
H=(c*OM(1:length(c),:))./(hn*OM(1:length(hn),:));
PV(1,1:3)=[100,0,50];
PV(2:nrc,1)=w';
PV(2:nrc,2)=(abs(H).^2)'*th(1,1);
%
% *** Compute the standard deviation of the spectrum ***
%
D3=[((-H./(a*OM(1:na+1,:)))'*ones(1,na)).*OM(2:na+1,:)',((H./(c*OM(1:nc+1,:)))'*ones(1,nc)).*OM(2:nc+1,:)',((-H./(d*OM(1:nd+1,:)))'*ones(1,nd)).*OM(2:nd+1,:)'];
ll=[1:na,na+sum(nb)+1:na+sum(nb)+nc+nd];
P=th(3+ll,ll);
D4=D3*P;
C1=sum((real(D4).*real(D3))')';
C2=sum((imag(D4).*imag(D3))')';
C3=sum((imag(D4).*real(D3))')';
alpha=(th(2,1)-th(1,1))/(th(2,1)+th(1,1));
d=na+sum(nb)+nc+nd+sum(nf); Ncap=d/alpha;

PV(2:nrc,3)=sqrt(2)*PV(2:nrc,2)/Ncap+2*th(1,1)*sqrt((real(H').^2).*C1+2*(real(H').*imag(H')).*C3+(imag(H').^2).*C2);
if nu==0, G=PV;end
