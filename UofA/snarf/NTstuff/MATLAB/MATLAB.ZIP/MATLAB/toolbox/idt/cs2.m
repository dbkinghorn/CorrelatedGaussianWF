echo on
% CASE STUDY # 2 ANALYSING A SIGNAL FROM A TRANSFORMER
% (If you encounter out-of-memory problems, check readme4.m)
%
% In this case study we shall consider the current signal from the
% R-phase when a  400 kV three-phase transformer is energized.
% The measurements were performed by Sydkraft AB in Sweden.

load current.mat

% The sampling interval is 1 ms.
% Let's take a look at the  data.
pause
idplot(i4r,-1,0.001),pause
% A close up:
pause
idplot(i4r,201:250,0.001),pause

% Let us first compute the periodogram:

ge = etfe(i4r,-1,-1,0.001);
pause
bodeplot(ge),pause

% We clearly see the dominant frequency component of 50 Hz, and its harmonics.
% The standard spectral analysis estimate gives

gs =  spa(i4r,-1,-1,-1,0.001);
pause
bodeplot([gs ge]),pause

% We see that a very large lag window will be required to see all the fine
% resonances of the signal. Standard spectral analysis does not work well.

% Let us instead compute spectra by parametric AR-methods. Models of 2nd
% 4th and 6th order are obtained by

t2=ar(i4r,2);t2(1,2)=0.001; % (The sampling interval)
t4=ar(i4r,4);t4(1,2)=0.001;
t6=ar(i4r,6);t6(1,2)=0.001;
g2=trf(t2);g4=trf(t4);g6=trf(t6);

% Let us take a look at the spectra:
pause
bodeplot([g2 g4 g6 ge]),pause

% We see that the parametric spectra are not capable of picking up the
% harmonics. The reason is that the AR-models attach too much attention to
% the higher frequencies, which are difficult to  model. (See Ljung (1987)
% Example 8.5)

% We shall therefore concentrate on the lower harmonics by prefiltering
% the data. We select a fifth order Butterworh filter with cut-off
% frequency at 175 Hz. (This should cover the 50, 100 and 150 Hz modes):

[bb,ba]=butter(5,175/500); % 500 Hz is the Nyquist frequency
i4rf = filtfilt(bb,ba,i4r);

t6f=ar(i4rf,6); t6f(1,2)=0.001;
g6f=trf(t6f);

% Let us now compare the spectrum obtained from the filtered data (6th
% order model) with that for unfiltered data (6th order) and with the
% periodogram:

pause
bodeplot([g6f g6 ge]),pause

% We see that with the filtered data we pick up the three first peaks in
% the spectrum quite well. 

% We can compute the numerical values of the resonances as follows:
% The roots of a sampled sinusoid of frequency om are located on
% the unit circle at exp(i*om*T), T being the sampling interval. We
% thus proceed as follows:
pause
a=polyform(t6f) % The AR-polynomial
omT=angle(roots(a))'
freqs=omT/0.001/2/pi'  % In Hz
pause

% We thus find the harmonics quite well.  We could also test how well
% the model t6f is capable of predicting the signal, say 50 ms ahead:

pause
compare(i4rf,t6f,50,201:500);pause

% If we were interested in the fourth and fifth harmonics (around
% 200 and 250 Hz) we would proceed as follows:

[bb,ba]=butter(5,[175 275]/500);
i4rff=filtfilt(bb,ba,i4r);
t8f=ar(i4rff,8); t8f(1,2)=0.001;
g8f=trf(t8f);
pause
bodeplot([ge g8f]),pause

% We thus see that with proper prefiltering, low order parametric models
% can be built that give good descriptions of the signal over desired
% frequency ranges.
