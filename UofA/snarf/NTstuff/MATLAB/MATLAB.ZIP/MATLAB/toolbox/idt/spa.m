function [GH,PV]=spa(z,M,W,maxsize,T)
%SPA	Performs spectral analysis.
%
%	G = spa(Z)  or	[G,NSP] = spa(Z)
%
%	Z : The output-input data Z=[y u], with y and u being column vectors.
%	For multi-input systems u=[u1 u2 ... un]. For time-series Z=y.
%	
%	If an input is present G is returned as the transfer function estimate,
%	and NSP (if specified) is the estimated noise spectrum. These func-
%	tions are of the standard frequency function format (see HELP FREQFUNC)
%	If NSP is specified also estimated standard deviations will be con-
%	tained in G and NSP. If Z is a time series G is returned as the esti-
%	mated spectrum, along with its estimated standard deviation.
%
%	A Hamming window of lag size min(length(Z)/10,30) is used, which can be
%	changed to M by
%	G = spa(Z,M)  or [G,NSP] = spa(Z,M)
%	The functions are computed at 128 equally spaced freqeuncy-values
%	between 0 (excluded) and pi. The functions can be computed at arbitrary
%	frequencies w (a row vector, generated e.g. by LOGSPACE) by
%	G = SPA(Z,M,w)  or  [G,NSP] = SPA(Z,M,w)
%	With G = spa(Z,M,w,maxsize,T) also the memory trade-off and the
%	sampling interval can be changed. See HELP AUXVAR.

%	L. Ljung 10-1-86
%	Copyright (c) 1986 by the MathWorks, Inc.
%	All Rights Reserved.

[Ncap,nz]=size(z);  i=sqrt(-1); dw=0;
if nz>Ncap, error(' The data should be entered in column vectors'),return,end
% *** Set up default values ***
maxsdef = idmsize(Ncap); %Mod 89-10-31
if nargin<5, T=1; end
if T<0, T=1; end
if nargin<2, M=min(30,floor(Ncap/10)); end %Mod 89-10-31
if M<0, M=min(30,floor(Ncap/10));end       %Mod 89-10-31
if nargin<4, maxsize=maxsdef; end
if maxsize<0, maxsize=maxsdef;end
if nargin<3, W=[1:128]*pi/128/T; dw=1;end
if length(W)==1, if W<0, W=[1:128]*pi/128/T; dw=1;end,end
if dw==1 & M>128, M=128; disp('M changed to 128');end
 
n=length(W);

% *** Compute the covariance functions ***

R=covf(z,M,maxsize);

% *** Form the Hamming lag window ***

pd=pi/(M-1);
window=[1 0.5*ones(1,M-1)+0.5*cos(pd*[1:M-1])];
if dw~=1 | nz>2, window(1)=window(1)/2;end

% *** For a SISO system with equally spaced frequency points
%     we compute the spectra using FFT for highest speed ***

noll=zeros(1,2*(n-M)+1);
order=2:n+1;
nfft = 2.^nextpow2(2*n);
if nz==2
    if dw==1
       rtem=R(4,:).*window;
       FIU=real(fft([rtem noll rtem(M:-1:2)],nfft));FIU=FIU(order);
       rtem=R(3,:).*window;
       FIYU=fft([R(2,1:M).*window noll rtem(M:-1:2)],nfft);
       FIYU=FIYU(order);
    end

 % *** For arbitrary frequency points we use POLYVAL for the
%      computation of spectra ****

    if dw~=1
        rtem=R(4,:).*window;
        FIU=2*real(polyval(rtem(M:-1:1),exp(-i*W*T)));
        rtem=R(2,:).*window; rtemp=R(3,:).*window;
        FIYU=polyval(rtem(M:-1:1),exp(-i*W*T)) + polyval(rtemp(M:-1:1),exp(i*W*T));
    end

% *** Now compute the transfer function estimate ***

       G=FIYU./FIU;
       GH(1,1:3)=[101,1,21];
       GH(2:n+1,1)=W'; GH(2:n+1,2)=abs(G'); 
       GH(2:n+1,3)=phase(G)'*180/pi;
       if nargout==1,return,end
end

% *** Compute the noise spectrum (= the output spectrum for
%     a time series) ***


rtem=R(1,:).*window;
   if dw==1
FIY=real(fft([rtem noll rtem(M:-1:2)],nfft)); FIY=FIY(order);
   end
   if dw~=1
            FIY=2*real(polyval(rtem(M:-1:1),exp(-i*W*T)));
   end
if nz==2, FFV=(FIYU.*conj(FIYU))./FIU;,else FFV=zeros(1,n);end
PV(1,1:3)=[100 0 50];
PV(2:n+1,1)=W'; PV(2:n+1,2)=abs(FIY-FFV)'; 
PV(2:n+1,3)=sqrt(0.75*M/Ncap*2)*PV(2:n+1,2);
if nz==2,GH(:,4)=GH(:,3);GH(1,1:5)=[101,1,51,21,71];
	GH(2:n+1,3)=sqrt(0.75*M/Ncap/2)*sqrt(PV(2:n+1,2)./FIU');
	 GH(2:n+1,5)=(180/pi)*GH(2:n+1,3)./GH(2:n+1,2);
end
if nz==1 , GH=PV;end

 if nz<3,return,end
%
% 
% *** Now we have to deal with the multi-input case ***
%
FI=zeros(nz,n);
for k=1:nz^2
    rtem=R(k,:).*window;
    FI(k,:)=polyval(rtem(M:-1:1),exp(-i*W*T));
end

for k=1:n
    FIZ=zeros(nz); FIZ(:)=FI(:,k); FIZ=FIZ+FIZ';
    GC(k,:)=FIZ(1,2:nz)/FIZ(2:nz,2:nz);
    PHIUINV=inv(FIZ(2:nz,2:nz));
    for kd=1:nz-1,diagCOV(k,kd)=PHIUINV(kd,kd);end
    PVC(k)=FIZ(1,1) -GC(k,:)*FIZ(2:nz,1);
end

PA=abs(PVC');
GH=zeros(n,5*(nz-1));
for k=1:5:(nz-1)*5
    ku=(k+4)/5;
    GH(1,[k:k+4])=[100+ku,ku,50+ku,20+ku,70+ku];
    GH(2:n+1,k)=W';
    GH(2:n+1,k+1)=abs(GC(:,(k+4)/5));
    GH(2:n+1,k+2)=sqrt(0.75*M/Ncap/2*(PA.*diagCOV(:,(k+4)/5)));
    GH(2:n+1,k+3)=phase(GC(:,(k+4)/5)')'*180/pi;
    GH(2:n+1,k+4)=(180/pi)*GH(2:n+1,k+2)./GH(2:n+1,k+1);
end
    
  if nargout==1, return,end
PV(1,1:3)=[100,0,50];
PV(2:n+1,1)=W';
PV(2:n+1,2)=PA;
PV(2:n+1,3)=sqrt(1.5*M/Ncap)*PA;

