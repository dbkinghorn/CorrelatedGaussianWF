clc,clg
echo on
%	The SYSTEM IDENTIFICATION TOOLBOX is an analysis module
%	that contains tools for building mathematical models of 
%	dynamical systems, based upon observed input-output data.  
%	The box contains both PARAMETRIC and NON-PARAMETRIC
%	MODELING methods.  

%	You can choose between the following case studies for
%	demonstrations:

%	1) Real data from a laboratory process. Simple models
%	   are built.

%	2) Simulation of data and test of several different methods.

%	3) Case study with focus on choice of model structure.

%	4) Spectrum estimation (Marple's test case)

%	5) Adaptive/Recursive algorithms.

%	6) Segmentation of data and models
%	Enter 1, 2, 3, 4, 5 or 6 accordingly. A zero will quit the demo.
echo off
k = input('Case study # ');
if k==1,iddemo1,end
if k==2,iddemo2,end
if k==3,iddemo3,end
if k==4,iddemo4,end
if k==5,iddemo5,end
if k==6,iddemo6,end

