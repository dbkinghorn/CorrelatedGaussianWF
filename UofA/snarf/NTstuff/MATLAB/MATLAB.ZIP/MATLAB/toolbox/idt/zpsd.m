function [zepo,Kg]=zpsd(th,ku)
%ZPSD	Computes zeros, poles, static gains and their standard deviations
%
%	[ZEPO,K] = zpsd(TH)
%
%	For a model defined by TH (in the format described by HELP THETA)
%	ZEPO is returned as the zeros and poles and their standard deviations.
%	Its first row contains integers with information about the column in
%	question. The last figure in this integer is the input number.
%	The first figure is interpreted as follows:
%	0 resp 2: zeros resp poles associated with the input in question
%	6 resp 8: standard deviation for the zeros resp poles
%	For complex conjugated pairs the second entry is the correlation 
%	coefficient between the real and imaginary parts.
%
%	The rows of K contain in order: the input number, the static gain, 
%	and its standard deviation.
%
%	With  [ZEPO,K] = zpsd(TH,KU) one obtains information associated with 
%	the input numbers given by the entries of the row vector KU.
%	The noise e is then regarded as input # 0. Default is KU=[1:# of inputs]
%	The information is best displayed by ZPPLOT. zpplot(zpsd(TH),sd) is a
%	possible construction.

%	L. Ljung 7-2-87
%	Copyright (c) 1987 by the MathWorks, Inc.
%	All Rights Reserved.

% *** Set up default values ***
nu=th(1,3);
if nu==0, kudef=0;else kudef=1:nu;end
if nargin<2, ku=kudef;end
if length(ku)==1, if ku<0, ku=kudef;end,end
if max(ku)>nu | min(ku)<0,error('Input indices outside # of inputs in theta')
return,end
[nt,ntt]=size(th);
Novar=0;
% Sort out the orders of the polynomials
    na=th(1,4); nb=th(1,5:nu+4);nc=th(1,nu+5);nd=th(1,nu+6);
    nf=th(1,nu+7:2*nu+6);
    ns=2*nu+3;
    Ncum=cumsum(th(1,4:3+ns));

if nt<3+Ncum(ns),disp('Covariance information not given in THETA'),
th(4:3+Ncum(ns),1:ntt)=zeros(Ncum(ns),ntt);Novar=1;end

% set up orders for the noise case
kzero=find(ku==0);kku=ku;if length(kzero)>0,kku(kzero)=nu+1;end
nb(nu+1)=nc;nf(nu+1)=nd;
nnb=max(nb(kku));nnf=max(nf(kku));if nnb==nc,nnb=nnb+1;end
nzp=max(nnb-1,nnf+na);

zepo=zeros(nzp+1,4*length(ku));
ll=1:na;a=[1 th(3,ll)];aa=0;
if na>0,Apoles=rotvar(a,th(3+ll,ll));
[aa,sl]=size(Apoles);end
    cc=1;
    for k=ku
    zepo(1,cc:cc+3)=[k 60+k 20+k 80+k];Kg(1,(cc+3)/4)=k;

    if na>0,zepo(2:aa+1,cc+2:cc+3)=Apoles;end

    if k~=0,
        llb=Ncum(k)+1:Ncum(k+1);
	llf=Ncum(nu+2+k)+1:Ncum(nu+3+k);
	b=th(3,llb);nbb=nb(k);nff=nf(k);
    else
        llb=Ncum(nu+1)+1:Ncum(nu+2);
	llf=Ncum(nu+2)+1:Ncum(nu+3);
	b=[1 th(3,llb)];nbb=nc;nff=nd;
    end
    f=[1 th(3,llf)];
        if length(b)>1,Bzeros=rotvar(b,th(3+llb,llb));%Corr 89-07-30
        [bb,sl]=size(Bzeros);zepo(2:bb+1,cc:cc+1)=Bzeros;end
	if length(llf)>0,Fpoles=rotvar(f,th(3+llf,llf));
        [ff,sl]=size(Fpoles);zepo(aa+2:aa+1+ff,cc+2:cc+3)=Fpoles; end
    bst=sum(b);ast=sum(a);fst=sum(f);
    kgg=bst/ast/fst;
    Kg(2,(cc+3)/4)=kgg;
    dKdth=[-ones(1,na)*kgg/ast ones(1,nbb)/ast/fst -ones(1,nff)*kgg/fst];
    Pk=dKdth*th(3+[ll llb llf],[ll llb llf])*dKdth';
    if length(Pk)>0, Kg(3,(cc+3)/4)=sqrt(Pk);else Kg(3,(cc+3)/4)=0;end
    cc=cc+4;
    end
