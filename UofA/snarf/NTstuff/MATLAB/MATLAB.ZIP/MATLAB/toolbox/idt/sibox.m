clc, help sitb
%The SYSTEM IDENTIFICATION TOOLBOX contains the following M-files:
%
%For simulation/prediction	idsim	mktheta	predict	compare
%For data handling:		dtrend	idfilt
%
%For nonparametric estimation:	covf	etfe	spa
%For parametric estimation:	ar	armax	arx	bj	iv	
%				ivar	iv4	ivx	oe	pem
%For recursive par est:		rarmax	rarx	rbj	roe	rpem	rplr
%For segmentation:		segment
%
%For model conversion:		contin	polyform	trf	trfcont	zp
%For model presentation:	bodeplot	idplot	nyqplot	present	zpplot
%For studying model uncertainty:	idsimsd	trfsd	zpsd
%
%For structure selection:	arxstruc	ivstruc	selstruc	struc
%For model validation:		idsim	pe	resid	compare	predict	
%
%Demos and case studies:	cs1	cs2	iddemo
%
%For more information, use help with the respective command.
