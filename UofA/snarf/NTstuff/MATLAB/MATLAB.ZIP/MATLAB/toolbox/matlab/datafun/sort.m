%SORT	Sort in ascending order.
%	SORT(X) sorts each column of X in ascending order. 
% 	When X is complex, the elements are sorted by ABS(X).
% 	[Y,I] = SORT(X) also returns an index matrix I.
%	If X is a vector, then Y = X(I).
%	If X is an m-by-n matrix, then
%	    for j = 1:n, Y(:,j) = X(I(:,j),j).
%
%	See also MIN, MAX.

%	Copyright (c) 1984-93 by The MathWorks, Inc.
%	Built-in function.
