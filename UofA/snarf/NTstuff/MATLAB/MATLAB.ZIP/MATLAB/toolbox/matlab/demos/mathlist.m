function mathlist
%MATHLIST List of mathematical examples.
%	MATHLIST, by itself, presents a list of mathematical examples.
%	Used by DEMO.

%	Copyright (c) 1984-93 by The MathWorks, Inc.
   
% Labels
labels = str2mat(...
   'Fourier Series', ...
   'Complex Mappings', ...
   'Tubular Knot', ...
   'The Peaks Function', ...
   'MathWorks''s Logo');

% Callbacks
callbacks = [ ...
   'fourier        '
   'cplxdemo       '
   'knot           '
   'peaks          '
   'membrane       '];

choices('MATH', 'Mathematical Examples', labels, callbacks);
