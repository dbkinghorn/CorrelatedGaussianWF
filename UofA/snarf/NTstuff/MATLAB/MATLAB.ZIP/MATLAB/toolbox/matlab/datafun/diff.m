function D = diff(A,nd,arg3)
%DIFF	Differentiate or difference.
%	DIFF may be called with either numeric or symbolic arguments.
%
%	For a numeric vector argument, DIFF computes differences.
%	DIFF(X), for a vector X, is [X(2)-X(1)  X(3)-X(2) ... X(n)-X(n-1)].
%	DIFF(X), for a matrix X, is the matrix of column differences,
%	   [X(2:n,:) - X(1:n-1,:)].
%	DIFF(X,n) is the n-th difference function.
%
%	For a symbolic (string) argument, DIFF uses the Maple Symbolic Toolbox
%	to compute derivatives.
%	DIFF(S) differentiates S with respect to its free variable.
%	DIFF(S,'v') differentiates S with respect to 'v'.
%	DIFF(S,n) and DIFF(S,'v',n) differentiate S n times.
%	DIFF, with no arguments, differentiates the previous expression.
%
%	Examples;
%	    With numeric arguments:
%	    h = .001; x = 0:h:pi;
%	    diff(sin(x.^2))/h is an approximation to 2*cos(x.^2).*x
%	    diff((1:10).^2) is 3:2:19
%
%	    With symbolic arguments and the Maple Symbolic Toolbox:
%	    diff('sin(x^2)') is '2*cos(x^2)*x'
%	    diff sin(x^2) is also '2*cos(x^2)*x'
%	    diff('t^6',6) is '720'.
%
%	See also GRADIENT, DEL2, INT, SYMVAR.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

if nargin == 0, A = '"'; end

if ~isstr(A)
   if nargin == 1, nd = 1; end
   for k = 1:nd
      [m,n] = size(A);
      if m == 1
          D = A(2:n) - A(1:n-1);
      else
          D = A(2:m,:) - A(1:m-1,:);
      end
   end

else
   % This branch requires the Maple Symbolic Toolbox
   if nargin <= 1
      eval('D = symdiff(A);')
   elseif nargin == 2
      eval('D = symdiff(A,nd);')
   elseif nargin == 3
      eval('D = symdiff(A,nd,arg3);')
   end
end
