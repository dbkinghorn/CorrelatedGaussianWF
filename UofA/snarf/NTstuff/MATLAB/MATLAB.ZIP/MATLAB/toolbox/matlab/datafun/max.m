%MAX	Largest component.
%	For vectors, MAX(X) is the largest element in X. For
% 	matrices, MAX(X) is a vector containing the maximum element
% 	from each column. [Y,I] = MAX(X) stores the indices of the 
% 	maximum values in vector I. MAX(X,Y) returns a matrix the
% 	same size as X and Y with the largest elements taken from X
% 	or Y. When complex, the magnitude MAX(ABS(X)) is used.
%
%	See also MIN, MEDIAN, MEAN, SORT.

%	Copyright (c) 1984-93 by The MathWorks, Inc.
%	Built-in function.
