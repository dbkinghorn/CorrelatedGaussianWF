%                        INTERACTIVE SIGNAL DEMO
%    
%    You are seeing discrete samples of a periodic waveform (above) and the 
%    absolute value of its discrete Fourier transform (DFT), obtained using
%    a fast Fourier transform (FFT) algorithm (below).  
%    In the lower plot, frequencies from 0 to 100 Hertz are displayed.
%    The DFT at negative frequencies is a mirror image of the DFT at positive
%    frequencies.  The sampling rate is 200 Hertz which means the "Nyquist
%    frequency" is 100 Hertz.  The DFT at frequencies above the Nyquist 
%    frequency is the same as the DFT at lower (negative) frequencies.
% 
%    Click and drag a point on the waveform displayed in the upper plot
%    to move that point to a new location, thereby setting a new fundamental
%    frequency and amplitude.
% 
%    Use the pop-up menu in the bottom left of the figure window to change 
%    the shape of the waveform.  The possible wave shapes are sinusoidal, 
%    square, and sawtooth.
% 
%    The fundamental frequency of the waveform is given in the editable
%    text box in the middle of the bottom row.  You can change this
%    fundamental frequency by clicking in the text box and editing
%    the number there, and then pressing RETURN.  The fundamental is also 
%    changed when the waveform is altered by clicking and dragging.
% 
%    If the Signal Processing Toolbox is installed, then the menu entitled
%    "Window" allows you to select a window function.  This window is 
%    multiplied by the time waveform prior to taking the DFT.  To display
%    the current window function in another figure window, select the menu 
%    item "Show window...".

%       Copyright (c) 1984-93 by The MathWorks, Inc.