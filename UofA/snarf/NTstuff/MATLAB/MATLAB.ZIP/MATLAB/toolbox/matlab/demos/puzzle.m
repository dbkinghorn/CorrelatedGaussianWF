function puzzle(n)
%PUZZLE	Mathematical riddles and MATLAB puzzles.
%	puzzle(n) is the n-th puzzle.
%	puzzle with no arguments picks a random one.
%	All the answers can be obtained with MATLAB commands
%	and functions, but we hope some are a challenge to find.
%
%	See also HINT.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

global ans
global HINTNUM

R = ['  Zs    rWi    i     eh    it?   kam    t     Q     ehc     l '
     'ocnaAeWnT?a deamttuocMte toB Ayaw i ny eheng odcMhh L  u ttaaa'
     'iWm  csi o  alyh   ntio hlado ?t ox  iws e f hpc ie am   lee  '
     'in    ts    ?a     h      (    is     W      f    rq    )t    '
     '   bt     ai    ao     s    ?W     ic    l     a      hn     g'
     'u   o au  s, d   lWe   nt ?  mmsm   paa    hr   cslt  eli    p'
     'cingeWnatw de ln uys pl tor oyawlhho  a engortaihh t? u taeaso'
     '  tK    jt     ao     h    ''s    eW?    is    un           hk '
     '    16    ?i     W           1.     t     a      0    5s     h'
     '  nudee  s y s ntamc aoho  oe ni  neott a WcM ip d  ?ouoch o t'
     'cta e ?tcaa  hed m inWdn me na  ctoi  vttho   ha  oVog   nn an'
     '         elob   fte   rWo   ns''   ?r u   vhi   taa   mMer   si'
     '   uss    '' m   oht   eta   eetr   f     iWr   ni    ?ePb   va'];

A = ['  sro   lZe   mo    .''nn'
     'c  eiaAca.nt pearbmoAgpl'
     'QAZ.  s cf  iohh  t d   '];

[m,k] = size(R);
if nargin == 0
    c = clock;
    n = fix(m*rem(c(6),1)+1);
end

disp(' ')
if (n >= 1) & (n <= m)
  HINTNUM = n;
  [ignore,j] = sort(sin(n*n+(1:k)));
  disp(R(n,j));
  
  if ((rem(n,3) == 0) & (n <= 9))
     n = n/3;
     [m,k] = size(A);
     [ignore,j] = sort(sin(n*n+(1:k)));
     ans = A(n,j);
  else
     % You'll have to go hunting for the other answers.  Good luck.
     ans = '';
  end
else
  disp(['puzzle(' int2str(rem(abs(n-1),m)+1) ')'])
end
disp(' ')
