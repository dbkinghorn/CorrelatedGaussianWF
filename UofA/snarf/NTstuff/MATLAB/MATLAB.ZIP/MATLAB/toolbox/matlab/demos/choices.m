function choices(name,header,labels,callbacks)
%CHOICES Create a list of choices with uicontrols and callbacks.
%	CHOICES('NAME',HEADER,BUTTONLABELS,CALLBACKS) creates
%	a window with registered name NAME.  The window contains
%	the string HEADER and buttons labeled with BUTTONLABELS.
%	These buttons register callback strings from CALLBACKS.
%	An additional button, labeled 'Close', is added to each
%	choicelist.
%
%	CHOICES is useful for constructing demo menus.
%	Use CHOICES in conjunction with CHOICEX, as in
%	this example.
%	    header = 'Easy Example';
%	    labels = str2mat('Choice 1','Choice 2','Choice 3');
%	    callbacks = str2mat('image(magic(1))','image(magic(2))', ...
%	        'image(magic(3))');
%	    choices('EXAMPLE', header, labels, callbacks);
%

%	Loren Shure, 8-14-92.
%	Copyright (c) 1984-93 by The MathWorks, Inc.

c = computer;
if ~isstr(name) | ~isstr(header) | ~isstr(labels) | ~isstr(callbacks)
	error('Requires string arguments.');
end
if nargin < 4
	error('Not enough input arguments.')
end
uicok = strcmp(c(1:2),'PC') | strcmp(c(1:2),'MA');
if isunix | ~uicok   % could be VMS as well
	uicok = strcmp(lower(get(0,'TerminalProtocol')),'x');
end
%can't use uicontrols -use menu stuff instead- this is for terminals -UNIX & VMS
if ~uicok
   labels = str2mat(labels,'Done');
   nl = size(labels,1);
   % build up menu string for evaluation
   % fix quotes, if there are any
   ss = deblank(labels(1,:));
   ss = ss(sort([1:length(ss) find(ss=='''')]));
   args = ['''',ss,''''];
   header = header(sort([1:length(header) find(header=='''')]));
   for i = 2:nl
      ss = deblank(labels(i,:));
      ss = ss(sort([1:length(ss) find(ss=='''')]));
      args = [args, ',''', ss,''''];
   end
   k = 1;
   while k > 0 & k < nl
      eval(['k = menu(''',header,''',', args,');']);
      if k == nl | k == 0
         return
      else
         eval(callbacks(k,:));
      end
   end
end
% can use uicontrols
global CHOICELIST
global CHOICEHANDLES
name = deblank(name);
if isempty(name)
	error('Requires non-blank string argument.')
end
% ensure list doesn't go into figure 1
figs = sort(get(0,'Children'));
openfigs = size(figs);
if ~isempty(figs)
   cf = gcf;
   if cf == 1
      cf = [];
   end
else
   cf = [];
end
fig1 = 1;
if isempty(figs)
	figs = figure('visible','off');
        fig1 = 0;
end
if figs(1) ~= 1
	figs = [figure('visible','off'); figs];
        fig1 = 0;
end
matchn = 0;
for i = 1:size(CHOICELIST,1)
	if strcmp(name,deblank(CHOICELIST(i,:)))
	    matchn = i;
	    break;
	end
end
if ~matchn
	CHOICEHANDLES = [CHOICEHANDLES; 0];
	if isempty(CHOICELIST)
	    CHOICELIST = name;
	else
	    CHOICELIST = str2mat(CHOICELIST, name);
	end
	matchn = size(CHOICEHANDLES,1);
else
	matchh = 0;
	for i = 1:size(figs,1)
	    if figs(i) == CHOICEHANDLES(matchn)
	        matchh = i;
	        break;
	    end
	end
	if matchh
	    figure(CHOICEHANDLES(matchn));
	    return
	end
end
xedge = 30;
ybord = 30;
width = 30;
yedge = 35;
height = 30;
if c(1:2) == 'PC'
      ha = axes('visible','off');
      hh = text(.1,.1,'Aq','units','pixel');yedge = get(hh,'extent');
      delete(hh);delete(ha);
      yedge = 1.6*yedge(4);
      height = 6*yedge/7;
end
avwidth = 7; % actually 6.8886 +/- 0.4887
imax = 1;
maxlen = size(labels,2);
twidth = 1.2*maxlen*avwidth;
% now figure out total dimensions needed so things can get placed in pixels
mwwidth = twidth + width + 2*xedge;
mwheight = (size(labels,1)+2)*yedge;
ss = get(0,'ScreenSize');
swidth = ss(3); sheight = ss(4);
left = 20;
bottom = sheight-mwheight-ybord;
rect = [left bottom mwwidth mwheight];
CHOICEHANDLES(matchn) = figure('Position',rect,'number','off', ...
       'name','','resize','off','colormap',[],'NextPlot','new',...
       'Menubar','none');
fg = CHOICEHANDLES(matchn);
fgs = CHOICEHANDLES(CHOICEHANDLES ~= fg);
set(fgs,'visible','off')
set(gca,'Position',[0 0 1 1]); axis off;
% Place header
hh=uicontrol(fg,'style','text','units','normal',...
             'position',[.05,.91,.9,.09 ],'string',header,...
             'Horizontal','center');
set(hh,'backg',get(gcf,'color'),'foreg',[1 1 1]-get(gcf,'color'))
% set up pre-amble so figure 1 is available for rendering in
sb = ['figure(1),set(1,''visible'',''on'');set(',int2str(fg),',''visible'',''off'');'];
se = [';global CHOICEHANDLES,set(CHOICEHANDLES(length(CHOICEHANDLES)),''visible'',''on'')'];
for ii=size(labels,1):-1:1
	i = size(labels,1) + 2 - ii;
	h1 = uicontrol(fg,'position',[xedge  (i-.5)*yedge width+twidth height]);
	set(h1,'callback',[sb callbacks(ii,:) se])
	set(h1,'string',['  ',deblank(labels(ii,:)), '  ']);
% left justify string inside button
	set(h1,'HorizontalAlignment','left');
end
% Create Close button
h1 = uicontrol(fg,'position',[xedge .5*yedge width+twidth height]);
set(h1,'string','  Close  ');
set(h1,'callback',['choicex(''',name,''')']);
set(h1,'HorizontalAlignment','left');
if ~isempty(cf)
   figure(cf)
end
