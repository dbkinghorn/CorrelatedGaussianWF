%MATDEMO Introduction to MATLAB.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

echo off
% Reset things before we get started.
clear
clc
format 
echo on

% Welcome to MATLAB. In the next few minutes, we hope to show you
% some of the power and flexibility offered by the MATLAB environment.
% This entire demonstration is written in MATLAB's fourth generation
% language, which gives you an idea of how easy it is to perform
% computations using MATLAB.
%
% Any line which is not preceded by a percent character, '%', is an
% actual MATLAB command.

% Press any key to continue...
pause
clc
% First, let's create a simple vector with 9 elements called 'a'.

a = [1 2 3 4 6 4 3 4 5 ]
% Notice how the results from each operation in MATLAB echo its result
% unless a semicolon is added at the end of each command.

% Press any key to continue...
pause
clc
% Now let's add 2 to each element of our vector, 'a', and store the
% result in a new vector. Notice how MATLAB requires no special handling
% of vector or matrix math.

b = a + 2
% Press any key to continue...
pause
clc
% Creating graphs in MATLAB is as easy as one command. Let's plot the
% result of our last vector addition.

plot(b)
grid
title('Press Any Key To Continue...')

% The "plot" statement graphs the elements of "b". The title was added
% with the "title" statement and the grid was drawn with "grid".

% Press any key to continue...
pause
clc
% MATLAB can make other graph types as well. 

bar(b)
xlabel('Sample #')
ylabel('Pounds')

% Notice the axis labels on the bar chart. Axis labels are drawn using
% the "xlabel" and "ylabel" commands. The bar chart was drawn using the
% "bar" function. 

% Press any key to continue...
pause
clc
% MATLAB can use symbols in plots as well. Here is an example using *'s
% to mark the points.  MATLAB offers a variety of other symbols and
% line types for use in graphs as well. 

plot(b,'*')
axis([0 10 0 10])

% Press Any Key To Continue...
pause
clf
clc
% One area in which MATLAB excels is matrix computation. Creating a
% matrix is as easy as making a vector, using semicolons (;) to separate
% the rows of a matrix. For example:

A = [1 2 0; 2 5 -1; 4 10 -1]
% Press any key to continue...
pause
clc
% We can easily find the transpose of the matrix 'A'. 

B = A'
% Press any key to continue...
pause
clc
% Now let's multiply these two matrices together. Note again that MATLAB
% doesn't require you to deal with matrices as a collection of numbers.
% MATLAB knows when you are dealing with matrices and adjusts your
% calculations accordingly.

C = A*B
% Press any key to continue...
pause
clc
% Instead of doing a matrix multiply, we can multiply the corresponding
% elements of two matrices or vector using the .* operator.

C = A.*B
% Press any key to continue...
pause
clc
% Let's find the inverse of a matrix...

X = inv(A)
% Now, let's illustrate the fact that a matrix times its inverse
% is the identity matrix.

I = inv(A)*A
% Press any key to continue...
pause
clc
% MATLAB has functions for nearly every type of common matrix calculation.
% There are functions to obtain eigenvalues ...

eig(A)
% as well as the singular value decomposition.

svd(A)
% Press any key to continue...
pause
clc
% The characteristic polynomial of a matrix A is
%     det(lambda*I - A)
% The "poly" function generates a vector containing the coefficients
% of the characteristic polynomial.

p = round(poly(A))
% Press any key to continue...
pause
clc
% We can easily find the roots of a polynomial using the "roots" function.

roots(p)
% These are actually the eigenvalues of the original matrix.

% Press any key to continue...
pause
clc
% MATLAB has many applications beyond just matrix computation.
% To convolve two vectors ...

q = conv(p,p)
% Press any key to continue...
pause

% Convolve again ...

r = conv(p,q)
% Press any key to continue...
pause
clc
% Two graphs of the result.

plot(r)

% Press any key to continue...
pause

bar(abs(r))

% Press any key to continue...
pause

clc
% At any time, we can get a listing of the variables we have stored in
% memory using the "who" or "whos" command.

whos
% Press any key to continue...
pause
clc
% You can get the value of a particular variable by typing its name.

A
% Press any key to continue...
pause
format compact
clc
% You can have more than one statement on a single line by separating
% each statement with commas or semicolons. Also note: if we don't
% assign a variable to store the result of an operation, the result
% is stored in a temporary variable called "ans".

sqrt(-1), log(-1), log(0)

% Since we separated the statements with commas, the result of each
% operation was echoed to the screen. As you can see, MATLAB easily
% deals with complex and infinite numbers in calculations.

% Press any key to continue...
pause
clc
% MATLAB has functions which make it ideal as a signal processing tool.
% Let's find the two dimensional FFT of a raised pedestal. First we'll
% make a 32x32 matrix full of zeroes, then fill a 3x3 block at the center
% of the matrix with ones.

A = zeros(32);
A(14:16,14:16) = ones(3);

% You can see how easily you can change a part of a matrix or vector
% without having to reenter the entire matrix. In case you can't visualize
% what we just made, let's look at the values of our matrix. 

% Press any key to get a quick look at the entire matrix ...
pause
format loose
colormap(cool)
clc
A
% It's understandable if you couldn't visualize what was going on with
% all of those numbers scrolling by. Let's make a three-dimensional
% plot of the matrix using the "mesh" command.

% Press any key to continue...
pause

mesh(A)

% Press any key to continue...
pause
clc
% Now let's take the two-dimensional FFT of our matrix and plot its
% magnitude.

y = fft2(A);
mesh(abs(y))

% Press any key to continue...
pause

clc
% In signal processing, it is often desirable to shift the quadrants
% of 2D FFTs so that the zeroth lag (DC) is at the center of the spectrum.
% We can do this in MATLAB using the "fftshift" function.

y = fftshift(y);
mesh(abs(y))

% Press any key to continue...
pause

clc
% Another interesting application is the Sobel edge-finding technique.
% We can use this to find the edges of a pedestal. We will use the same
% method to make the matrix as we did in the previous 2D FFT demo.

A = zeros(32);
A(4:28,4:28)=ones(25);
mesh(A)

% Press any key to continue...
pause

clc
% Find the horizontal edges by convolving our data with the Sobel
% edge detector and plot the result.

s = [1 2 1; 0 0 0; -1 -2 -1];
h = conv2(A,s);
mesh(h)

% Press any key to continue...
pause
clc
% Now let's find the vertical edges.

v = conv2(A,s');
z = sqrt(h.^2+v.^2);
mesh(z);
title('Horizontal and Vertical Edges')

% Press any key to continue...
pause

clc
% MATLAB also allows you to create and analyze functions easily. For example,
% here is a function we have saved as a MATLAB M-file. M-files are just ASCII
% files which contain MATLAB commands. M-files can return values, as functions,
% or behave just like simple scripts. Let's take a look at our "humps" function.

type humps
% Press any key to continue...
pause

clc
% Now suppose we want to see what "humps" looks like in the range -1 <= x <=2.
% First we'll create a vector called 'x', with values from -1 to 2 in steps
% of .02. Then, we'll plot the values of x vs. humps(x).

x = -1:.02:2;
plot(x,humps(x))
title('Plot of humps(x)')

pause

clc
% We can find the numerical integral of humps(x) using the "quad" function.
% In this case we'll find the integral over the range of 0 <= x <= 1.
% We will also use two optional features in "quad" which will allow us to
% set the relative tolerance of our integration to .001, and show a plot
% of the points chosen by the numerical integration.

q = quad('humps',0,1,.001,1);
title('Evaluation points for humps(x) integration.')

pause

% The result of the integral is

q

% Press any key to continue...
pause
clc
% Thank you for participating in this introduction to MATLAB.
%
% To see a list of other demos and examples that might interest you,
% type
%
%    help demos
% 
% And, if you haven't already done so, simply type
%
%    demo
%
% to obtain the demo menu.

