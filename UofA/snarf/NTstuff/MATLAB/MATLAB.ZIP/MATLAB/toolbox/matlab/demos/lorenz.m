%LORENZ	Plot the orbit around the Lorenz chaotic attractor.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

clf
clc
echo on

% Solve the ordinary differential equation describing the
% Lorenz chaotic attractor.  The equations are defined in
% an M-file, lorenzeq.m.

type lorenzeq

% Press any key to continue after pauses.
pause

clc

% The values of the global parameters are

global SIGMA RHO BETA
SIGMA = 10.;
RHO = 28.;
BETA = 8./3.;

pause

% The graphics axis limits are set to values known to contain the solution.

axis([10 40 -20 20 -20 20])
view(3)
hold on
title('Lorenz Attractor')

pause

clc

% The orbit ranges chaotically back and forth around two different points,
% or attractors.  It is bounded, but not periodic and not convergent.
% The numerical integration, and the display of the evolving solution,
% are handled by the function ODE23P.
%
% This will run for quite a while; hit <ctrl-C> to break out sooner.

y0 = [0 0 eps];
tfinal = 100;
y = ode23p('lorenzeq',0,tfinal,y0) 
echo off
