function result = bench(ntimes)
%BENCH	MATLAB Benchmark
%
%	BENCH times five different MATLAB tasks and compares the
%	execution speed with the speed of several other computers.
%	The problem sizes are chosen so that each task requires about
%	one second on a Sun SPARC-2. The five tasks are:
%	
%	 Loops     For loops and "zeros".   Strings and "malloc".
%	 LU        MATLAB's "LINPACK".      Primarily floating point.
%	 Sparse    Solve sparse system.     Mixed integer and floating point.
%	 3-D       Surf plot of "peaks".    3-D polygonal fill graphics.
%	 2-D       plot(fft(eye)).          2-D line drawing graphics.
%
%	BENCH runs each of the five tasks 10 times.
%	BENCH(N) runs each of the five tasks N times.
%	TIMES = BENCH(N) returns a vector with the five execution times.
%	On a Sun SPARC-2, BENCH(N) would nominally produce [N N N N N].
%	Smaller values are faster, larger are slower.
%
%	A final bar chart shows speed, which is inversely proportional to 
%	time.  Here, longer bars are faster machines, shorter bars are slower.
%
%	CAVEAT: Fluctuations of five or 10 percent in the measured times
%	of repeated runs on a single machine are not uncommon.
%	Your own mileage may vary.

%	C. Moler, 1-5-92, 8-26-92, 11-23-92.
%	Copyright (c) 1984-93 by The MathWorks, Inc.


machines = str2mat( ...
   'HP 720', ...
   'HP 710', ...
   'Iris Indigo', ...
   'IBM RS/6000, 320', ...
   'SPARC-2',...
   'SPARC-IPC',...
   'Tadpole', ...
   'SPARC-1');

times = [ ...
  3.05 3.87 5.36 5.29 4.48;
  5.26 5.62 5.62 9.14 6.36;
  6.79 11.1 8.13 10.2 9.16; 
  12.8 4.49 8.78 17.6 14.5;
  10.0 10.0 10.0 10.0 10.0;
  15.7 21.6 19.3 19.0 19.9;
  12.4 15.4 15.2 26.5 23.0;
  16.6 24.1 20.3 30.5 28.6];


help bench

clf
set(gcf,'pos','default')

if nargin < 1, ntimes = 10; end

% The problem size, n, for each task has been chosen 
% so that the task takes about one second on a SPARC-2.

% Loops

figtext(.33,.5,'MATLAB Benchmark')
figtext(.40,.42,'Loops')
axis off
drawnow

n = 375;
A = [];
r = 1;
tic
for k = 1:ntimes
   for j = 1:n
      clear A;
      r = rem(pi*r,1);
      m = fix(100*r);
      A = zeros(m,m);
   end
end
t(1) = toc

% LU

clf
figtext(.33,.5,'MATLAB Benchmark')
figtext(.45,.42,'LU')
axis off
drawnow

n = 167;
A = randn(n,n);
tic
for k = 1:ntimes
   lu(A);
end
t(2) = toc

% Sparse

clf
figtext(.33,.5,'MATLAB Benchmark')
figtext(.42,.42,'Sparse')
axis off
drawnow

n = 36;
A = delsq(numgrid('L',n));
b = sum(A)';
spparms('autommd',0);
tic
for k = 1:ntimes
   x = A\b;
end
t(3) = toc

% 3-D

clf
n = 24;
[x,y,z] = peaks(n);
ax = [-3 3 -3 3 -8 8];
tic
for k = 1:ntimes
   surf(x,y,z);
   axis(ax);
   drawnow;
end
t(4) = toc

% 2-D

clf
n = 52;
tic
for k = 1:ntimes
   plot(fft(eye(n)));
   axis('square')
   drawnow;
end
t(5) = toc

% Compare with other machines.

machines = str2mat(machines,'This computer');
times = [times; 10/ntimes*t];
totals = sum(times')';
speeds = 50*100./totals;
[speeds,k] = sort(speeds);
machines = machines(k,:);
times = times(k,:);
m = size(machines,1);

% Horizontal bar chart
% Highlight this machine with another color.

me = find(k==length(k));
clf
[x,y] = bar(speeds);
plot(y,x,'y');
title('Relative Speed')
hold on
k = 5*me;
plot(y(k-4:k),x(k-4:k),'m')

% Add machine names

for k = 1:m
   text(5,k,machines(k,:))
end
hold off

% Display report in new figure

figh = figure('pos',get(gcf,'pos')+[100 -300 0 0]);
drawnow
x0 = .10;
y0 = .85;
dx = .10;
dy = .06;
figtext(x0+.30,y0,'Execution Time')
x = x0+5*dx/2;
y = y0-3*dy/2;
tasks = [' Loops';'    LU';'Sparse';'   3-D';'   2-D'];
for j = 1:5
   figtext(x,y,tasks(j,:))
   x = x + dx;
end
drawnow
for i = 1:m
   y = y0-(m-i+5/2)*dy;
   x = x0;
   h = figtext(x,y,machines(i,:));
   if i == me, set(h,'color','m'), end
   x = x + 5*dx/2;
   for j = 1:5
      h = figtext(x,y,sprintf('%6.1f',times(i,j)));
      if i == me, set(h,'color','m'), end
      x = x + dx;
   end
   drawnow
end

% Pause before cleaning up.

disp(' ')
disp('Pause.  Touch any key to close the report and finish.')
disp(' ')
pause
close(figh)
clf

% Output if requested.
if nargout == 1, result = t; end

