function H = figtext(x,y,T,justify)
%FIGTEXT Place text in figure window.
%	FIGTEXT(x,y,T) writes T, left justified, with the lower left
%	corner at figure normalized coordinates (x,y).
%	FIGTEXT(x,y,T,'center') and FIGTEXT(x,y,T,'right') are also possible.
%	H = FIGTEXT(...) returns a vector of handles to the lines of text.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

if nargin < 4, justify = 'left'; end

kids = get(gcf, 'children');
axis_exists = 0;
for i=1 : size(kids,1)
   if strcmp (get(kids(i), 'type') , 'axes')
      if (get(kids(i), 'pos') == [0 0 1 1])
            axes(kids(i));
            axis_exists = 1;
      end;
   end;
end;
if (axis_exists == 0)
	axes('pos', [0 0 1 1], 'vis', 'off');
end;

dely = .04;
[m,n] = size(T);
for k = m:-1:1
   h(k) = text(x,y,T(k,:),'horiz',justify, 'erase', 'back');
   y = y + dely;
end

if nargout > 0
   H = h';
end
