function z = cross(x,y)
%CROSS	Vector cross product.
%	z = cross(x,y).  x and y are usually vectors with 3 components.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

if (length(x) == 3) & (length(y) == 3)
   I = eye(3,3);
   z = x;
   for j = 1: 3
      z(j) = det([x(:) y(:) I(:,j)]);
   end
elseif isstr(x) & isstr(y)
   z = ['norm(' x ') * norm(' y ') * sin(angle(' x ',' y '))'];
end
