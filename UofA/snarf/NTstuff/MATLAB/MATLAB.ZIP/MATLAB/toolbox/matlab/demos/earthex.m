%EARTHEX Used by EARTHMAP to generate relief view.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

disp('This takes about 3 minutes on a SPARC 2 ...')
tic

% Set everything below sea level to zero.
tland = topo.*(topo >= 0);

% Lighting data from two directions is averaged 
% to provide the illusion of a relief map.
az = 45;
el = 10;
disp('First lighting calculation ...')
cdata = get(surfl(tland,[az,el]),'cdata');
disp('Second lighting calculation ...')
cdata = (cdata+get(surfl(tland,[-az,el]),'cdata'))/2;

% Texture map the lighting data onto the sphere.
disp('Texture mapping ...')
clf
h = surface(x,y,z,'facecolor','texture','cdata',cdata); 
view(3)
axis square
colormap(topomap2)
toc
