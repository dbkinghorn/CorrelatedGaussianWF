% 
%                        INTERACTIVE SIGNAL DEMO - 2
%    
%    You are seeing a representation of a continuous function (above) and its
%    Fourier transform (below).  The function is a Gaussian pulse multiplied,
%    or "modulated," by a cosine of a particular frequency.  This demonstration
%    allows you to change the modulation frequency, as well as the amplitude of
%    the function, and immediately observe those changes in both domains.
% 
%    Click and drag a point on the waveform displayed in either plot
%    to move that point to a new location, thereby setting a new modulation
%    frequency and amplitude.
% 
%    The modulation frequency of the waveform is specified in the editable
%    text box beneath the plots.  This number is updated when you click and 
%    drag either waveform.  You can also change the modulation frequency by 
%    clicking in the text box and editing the number there, and then pressing 
%    the RETURN key or moving the pointer outside of the box.  The sliding
%    control above the text box monitors changes in the modulation
%    frequency.  By clicking and dragging the control you can set the 
%    modulation frequency.

%       Copyright (c) 1984-93 by The MathWorks, Inc.