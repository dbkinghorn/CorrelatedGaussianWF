function [amp1,freq1]=mmove2(fixed_x,fixed_y,amp,freq,time_line,freq_line,...
        freq_field,freq_slider,min_amp,max_amp,min_freq,max_freq,ax_time)
% function mmove2
%
%  	CallBack for WindowButtonMotionFcn, signal demo 2

% 	TPK 11/3/92
% 	TPK 12/4/92  made it a function
%	(c) Copyright 1984-93, by The MathWorks, Inc.

    pt=get(gca,'currentpoint');
    x=pt(1,1);
    y=pt(1,2);

    amp1=y/fixed_y*amp;
    if (amp1>max_amp ),
       amp1=max_amp ;
    end;
    if (amp1<min_amp ),
       amp1=min_amp ;
    end;
    if (ax_time==gca),
        freq1=fixed_x/x*freq;
    else
        freq1=x/fixed_x*freq;
    end;
    if (freq1>max_freq),
       freq1=max_freq;
    end;
    if (freq1<min_freq),
       freq1=min_freq;
    end;

    [t,f,w,F]=tffunc(amp1,freq1);
    set(time_line,'YData',f);
    set(freq_line,'YData',F);
    set(freq_field,'String',num2str(freq1));
    set(freq_slider,'Value',freq1);

