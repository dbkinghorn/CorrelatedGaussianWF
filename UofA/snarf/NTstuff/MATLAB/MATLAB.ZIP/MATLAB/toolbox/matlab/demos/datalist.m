function datalist
%DATALIST List of data analysis examples.
%	DATALIST, by itself, presents a list of data analysis examples.
%	Used by DEMO.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

% Labels
labels = str2mat(...
   'Spectral Analysis', ...
   'Earthquake Example', ...
   'Discrete Transform',...
   'Continuous Transform',...
   'Census Example', ...
   'Graphics Input', ...
   'Sunspot Data');

% Callbacks
callbacks = [ ...
    'fftdemo        '
    'quake          '
    'sigdemo1       '
    'sigdemo2       '
    'census         '
    'spline2d       '
    'sunspots       '];

choices('DATA', 'Data Analysis', labels, callbacks);
