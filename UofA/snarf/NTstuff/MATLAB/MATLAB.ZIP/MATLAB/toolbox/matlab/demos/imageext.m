function imageext()
%IMAGEEXT	Demonstrate MATLAB V4's image capability.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

if ~(exist('gatlin.mat')==2)
   return
end
global IM_FIG;
if ~isempty(IM_FIG)
	set(0,'CurrentFigure',IM_FIG);
	return
end
global IM_NAMES
IM_NAMES = ['flujet  '
         'spine   '
         'gatlin  '
         'durer   '
         'detail  '
         'cape    '
         'clown   '
         'earth   '
         'mandrill'
         'spiral  '];
nimages = size(IM_NAMES,1);
image_button_labels = str2mat('NCSA Fluid Jet', ...
         'Human Spine', ...
         'Gatlinburg, 1964', ...
         'Durer Etching', ...
         'Durer Detail', ...
         'Cape Cod');
image_button_labels = str2mat(image_button_labels, ...
         'Clown', ...
         'Earth', ...
         'Mandrill', ...
         'Color Spiral');

color_button_labels = [ ...
         'hsv     ',
         'hot     ',
         'pink    ',
         'cool    ',
         'bone    ',
         'prism   ',
         'flag    ',
         'gray    ',
         'rand    ',
         'spin    ',
         'revert  '];
nil = size(image_button_labels,1);
nic = size(color_button_labels,1);
if nil > nic
	color_button_labels = str2mat(color_button_labels,'Close');
	nic = nic + 1;
	where_close = 'color';
else
	image_button_labels = str2mat(image_button_labels,'Close');
	nil = nil + 1;
	where_close = 'image';
end
maxbut = max(nil,nic);
IM_FIG = figure('units','normal','position',[.13 .33 .65 .6]);
revert = get(IM_FIG,'colormap');

% place image menu buttons on left side
toti = 1.5*nil+.5;
but_h = .8/nil;
widi = 0.2;
hi = [];
for k = 1:nil
   pos = [0.01 (1.5*(k-1)+.25)/toti widi but_h];
   hi = [uicontrol(IM_FIG,'units','normal','pos',pos) ; hi];
end

% place color menu buttons on right side
totc = 1.5*nic+.5;
widc = 0.08;
hc = [];
for k = 1:nic
   pos = [0.99-widc (1.5*(k-1)+.25)/totc widc but_h];
   hc = [uicontrol(IM_FIG,'units','normal','pos',pos) ; hc];
end

if strcmp(where_close,'image')
   hcl = hi(length(hi));
   hi = hi(1:length(hi)-1);
   image_button_labels(nil,:) = [];
   nil = nil-1;
else
   hcl = hc(length(hc));
   hc = hc(1:length(hc)-1);
   color_button_labels(nic,:) = [];
   nic = nic-1;
end

% set close callback
s = ['global IM_FIG;close(IM_FIG),clear global IM_FIG IM_NAMES IM_AXIS;'];
s = [s 'clear IM_AXIS IM_FIG IM_NAMES;'];
if strcmp(where_close,'image')
   set(hcl,'string',' Close','horiz','left','callback',s);
else
   set(hcl,'string',' close','horiz','center','callback',s);
end
for k=1:nic
    col = color_button_labels(k,:);
    col(col==' ') = [];
    coll = col;
    if strcmp(col,'rand'),col='rand(size(get(gcf,''''colormap''''),1),3)'; end
    if strcmp(col,'spin')
        s = ['global IM_FIG,cf=gcf;set(0,''CurrentFigure'',IM_FIG),',...
            'point = get(IM_FIG,''pointer'');',...
            'set(IM_FIG,''pointer'',''watch'');drawnow;',...
            'spinmap;set(IM_FIG,''pointer'',point);'];
    else
       s = ['global IM_FIG, cmap = ''',col,''';',...
            'cf=gcf;set(0,''CurrentFigure'',IM_FIG);',...
            'point = get(IM_FIG,''pointer'');',...
            'set(IM_FIG,''pointer'',''watch'');drawnow;',...
            'cmap(cmap=='' '')=[];eval([''cm='' cmap '';'']);',...
            'set(IM_FIG, ''mincolormap'',size(cm,1),''colormap'',cm);',...
            'set(IM_FIG,''pointer'',point);',...
            'if cf~=IM_FIG,set(0,''CurrentFigure'',cf),end;'];
    end
    set(hc(k),'string',coll,'horiz','center','callback',s);
end
for k = 1:nil-1
    s = ['global IM_AXIS IM_FIG IM_NAMES IM_CAPT;cf=gcf;',...
        'set(0,''currentfigure'',IM_FIG);',...
        'set(IM_FIG,''CurrentAxes'',IM_AXIS);',...
        'cla; drawnow;',...
        'point = get(IM_FIG,''pointer'');',...
        'set(IM_FIG,''pointer'',''watch'');drawnow;',...
        'file = ''',IM_NAMES(k,:),''';file(file == '' '') = [];',...
        'load(file);',...
        '[m,n] = size(X); image(X);axis off;A = [n/m 1];',...
        'set(IM_AXIS,''aspect'',eval(''A''));',...
        'set(IM_FIG,''mincolormap'',size(map,1),''colormap'',map);',...
        'IM_CAPT = imtext(.5,1.035,caption);',...
        'revert = map;' ...
        'set(IM_FIG,''pointer'',point);',...
        'drawnow,if cf~=IM_FIG,set(0,''CurrentFigure'',cf),end,'];
    set(hi(k),'string',[' ',deblank(image_button_labels(k,:))],'horiz','left','callback',s);
end

% now do color spiral
s = ['global IM_AXIS IM_FIG IM_NAMES;cf=gcf;set(0,''currentfigure'',IM_FIG);',...
    'point = get(IM_FIG,''pointer'');set(IM_FIG,''pointer'',''watch'');',...
    'drawnow,set(IM_FIG,''CurrentAxes'',IM_AXIS);',...
    'm = 16; X = [spiral(m)-1 zeros(m,1); zeros(1,m+1)]; pcolor(X);',...
    'map = hsv; set(IM_FIG,''mincolormap'',size(map,1),''colormap'',map);',...
    'revert = map; drawnow,set(IM_FIG,''pointer'',point);',...
    'if cf~=IM_FIG,set(0,''CurrentFigure'',cf),end,'];
set(hi(nil),'string',[' ',deblank(image_button_labels(nil,:))],'horiz','left','callback',s);

% set default axes location
IM_AXIS = axes('pos',[1.2*(0.01+widi) .11 .9*(.98-widi-widc) .81]);
global IM_AXIS;
axis off
rect = [.25 .95 .5 .04];
uicontrol(IM_FIG,'style','text','units','normal','position',rect,'string',...
         'Images and Color Maps','backgroundcolor',get(gcf,'color'), ...
         'clipping','off', 'foregroundcolor', get(IM_AXIS,'xcolor'));

