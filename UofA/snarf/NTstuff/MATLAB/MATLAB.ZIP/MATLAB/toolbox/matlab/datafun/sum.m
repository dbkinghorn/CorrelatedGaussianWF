%SUM	Sum of the elements.
%	For vectors, SUM(X) is the sum of the elements of X.
% 	For matrices, SUM(X) is a row vector with the sum over
% 	each column. SUM(DIAG(X)) is the trace of X.
%
%	See also PROD, CUMPROD, CUMSUM.

%	Copyright (c) 1984-93 by The MathWorks, Inc.
%	Built-in function.
