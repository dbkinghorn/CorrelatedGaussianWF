% Inner loop for life.

 %       Copyright (c) 1984-93 by The MathWorks, Inc.

while t < tfinal
   t = t+1;

   % How many of eight neighbors are alive.
   N = X(n,:) + X(s,:) + X(:,e) + X(:,w) + ...
       X(n,e) + X(n,w) + X(s,e) + X(s,w);

   % A live cell with two live neighbors, or any cell with three
   % neigbhors, is alive at the next time step.
   X = (X & (N == 2)) | (N == 3);

   % Update plot.
   [i,j] = find(X);
   set(plothandle,'xdata',i,'ydata',j)
   drawnow
end
