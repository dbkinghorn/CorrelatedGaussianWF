%MIN	Smallest component.
%	For vectors, MIN(X) is the smallest element in X. For
% 	matrices, MIN(X) is a vector containing the minimum element
% 	from each column. [Y,I] = MIN(X) stores the indices of the 
% 	minimum values in vector I. MIN(X,Y) returns a matrix the
% 	same size as X and Y with the smallest elements taken from X
% 	or Y. When complex, the magnitude MIN(ABS(X)) is used.
%
%	See also MAX, MEDIAN, MEAN, SORT.

%	Copyright (c) 1984-93 by The MathWorks, Inc.
%	Built-in function.
