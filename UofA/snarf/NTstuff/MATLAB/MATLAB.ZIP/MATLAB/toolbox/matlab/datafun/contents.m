% Data analysis and Fourier transform functions.
%
% Basic operations.
%   max         - Largest component.
%   min         - Smallest component.
%   mean        - Average or mean value.
%   median      - Median value.
%   std         - Standard deviation.
%   sort        - Sort in ascending order. 
%   sum         - Sum of elements.
%   prod        - Product of elements.
%   cumsum      - Cumulative sum of elements.
%   cumprod     - Cumulative product of elements.
%   trapz       - Numerical integration using trapezoidal method.
%
% Finite differences.
%   diff        - Difference function and approximate derivative.
%   gradient    - Approximate gradient.
%   del2        - Five-point discrete Laplacian.
%
% Correlation.
%   corrcoef    - Correlation coefficients.
%   cov         - Covariance matrix.
%   subspace    - Angle between subspaces.
%
% Filtering and convolution.
%   filter      - One-dimensional digital filter.
%   filter2     - Two-dimensional digital filter.
%   conv        - Convolution and polynomial multiplication.
%   conv2       - Two-dimensional convolution.
%   deconv      - Deconvolution and polynomial division.
%
% Fourier transforms.
%   fft         - Discrete Fourier transform.
%   fft2        - Two-dimensional discrete Fourier transform.
%   ifft        - Inverse discrete Fourier transform.
%   ifft2       - Two-dimensional inverse discrete Fourier transform.
%   abs         - Magnitude.
%   angle       - Phase angle.
%   unwrap      - Remove phase angle jumps across 360 degree boundaries.
%   fftshift    - Move zeroth lag to center of spectrum.
%   cplxpair    - Sort numbers into complex conjugate pairs.
%   nextpow2    - Next higher power of 2.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

