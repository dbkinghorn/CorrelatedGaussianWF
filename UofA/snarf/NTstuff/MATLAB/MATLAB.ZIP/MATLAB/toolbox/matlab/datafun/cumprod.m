%CUMPROD Cumulative product of the elements.
%	For vectors, CUMPROD(X) is the cumulative product of the 
% 	elements of X.  For matrices, CUMPROD(X) is a matrix
% 	containing the cumulative products over each column.
%
%	See also CUMSUM, SUM, PROD.

%	Copyright (c) 1984-93 by The MathWorks, Inc.
%	Built-in function.
