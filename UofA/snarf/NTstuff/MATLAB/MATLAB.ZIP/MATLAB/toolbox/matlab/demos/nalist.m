%NALIST	Numerical analysis demonstrations.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

echo off
clc
disp('MATLAB itself handles the linear side of numerical analysis.  A')
disp('collection of M-files we call "function functions" extends the')
disp('capabilities of MATLAB into the nonlinear aspects of numerical')
disp('analysis.  The primary tools include:')
disp(' ')
disp('  * Numerical solution of ordinary differential equations using')
disp('    automatic step size Runge-Kutta methods. (ODE45 and ODE23)')
disp(' ')
disp('  * Numerical evaluation of integrals using a recursive, adaptive')
disp('    Simpson''s rule. (QUAD)')
disp(' ')
disp('  * Finding a zero of functions of one variable. (FZERO)')
disp(' ')
disp('  * Plotting functions of one variable, with adaptive choice of')
disp('    evaluation points. (FPLOT)')
disp(' ')
disp('  * Finding a minimum of functions of several variables using the')
disp('    Nelder-Meade simplex algorithm. (FMINS)')
disp(' ')
disp('This demonstration also includes two dynamic text "movies" which')
disp('show the details of two matrix computations -- the QR algorithm')
disp('for matrix eigenvalues, and Gauss-Jordan elimination to compute')
disp('the reduced row echelon form of a matrix.')

% Labels
labels = str2mat(...
   'ODEs', ...
   'Quadrature', ...
   'Zerofinding', ...
   'Function Plot', ...
   'Nonlinear Fit', ...
   'Matrix Eigenvalues',...
   'Row Echelon Form');

% Callbacks
callbacks = [ ...
   'odedemo        '
   'quaddemo       '
   'zerodemo       '
   'fplotdemo      '
   'fitdemo        '
   'eigmovie       '
   'rrefmovie      '];

choices('NADE', 'Numerical Analysis', labels, callbacks);
