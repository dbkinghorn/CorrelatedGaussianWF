%PENNY Several views of the penny data.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

clf
clc
echo on

% The file PENNY.MAT contains measurements made at the 
% National Institute of Standards and Technology of the
% depth of the mold used to mint a U. S. penny, sampled
% on a 128-by-128 grid.
% We first load the data and rescale it.

load penny.mat
P = (.15/256)*P;

% Press any key to continue after pauses.
pause

clc

% Draw a contour plot with 15 copper colored contour lines.

C = copper(35);
set(gca,'colororder',C(21:35,:),'box','on')
hold on
contour(P,15);
n = size(P,1); axis([1 n 1 n]), axis('ij'), axis('square')
hold off

pause

clc

% Draw a pseudocolor plot with brightness proportional to height.

pcolor(P)
colormap(copper)
axis([1 n 1 n]), axis('ij'), axis('square'), shading('flat')

pause

clc

% Draw a pseudocolor plot with brightness proportional to the
% Laplacian of the height.  A cell is bright if its height is
% greater than the average of its four neighbors and dark if
% its height is less than the average of its four neighbors.
% This is an unusual "lighting model", but it produces an image
% that looks like a photograph of a penny.

D = -del2(P);
pcolor(D)
axis([1 n 1 n]), axis('ij'), axis('square'), shading('flat')

pause

clc

% Finally, produce a 3-D, copper colored, surface plot with
% the Laplacian lighting model.

surf(P,D);
axis([1 n 1 n 0 1]), axis('ij'), shading('flat')
view(-20,75)
echo off
