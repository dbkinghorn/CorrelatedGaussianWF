% Demonstrations and samples.
%
% Introduction.
%   demo        - Demonstrate some of MATLAB's capabilities.
%   intro       - Introduction to MATLAB.
%   bench       - MATLAB Benchmark.
%
% MathWorks Specials.
%   vibes       - Vibrating L-shaped membrane.
%   life        - MATLAB's version of Conway's Game of Life.
%   penny       - Several views of the penny data.
%   lorenz      - Plot the orbit around the Lorenz chaotic attractor.
%   earthmap    - View Earth's topography.
%   sqdemo      - Superquadrics using UIControls.
%
% Data Analysis.
%   fftdemo     - Use of the fast finite Fourier transform.
%   quake       - Loma Prieta Earthquake.
%   sigdemo1    - Discrete-time Fourier transforms, with GUI.
%   sigdemo2    - Continuous-timeFourier transforms, with GUI.
%   census      - Try to predict the US population in the year 2000.
%   spline2d    - Demonstrate GINPUT and SPLINE in two dimensions.
%   sunspots    - The answer is 11.08, what is the question?
%
% Numerical analysis.
%   odedemo     - Ordinary differential equations.
%   quaddemo    - Adaptive quadrature.
%   zerodemo    - Zerofinding with fzero.
%   fplotdemo   - Plot a function.
%   fitdemo     - Nonlinear minimization with Nelder-Meade search.
%   eigmovie    - Symmetric eigenvalue movie.
%   rrefmovie   - Computation of Reduced Row Echelon Form
%
% Mathematical Examples.
%   fourier     - Graphics demo of Fourier series expansion.
%   cplxdemo    - Maps of functions of a complex variable.
%   peaks       - A sample function of two variables.
%   knot        - Tube surrounding a three-dimensional knot.
%   membrane    - Generate MathWorks's logo.
%
% Images and color maps.
%   imagedemo   - Demonstrate MATLAB V4's image capability.
%   colormenu   - Select color map.
%
% Sound.
%   sounddemo   - Demonstrate MATLAB V4's sound capability.
%
% Sparse matrices.
%   bucky       - The graph of the Buckminister Fuller geodesic dome.
%   delsqdemo   - Finite difference Laplacian on various domains.
%   sepdemo     - Separators for a finite element mesh.
%   sparsity    - Demonstrate effect of sparsity orderings.
%   airfoil     - Display sparse matrix from NASA airfoil.
%

%	Copyright (c) 1984-93 by The MathWorks, Inc.
