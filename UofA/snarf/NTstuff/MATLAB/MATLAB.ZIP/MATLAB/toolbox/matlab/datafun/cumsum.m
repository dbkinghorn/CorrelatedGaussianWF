%CUMSUM	Cumulative sum of the elements.
%	For vectors, CUMSUM(X) is the cumulative sum of the elements
% 	of X. For matrices, CUMSUM(X) is a matrix containing
% 	the cumulative sums over each column.
%
%	See also CUMPROD, SUM, PROD.

%	Copyright (c) 1984-93 by The MathWorks, Inc.
%	Built-in function.
