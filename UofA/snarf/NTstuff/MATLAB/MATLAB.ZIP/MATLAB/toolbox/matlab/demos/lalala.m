function lalala()
%LALALA Modern version of LALA.
%
%	See also LAUGH, SOUNDDEMO.

%	Copyright (c) 1984-93 by The MathWorks, Inc.

if strcmp(computer,'SUN4')
   % Read the file, Sun's .au format, and send it to the speaker.
   fr = fopen('lalala.dat','rb');
   fw = fopen('/dev/audio','w');
   fwrite(fw,fread(fr));
   fclose(fr);
   fclose(fw);
else
   error('Sound capability required.')
end
