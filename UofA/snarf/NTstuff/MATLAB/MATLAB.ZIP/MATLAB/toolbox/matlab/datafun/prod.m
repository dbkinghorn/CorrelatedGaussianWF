%PROD	Product of the elements.
%	For vectors, PROD(X) is the product of the elements of X.
% 	For matrices, PROD(X) is a row vector with the product over 
% 	each column.
%
%	See also SUM, CUMPROD, CUMSUM.

%	Copyright (c) 1984-93 by The MathWorks, Inc.
%	Built-in function.
