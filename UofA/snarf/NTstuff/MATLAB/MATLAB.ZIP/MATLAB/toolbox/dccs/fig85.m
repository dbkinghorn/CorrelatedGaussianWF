function fig85
% function fig85  generates the Fig 8.5 which shows the computation
% of a transfer function using a random input and spectral
% analysis with output noise/signal ratio a.
clg
a=.2;
f = [-.25 -1 ;1 0 ];
g = [1;0];
h = [ 0 1];
j = 0;
[phi,gam] = c2d(f,g,.5);
w1 = 0:pi/64:pi;
w = w1(2:64);
[mag ph] = dbode(phi,gam,h,j,1,w);
% ph = ph - 360*ones(ph);
rand('seed',0);
u = rand(256,1);
u = u- ones(u)*mean(u);
y = dlsim(phi,gam,h,j,u);
v = rand(256,1);
v = v - ones(v)*mean(v);
yn = y + a*v;
ru1 = xcorr(u);
ru = ru1(128:383);
wh = hamming(256);
rubar = ru.*wh;
ryu1 = xcorr(y,u);
ryu = ryu1(128:383);
ryubar = ryu.*wh;
ryun1 = xcorr(yn,u);
ryun = ryun1(128:383);
ryunbar = ryun.*wh;
Syu = fft(ryubar);
Syun = fft(ryunbar);
Suu = fft(rubar);
Tf = Syu./Suu;
Tfn = Syun./Suu;
magr = abs(Tf(3:2:128));
phr1 = angle(Tf(3:2:128))*180/pi;
phr = fixphase(phr1);
magn = abs(Tfn(3:2:128));
phn1 = angle(Tfn(3:2:128))*180/pi;
phn = fixphase(phn1);
hold off, clg;
subplot(221), loglog(w,mag),hold on, loglog(w,magr,'x'),grid,title('smoothed estimate')
hold off
subplot(223),semilogx(w,ph),hold on,semilogx(w,phr,'x'), grid
hold off
subplot(222), loglog(w,mag),hold on, loglog(w,magn,'x'),grid,title('estimate with noise')
hold off
subplot(224),semilogx(w,ph),hold on,semilogx(w,phn,'x'), grid
hold off
