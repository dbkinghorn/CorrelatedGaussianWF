function[PHI,GAMMA,H,J] = c2dd(A,B,C,T,lambda)
%C2DD	Conversion  of continuous state space model to discrete model 
%	with delay in the control.
%  [phi,gamma,hd,jd] = c2dd(a,b,c,T,lambda)
%	the continuous time system is
%	      y(t) = Cx(t) ;   output
%	      .
%          x(t) = Ax(t) + Bu(t-lambda) ;  state
%	the discrete system is
%             y(k) = Hx(k) + Ju(k) ;   output  
%
%	x(k+1) = PHI x(k) + GAMMA u(k) ;   state
%	the delay lambda can be negative < T seconds.
%	written by g.franklin based on results in Franklin and
% 	Powell, Digital Control; Addison and Wesley; 1980
%	chapter 6, pages 171-177
[ns nc] = size(B);
l = ceil(lambda/T);
m = l*T - lambda;

s1 = expm([A*m, B*m; zeros(1,ns+1)]);
s2 = expm([A*(T-m), B*(T-m); zeros(1,ns+1)]);
s3 = eye(l-1);
s4 = zeros(ns,l-2);
s5 = zeros(l-1,ns+1);
s6 = zeros(1,ns+l);

PHI1 = s1(1:ns,1:ns)*s2(1:ns,1:ns);
GAMMA1 = s1(1:ns,1:ns)*s2(1:ns,ns+1);
GAMMA2 = s1(1:ns,ns+1);
if l == 0
%
	'this is the modified z-transform case '
%
	PHI = PHI1;
	GAMMA = PHI1 * GAMMA2 + GAMMA1;
	H     =  C;
	J     =  C * GAMMA2;
%
%	delay less than one period
%
	elseif l == 1
		PHI = [PHI1, GAMMA1; zeros(1:ns+1)];
		GAMMA  = [GAMMA2;1];
		H      =  [C,0];
		J      =[0];
		else
			PHI   =  [PHI1,GAMMA1,GAMMA2,s4;s5,s3;s6];
			GAMMA =  s6';
			GAMMA(ns+l,1) = 1;
			H     =  [C,zeros(1,l)];
			J     =  [0];
		end
	end	
end
