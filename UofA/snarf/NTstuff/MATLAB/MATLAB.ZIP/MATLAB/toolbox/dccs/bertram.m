function Kb = bertram(a,b,c,d)
% kb = bertram(a,b,c,d) is a function to compute the Bertram Worst
% case bound for quantization errors in an otherwise linear digital
% system with state description matrices from the point of
% qunatization a,b,c,d. The bound is y-max <= kb*q/2.

x = b;
Kb = abs(d);
while norm(x,1) > .00005;
     y = c*x;
     Kb = Kb + abs(y);
     x = a*x;
end
