% FIG516.M   Fig. 5.16
clg
w=logspace(-2,1);
l=length(w);

% s-plane 
z=inf;
p=[0 -1];
ko=1;
[num,den]=zp2tf(z,p,ko);
[mag,phase]=bode(num,den,w);
phasem=phase+180;
axis([-2 1 -3 2]);
subplot(211),loglog(w,mag,'-'),grid 
ylabel('Magnitude')
xlabel('Frequency (rad/sec)')
axis([-2 1 -100 100]);
subplot(212),semilogx(w,phasem,'-'),grid
ylabel('Phase (deg)')
xlabel('Frequency (rad/sec)')
hold on

%              T = 0.2 sec
T = 0.2;
th= w*T;
th=th(th < pi);
lt=length(th);
lt=lt+1;
th(lt)=pi;
wp=th/T;
z=[-.9355;inf]
p=[1;.8187]
ko=.0187;
[num,den]=zp2tf(z,p,ko);
[mag,phase]=dbode(num,den,th);
phasem=phase+180;
axis([-2 1 -3 2]);
subplot(211),loglog(wp,mag,'--') 
axis([-2 1 -100 100]);
subplot(212),semilogx(wp,phasem,'--')

%              T = 1 sec
T = 1;
th= w*T;
th=th(th < pi);
lt=length(th);
lt=lt+1;
th(lt)=pi;
wp=th/T;
z=[-.718;inf]
p=[1;.368]
ko=.368;
[num,den]=zp2tf(z,p,ko);
[mag,phase]=dbode(num,den,th);
phasem=phase+180;
axis([-2 1 -3 2]);
subplot(211),loglog(wp,mag,'-.') 
axis([-2 1 -100 100]);
subplot(212),semilogx(wp,phasem,'-.')

%              T = 2 sec
T = 2;
th= w*T;
th=th(th < pi);
lt=length(th);
lt=lt+1;
th(lt)=pi;
wp=th/T;
z=[-.523;inf]
p=[1;.135]
ko=1.135;
[num,den]=zp2tf(z,p,ko);
[mag,phase]=dbode(num,den,th);
phasem=phase+180;
axis([-2 1 -3 2]);
subplot(211),loglog(wp,mag,':') 
axis([-2 1 -100 100]);
subplot(212),semilogx(wp,phasem,':')
hold off
