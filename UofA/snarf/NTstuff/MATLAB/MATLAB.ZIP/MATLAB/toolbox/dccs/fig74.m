function fig74
% a function to construct fig 7.4 using the functions %
%   bertram and widrow
B = zeros(2,10);
b = 1;
c = 1;
d = 0;
a = 0;
for k = 0:9
B(1,k+1) = bertram(a,b,c,d);
B(2,k+1) = widrow(a,b,c,d);
a = (k+1)/10;
end
k = 0:.1:.9;
v = [0 1.0 0 11];
axis(v)
plot(k,B(1,:),'x',k,B(2,:),'o')
grid
title('Error bound and rms estimate for first order system')
xlabel('Fig. 7.4              alpha')
