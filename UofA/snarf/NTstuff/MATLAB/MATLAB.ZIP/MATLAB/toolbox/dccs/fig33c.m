% function to plot Fig. 3.3(c)
% fig33c
function fig33c
k = 0:25;
y = 3*sin(.5*k + pi/6);
zohplot(k,y)
hold
n = 0:125;
y1 = 3*sin(.1*n + pi/6);
plot(n/5 , y1, '.')
grid
title('OUTPUT SIGNAL rh')
hold
