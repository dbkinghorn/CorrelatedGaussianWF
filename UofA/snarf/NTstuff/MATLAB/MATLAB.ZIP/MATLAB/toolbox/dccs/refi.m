function [M,N,Nbar] = refi(phi,gam,H,K)
% REFI.M  computes command input matrices
% # of contols must be equal to # of outputs
% i.e., if gam = n x m, then H must be m x n
I=eye(phi);
[m,n]=size(H);
np=inv([phi-I gam;H zeros(m)])*([zeros(n,m);eye(m)]);
M=np(1:n,:);
N=np(n+1:n+m,:);
Nbar=N+K*M;
