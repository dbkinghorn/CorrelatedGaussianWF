%FIG96.M          Fig. 9.6
F=[0 1;0 0];
G=[0;1];
T=1;
Qc1=[1 0;0 0];
Qc2=[10000 1 .5 .2 .1 .05 .02 .01];
% First find the s-plane roots for a continuous optimization
for j=1:8,
	K=lqr(F,G,Qc1,Qc2(j));
	e=eig(F-G*K);
	s(1,j)=e(1);
	s(2,j)=e(2);
end
axis([-3 0 -3 3])
plot(real(s(1,:)),imag(s(1,:)),'*',real(s(2,:)),imag(s(2,:)),'*')
hold on
plot(real(s(1,:)),imag(s(1,:)),'-',real(s(2,:)),imag(s(2,:)),'-')
zero = [0 0];
x=[-4 0];
plot(x,zero)
grid
title('Fig. 9.6')
xlabel('Real s')
ylabel('Imag s')
% Now convert continuous cost to equivalent discrete cost
% and do discrete optimization
for j=1:8,
	[phi,gam,K]=dclqr(F,G,Qc1,Qc2(j),T);
	e=eig(phi-gam*K);
	z(1,j)=e(1);
	z(2,j)=e(2);
end
% convert roots to s-plane for comparison
s=log(z)/T;
plot(real(s(1,:)),imag(s(1,:)),'o',real(s(2,:)),imag(s(2,:)),'o')
text(-2.8,.1,'o  o  o  emulation design')
text(-2.8,.5,'*--*--*  continuous design')
hold off
