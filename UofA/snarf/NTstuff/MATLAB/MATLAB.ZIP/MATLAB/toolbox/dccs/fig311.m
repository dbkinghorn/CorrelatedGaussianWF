function fig311
% function to plot Fig. 3.11
clg
k = 0:25;
y = 3*sin(.5*k+pi/6);
zohplot(k,y)
hold on
abar = 3*sin(.25)/.25;
n = 0:125;
y1 =abar*sin(.1*n + pi/6 -.25);
plot(n/5, y1)
y1 = 3*sin(.1*n + pi/6);
plot(n/5, y1)
title('PLOT OF ZOH OUTPUT AND FIRST HARMONIC')
xlabel('               Fig. 3.11         t/T --->')
grid
hold off
