% FIG521.M   Fig. 5.21
clg
w=logspace(-1,1);
l=length(w);

% s-plane 
z=inf;
p=[0 -1];
ko=1;
[num,den]=zp2tf(z,p,ko);
[mag,phase]=bode(num,den,w);
phasem=phase+180;
for i=1:l
	K(i)=1/mag(i);
end
r=rlocus(num,den,K);
Wn=abs(r(:,1));
zeta=-real(r(:,1))./Wn;
axis([0 80 0 1]);
plot(phasem,zeta,'-'),grid 
ylabel('Damping ratio, zeta')
xlabel('Phase margin')
hold on

%              T = 0.2 sec
T = 0.2;
th= w*T;
z=[-.9355;inf];
p=[1;.8187];
ko=.0187;
[num,den]=zp2tf(z,p,ko);
[mag,phase]=dbode(num,den,th);
phasem=phase+180;
for i=1:l
	K(i)=1/mag(i);
end
r=rlocus(num,den,K);
s=log(r)/T;
Wn=abs(s(:,1));
zeta=-real(s(:,1))./Wn;
plot(phasem,zeta,'--') 

%              T = 1 sec
T = 1;
th= w*T;
th=th(th < pi);
lt=length(th);
z=[-.718;inf];
p=[1;.368];
ko=.368;
[num,den]=zp2tf(z,p,ko);
[mag,phase]=dbode(num,den,th);
phasem=phase+180;
for i=1:lt
	K(i)=1/mag(i);
end
r=rlocus(num,den,K);
s=log(r)/T;
Wn=abs(s(:,1));
zeta=-real(s(:,1))./Wn;
zeta=zeta(1:lt);
phasem=phasem(1:lt);
plot(phasem,zeta,'-.') 
hold off
