% fig63a.m      Fig. 6.3(a)
clg
f=[0 1 0 0;
-.91 -.036 .91 .036
0 0 0 1
.091 .0036 -.091 -.0036];
g=[0;0;0;1];
h=[1 0 0 0];
T=.4;
[phi,gam]=c2d(f,g,T);
z=eig(phi);
zol = z'
zd1=[.9;.9;.9;.9];
zd = zd1'
k1=acker(phi,gam,zd1)
n=102;
b=[1;0;0;0];
y1=dimpulse(phi-gam*k1,b,h,0,1,n);
u1=dimpulse(phi-gam*k1,b,k1,0,1,n);
t=-T:T:(n-2)*T;
axis([0 40 -12 2])
plot(t,y1),grid
ylabel('OUTPUT,  d  and  CONTROL,  u')
xlabel('TIME   (SEC)')
title('Fig. 6.3(a)')
hold on
zohplot(t',u1,'-')
pause
hold off
axis
