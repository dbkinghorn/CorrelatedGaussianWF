function fig43
%  fig4_3(T) computes the discrete equivalent 
%  of the third order Butterworth  system with bandwidth 1
%  rad/s using sample period T  and Bilinear,
%  bilinear  prewarped at wp = 1, forward, and backward 
%  rules.  The results are plotted in magnitude and phase
%  against normalized frequency wT.
a = [-2 -2 -1;1 0 0;0 1 0];
b = [1 0 0]';
c = [0 0 1];
d = 0;
w = 0:.05:2.5;
T=1;
[magc phc] = bode(a,b,c,d,1,w);
[ff,gf,hf,jf] = fwd(a,b,c,d,T);
[fb,gb,hb,jb] = bkwd(a,b,c,d,T);
[fbi,gbi,hbi,jbi] = bilinear(a,b,c,d,T);
warp = (2/T)*tan(T/2);
awarp = warp*a;
bwarp = b * warp;
[fp,gp,hp,jp] = bilinear(awarp,bwarp,c,d,T);
[magf phf] = dbode(ff,gf,hf,jf,1,w*T);
[magb phb] = dbode(fb,gb,hb,jb,1,w*T);
[magwarp phwarp] = dbode(fp,gp,hp,jp,1,w*T);
[magbi phbi] = dbode(fbi,gbi,hbi,jbi,1,w*T);
clg
hold off
subplot(211), plot(w,magc), hold on
subplot(211),plot(w,magbi,'o',w,magwarp,'+',w,magb,'*',w,magf,'x');
subplot(211), grid,title('magnitude and phase of discrete equivalents'), hold off
subplot(212) , plot(w,phc), hold on
subplot(212),plot(w,phbi,'o',w,phwarp,'+',w,phb,'*',w,phf,'x')
subplot(212), grid,title('bilin = o,warp = +, back = *, forw = x')
subplot(212), xlabel('normalized frequency w/wp')
hold off
