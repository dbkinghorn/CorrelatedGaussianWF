% FIG523.M   Fig. 5.23
clg
dt=1;
w=logspace(-2,1);
l=length(w);
one=ones(l,1);
oeighty=-180*one;
th= w*dt;
th=th(th < pi);
lt=length(th);
wp=th/dt;

% uncompensated
z=[-.9672;inf];
p=[1;.9048];
kp=.0484;
ko=kp;
[num,den]=zp2tf(z,p,ko);
[mag,phase]=dbode(num,den,th);
axis([-2 1 -2 2]);
subplot(211),loglog(wp,mag,'-',w,one,'-'),grid 
ylabel('magnitude')
xlabel('frequency (rad/sec)')
axis([-2 1 -270 -90]);
subplot(212),semilogx(wp,phase,'-',w,oeighty,'-'),grid
ylabel('phase (deg)')
xlabel('frequency (rad/sec)')
f=wp';
fr=[f,mag,phase+180];

% Compensation #1
dz=.85;
dp=0;
z=[-.9672;dz;inf];
p=[1;.9048;dp];
ko=kp*(1-dp)/(1-dz);
[num,den]=zp2tf(z,p,ko);
[mag,phase]=dbode(num,den,th);
axis([-2 1 -2 2]);
subplot(211),loglog(wp,mag,'--')
axis([-2 1 -270 -90]);
subplot(212),semilogx(wp,phase,'--')
fr=[f,mag,phase+180];

% Compensation #2
dz=.9;
dp=0;
z=[-.9672;dz;inf];
p=[1;.9048;dp];
ko=kp*(1-dp)/(1-dz);
[num,den]=zp2tf(z,p,ko);
[mag,phase]=dbode(num,den,th);
axis([-2 1 -2 2]);
subplot(211),loglog(wp,mag,':')
axis([-2 1 -270 -90]);
subplot(212),semilogx(wp,phase,':')

% Compensation #3
dz=.9;
dp=-.5;
z=[-.9672;dz;inf];
p=[1;.9048;dp];
ko=kp*(1-dp)/(1-dz);
[num,den]=zp2tf(z,p,ko);
[mag,phase]=dbode(num,den,th);
axis([-2 1 -2 2]);
subplot(211),loglog(wp,mag,'-.')
axis([-2 1 -270 -90]);
subplot(212),semilogx(wp,phase,'-.')

