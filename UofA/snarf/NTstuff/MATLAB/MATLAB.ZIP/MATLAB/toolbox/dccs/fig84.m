% fig84 plots the Hamming window and its magnitude spactrum
clg
wh = hamming(64);
pad = zeros(256,1);
pad(1:64) = wh;

k = 0:127;
S = abs(fft(pad));
subplot(211), plot(k,pad(1:128)) ,title('Hamming Window');
subplot(212), semilogy(k,S(1:128)/S(1));
hold off
