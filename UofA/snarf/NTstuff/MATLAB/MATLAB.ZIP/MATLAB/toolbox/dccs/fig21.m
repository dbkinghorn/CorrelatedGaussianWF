function fig21
% a function to compute and plot the first 9 Fibonacci numbers
y = zeros(1,9);
k = 3;
y(1) = 1;
y(2) = 1;
while k <= 9;
y(k) = y(k-1) + y(k-2);
k = k+1;
end
k1 = 0:8;
plot(k1,y,'o')
title('FIG 2.1 PLOT OF THE FIRST 9 FIBONACCI NUMBERS')
xlabel('              k')
ylabel('u(k)')

