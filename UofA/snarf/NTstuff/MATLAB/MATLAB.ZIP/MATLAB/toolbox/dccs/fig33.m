 % *.m file to produce Fig 3.3.
% fig23
function fig33
clg
subplot(224), fig33d
subplot(221), fig33a
subplot(222), fig33b
subplot(223), fig33c
