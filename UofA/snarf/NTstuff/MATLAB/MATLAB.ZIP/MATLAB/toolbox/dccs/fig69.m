% fig69.m      Fig. 6.9
clg
f=[0 1;
0 0];
g=[0;1];
h=[1 0];
T=.1;
[phi,gam]=c2d(f,g,T);
z=eig(phi);
zol = z'
i=sqrt(-1);
zd1=[.8+i*.25;.8-i*.25];
zd = zd1'
k=acker(phi,gam,zd1)
pbb=phi(2,2);
pab=phi(1,2);
zd2=.5
lr=(1-zd2)/T
n=17;
%y=dimpulse(phi-gam*k,ic,h,0,1,n);
%u=dimpulse(phi-gam*k,ic,k,0,1,n);
x2=dimpulse(pbb-lr*pab,1,1,0,1,n);
t=-T:T:(n-2)*T;
axis([0 1.5 -2 2])
plot(t,x2,'*'),grid
hold on
plot(t,x2,'-')
hold off
ylabel('ESTIMATE ERROR,  X2')
xlabel('TIME   (SEC)')
title('Fig. 6.9')
pause
axis
