function  kw =widrow(a,b,c,d)
% kw = widrow(a,b,c,d) is a function to compute the rms
%  error due to round-off error normalized by q/2. 
%  y-rms = kw*q/2.   Assumes  the white noise model with
%   var q^2/12.
q = b*b';
p = dlyap(a,q);
kw = sqrt((c*p*c'+d*d')/3); 
