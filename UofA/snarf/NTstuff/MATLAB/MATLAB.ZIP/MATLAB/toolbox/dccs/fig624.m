% fig624.m      Fig. 6.24
%     response without integral control, full state feedback
%     with STATE COMMAND structure
clg
f=[0 1;
0 0];
g=[0;1];
h=[1 0];
T=.1;
[phi,gam]=c2d(f,g,T);
z=eig(phi);
zol = z'
i=sqrt(-1);
zd2=[.8+i*.25;.8-i*.25];
zd = zd2'
k=acker(phi,gam,zd2)
[Nx,Nu,Nbar]=refi(phi,gam,h,k)
gk=gam*k;
phic=[phi-gk]
z=eig(phic);
zcl = z'
hec= -k        % output is  u
d=[Nbar 0];
n=61;
m=20;
% step command at t=0; disturbance step,w, of 5 at n=20
w=[zeros(m,1);5*ones(n-m,1)];
input=[ones(n,1) w];
gnb=gam*Nbar;
B=[gnb gam];
[y,x]=dlsim(phic,B,hec,d,input);
u=y(:,1);
t=0:T:(n-1)*T;
axis([0 6 -3 3])
plot(t,x(:,1),'o',t,x(:,2),'x'),grid
hold on
plot(t,x(:,1),'-',t,x(:,2),'-')
zohplot(t',w/2,'-.')
us=u/5;
zohplot(t',us,'-')
hold off
ylabel('OUTPUTS')
xlabel('TIME   (SEC)')
title('Fig. 6.24')
text(4.1,-2.67,'--o---  X1')
text(4.1,-3,'--x---  X2')
text(4.1,-2.33,'------  U/5')
text(4.1,-1.9,'_._._._  w/2')
pause
axis
