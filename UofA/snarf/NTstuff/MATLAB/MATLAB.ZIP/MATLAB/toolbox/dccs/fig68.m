% fig68.m      Fig. 6.8
clg
f=[0 1;
0 0];
g=[0;1];
h=[1 0];
T=.1;
[phi,gam]=c2d(f,g,T);
z=eig(phi);
zol = z'
i=sqrt(-1);
zd1=[.8+i*.25;.8-i*.25];
zd = zd1'
k=acker(phi,gam,zd1)
zd2=[.4+i*.4;.4-i*.4];
zd = zd2'
lt=acker(phi',h',zd2);
lp=lt'
lt=acker(phi',phi'*h',zd2);
lc=lt'
lc=inv(phi)*lp
n=17;
ic=[0;1];
%y=dimpulse(phi-gam*k,ic,h,0,1,n);
%u=dimpulse(phi-gam*k,ic,k,0,1,n);
x1=dimpulse(phi-lc*h*phi,ic,h,0,1,n);
h2=[0 1];
x2=dimpulse(phi-lc*h*phi,ic,h2,0,1,n);
t=-T:T:(n-2)*T;
axis([0 1.5 -2 2])
plot(t,x1,'o',t,x2,'*'),grid
hold on
plot(t,x1,'-',t,x2,'-')
hold off
ylabel('ESTIMATE ERRORS, X1 and X2')
xlabel('TIME   (SEC)')
title('Fig. 6.8')
text(1.1,-1.5,'--o--  X1')
text(1.1,-2,'--*--  X2')
pause
axis
