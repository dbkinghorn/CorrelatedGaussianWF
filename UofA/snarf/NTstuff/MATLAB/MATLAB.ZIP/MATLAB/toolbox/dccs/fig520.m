% fig520.M      Fig. 5.20
% 
axis([-1.5 1.5 -1.5 1.5])
axis('square')
t=0:.1:6.3;
plot(sin(t),cos(t),'-'),grid
hold on
ko=.0012;
z=[-3.38; -.242;inf];
p=[1; .8187; .8187];
[num,den]=zp2tf(z,p,ko);
th=logspace(-2,pi);
[mag,phase]=dbode(num,den,th);
d2r=1/57.295;
phase=phase*d2r;
re=mag.*cos(phase);
im=mag.*sin(phase);
plot(re,im,'--')
pause
hold off
axis
axis('normal')
