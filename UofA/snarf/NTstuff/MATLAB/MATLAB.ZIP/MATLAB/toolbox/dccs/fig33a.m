function fig33a
% function to plot Fig. 3.3(a)
% fig33a
n = 0:125;
y1 = 3*sin(.1*n + pi/6);
plot(n/5 , y1)
grid
title('INPUT SIGNAL r')
