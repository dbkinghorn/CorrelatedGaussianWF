% *.m file to produce Fig 3.3(d)
% fig33d
function fig33d
v = [-10 10 -10 10];
x = [-7  -3  -2];
y = [0 0 1];
x1 = [-2  2];
y1 = [0 0];
axis(v);
plot(x,y)
hold
plot(x1,y1)
x1 = [2 2 6 6 2];
y1 = [-2 2 2 -2 -2];
plot(x1,y1)
x2 = [6 8];
y2 = [0 0];
plot(x2,y2)
text(-4,1,'r')
text(0,1,'r*')
text(6.5,1,'rh')
text(2.5,-1,'ZOH')
text(-2.5, -2.5,'T')
title('SAMPLE & HOLD')
xlabel('Fig. 3.3')
hold
