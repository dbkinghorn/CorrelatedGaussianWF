% FIG531b.M   
clg
dt=1;     %  sample period
tm=20;     %  problem time duration
                  %  Discrete Plant
kp=.3935;
gz=[-.6065];
gp=[0;0;.3679];
               %   compensation
k=.3;
dp=1;
dz=0;
z=[gz;dz];
p=[gp;dp];
[nud,ded] = zp2tf(z,p,kp);  % kp = plant gain
r=rlocus(nud,ded,k); % k = D(z) gain
[nu,de] = zp2tf(z,r,kp*k);  % c.l. transfer function
n=tm/dt + 1;
y=dstep(nu,de,n);    %  output at sample times
t=0:dt:tm;
axis([0 tm -1.4 1.4]);
plot(t,y,'*')
ylabel('OUTPUT,  Y  and  CONTROL,  U/2')
xlabel('TIME   (SEC)')
title('Fig. 5.31 (b)')
grid
hold on
zu=[dz;gp];
[nu,de]=zp2tf(zu,r,k);
u=dstep(nu,de,n);   % control output at samples)
us=u/2;       % scaled control output at samples)
zohplot(t',us,'-')
pause
hold off
axis
