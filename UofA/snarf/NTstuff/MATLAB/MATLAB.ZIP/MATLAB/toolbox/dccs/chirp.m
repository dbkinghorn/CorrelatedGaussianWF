function u = chirp(w1,w2,N)
%  u = chirp(w1,w2,N) returns a chirp from discrete radian frequency
%  w1 to w2 with N points.
wa = w1:(w2 - w1)/N:w2;
w(1:N) = wa(1:N);
win1 = [0:10/N:1, ones(1,.8*N) , 1:-10/N:0];
win(1:N) = win1(1:N);
k = 0:N-1;
u =win.* sin(w.*k);
ubar = mean(u);
u = u - ones(u).*ubar;
