% FIG522.M   Fig. 5.22
clg
dt=1;     %  sample period
                  %  Discrete Plant
kp=.0484;
gz=[-.9672;inf];
gp=[1;.9048];
               %   compensation
k=6;
dz=.8;
dp=.05;
z=[gz;dz];
p=[gp;dp];
ko=kp*k;
[nud,ded] = zp2tf(z,p,ko);  % kp = plant gain
w=logspace(-2,1);
l=length(w);
th= w*T;
th=th(th < pi);
lt=length(th);
lt=lt+1;
th(lt)=pi;
wp=th/T;
[mag,phase]=dbode(nud,ded,th);
axis([-2 1 -3 3]);
loglog(wp,mag,'-'),grid
hold on
ylabel('Magnitude')
xlabel('Frequency (rad/sec)')
a=[.001 2 ];
b=[1 1];
loglog(b,a,'-')
a=[126 1.26 1];
b=[.01 1 1.26];
loglog(b,a,'-')
a=[1.26 1.26];
b=[.01 1];
loglog(b,a,'--')
hold off



