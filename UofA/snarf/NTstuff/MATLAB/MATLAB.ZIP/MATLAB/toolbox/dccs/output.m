function y = output(gz,gp,dz,dp,kp,k,dt,tm,kc,gcp,gcz)
% OUTPUT.M   intersample output and control 
clg
%  dt = sample period
%  tm = problem time duration
                  %  Continuous Plant
% kc = gain
% gcp = poles
% gcz = zeros
                  %  Discrete Plant
% kp = gain
% gp = poles
% gz = zeros
               %   compensation
% k = gain
% dz = zeros
% dp = poles

z=[gz;dz];
p=[gp;dp];
[nud,ded] = zp2tf(z,p,kp);
r=rlocus(nud,ded,k); 
[nu,de] = zp2tf(z,r,kp*k);  % c.l. transfer function
n=tm/dt + 1;
y=dstep(nu,de,n);    %  output at sample times
t=0:dt:tm;
axis([0 tm -1.4 1.4])
plot(t,y,'*')
ylabel('OUTPUT,  Y  and  CONTROL,  U/10')
xlabel('TIME   (SEC)')
grid
hold on
zu=[dz;gp];
[nu,de]=zp2tf(zu,r,k);
u=dstep(nu,de,n);   % control output at samples)
us=u/10;       % scaled control output at samples)
zohplot(t',us,'-')
                   % now fill in between samples
[nc,dc] = zp2tf(gcz,gcp,kc);  
dtc=dt/5;
tc=0:dtc:tm;
le=length(tc);
ut=ones(5,1)*u';
uc=ut(:);
uc=uc(1:le);
yc=lsim(nc,dc,uc,tc);
plot(tc,yc)
pause
hold off
axis
