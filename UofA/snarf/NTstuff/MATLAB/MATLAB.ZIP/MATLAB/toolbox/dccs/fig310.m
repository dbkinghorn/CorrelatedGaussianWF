function fig310
% *.m file to plot Fig. 3.10;
w = 0:.1:15;
zoh = sin(w/2)./(w/2);
v =[0 15 0 1.3]
axis(v)
subplot(223),plot(w,abs(zoh),'.')
x = [1 1];
y = [0  sin(.5)/(.5)];
hold
subplot(223),plot(x,y)
x1 = [2*pi-1 2*pi-1];
y1 = [0 sin(pi-.5)/(pi-.5)];
subplot(223),plot(x1,y1)
x2 = [2*pi+1 2*pi+1];
y2 = [0 sin(pi+.5)/(pi+.5)];
subplot(223),plot(x2,abs(y2))
x3=[4*pi-1 4*pi-1];
y3=[0 sin(2*pi-.5)/(2*pi-.5)];
subplot(223),plot(x3,abs(y3))
x4 = [4*pi+1 4*pi+1];
y4 =[0 sin(2*pi+.5)/(2*pi+.5)];
subplot(223),plot(x4,y4)
title(' RESPONSE FROM ZOH')
xlabel('Fig. 3.10')
grid
v = [0 15 0 1.3]
hold
axis(v)
x = [1 1];
y = [0  1];
subplot(221),plot(x,y)
grid
title('INPUT SPECTRUM')
x = [1 1];
y = [0  1];
axis(v)
subplot(222),plot(x,y)
hold
x1 = [2*pi-1 2*pi-1];
y1 = [0 1];
subplot(222), plot(x1,y1)
x2 = [2*pi+1 2*pi+1];
y2 = [0 1];
subplot(222),plot(x2,y2)
x3=[4*pi-1 4*pi-1];
y3=[0 1];
subplot(222),plot(x3,y3)
x4 = [4*pi+1 4*pi+1];
y4 = [0 1]
subplot(222), plot(x4,y4)
grid
title('SAMPLED SPECTRUM')
hold off
