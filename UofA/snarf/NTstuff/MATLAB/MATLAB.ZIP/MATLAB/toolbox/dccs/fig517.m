% FIG517.M   Fig. 5.17
clg
%                 s-plane 

w=logspace(-2,2,200);
z=inf;
p=[0 -1];
ko=1;
[num,den]=zp2tf(z,p,ko);
[mag,phase]=bode(num,den,w);

%              T = 0.2 sec
T = 0.2;
th= w*T;
lag=57.295*th/2;
axis([0 3.5 0 90])
plot(th,lag),grid
hold on
xlabel('Normalized frequency, wT (rad)')
ylabel('Phase lag (deg)')
th=th(th < 3);
lt=length(th);
z=[-.9355;inf]
p=[1;.8187]
ko=.0187;
[num,den]=zp2tf(z,p,ko);
[mag,phased]=dbode(num,den,th);
phase=phase(1:lt);
lagd= phase-phased;
plot(th,lagd,'--')

%              T = 1 sec
T = 1;
th= w*T;
th=th(th < 2.9);
lt=length(th);
z=[-.718;inf]
p=[1;.368]
ko=.368;
[num,den]=zp2tf(z,p,ko);
[mag,phased]=dbode(num,den,th);
phase=phase(1:lt);
lagd= phase-phased;
plot(th,lagd,'--')

%              T = 2 sec
T = 2;
th= w*T;
th=th(th < 2.8);
lt=length(th);
z=[-.523;inf]
p=[1;.135]
ko=1.135;
[num,den]=zp2tf(z,p,ko);
[mag,phased]=dbode(num,den,th);
phase=phase(1:lt);
lagd= phase-phased;
plot(th,lagd,'--')
hold off
