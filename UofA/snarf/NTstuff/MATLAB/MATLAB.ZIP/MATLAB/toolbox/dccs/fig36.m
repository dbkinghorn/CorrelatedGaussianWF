function fig36
% function to plot Fig 3.6
num = [1];
den = [1 .8 1];
w = -6:.1:6;
[mag ph] = bode(num,den,w);
v = [-10 10 0 2];
axis(v);
mag1 = zeros(mag);
mag1(31:90) = mag(31:90);
subplot(211),plot(w,mag1)
grid
title('SPECTRUM OF A BANDLIMITED SIGNAL')
text(.5,1.6,'|R|')
xlabel('Fig. 3.6(a)                wT')
w1 = w - 2*pi;
subplot(212),plot(w,mag1)
hold on
subplot(212),plot(w1,mag1)
w2 = w + 2*pi;
subplot(212), plot(w2,mag1)
title('SPECTRUM OF A SAMPLED BANDLIMITED SIGNAL')
text(.5, 1.6,'|R*|')
grid
xlabel('Fig. 3.6(b)                wT')
x = [2.5 2.5];
y = [0 .75];
subplot(212), plot(x,y)
text(2.4,1.,'w1')
hold off
