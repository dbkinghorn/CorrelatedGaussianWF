%FIG98B.M        Fig. 9.8(b)
%also see EXAMP963.M  to do some design iterations
clg
F=[-.2 .1 1;
-.05 0 0;
0 0 -1];
G=[0 1;0 .7;
1 0];
T=.2;
[phi,gam]=c2d(F,G,T);
ts=2.4
k=ts/T;
alpha=100^(1/k)
phip=alpha*phi;
gamp=alpha*gam;
q1=[.25 0 0;
0 1 0;
0 0 0]
q2=[1/25 0;
0 .01]
K=dlqr(phip,gamp,q1,q2)
phic=phi-gam*K;
z=eig(phic)
H=-K;
d=[0;0];
ic=[0;1;0];
n=22;
t=-T:T:(n-2)*T;
[y,x]=dimpulse(phic,ic,H,d,1,n);
axis([0 4 -2 2]);
plot(t,x(:,1)/2,'o',t,x(:,2),'x'),grid
hold on
plot(t,x(:,1)/2,'-',t,x(:,2),'-')
zohplot(t',y(:,2)/10,'--')
zohplot(t',y(:,1)/5,'-')
hold off
ylabel('OUTPUTS')
xlabel('TIME   (SEC)')
title('Fig. 9.8(b)')
text(2.1,-1.25,'---o--- X1/2')
text(2.1,-1.5,'---x--- X2')
text(2.1,-1.75,'------- U1/5')
text(2.1,-2,'- - - - U2/10')
pause
axis
disp('       t       x1        x2         x3')
output=[t(2:19)' x(2:19,1) x(2:19,2) x(2:19,3)]
