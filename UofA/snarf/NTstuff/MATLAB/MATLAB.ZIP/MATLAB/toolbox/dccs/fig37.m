function fig37
% function to plot Fig. 3.7
clg
hold off
n = -4:.1:4;
y = sin(pi*n)./(pi*n);
plot(n,y)
grid
title('IMPULSE RESPONSE OF THE IDEAL LOW-PASS FILTER')
xlabel('            Fig. 3.7          t/T')
