function fig48
%  fig48(T) computes Fig. 4.8  which compares
% the zero-order-hold, the triangle hold, and the
% zero-pole equivalents for the third order Butterworth
 % filter with unity (rad) bandwidth..  The respones are
% plotted against the frequency normalized
a = [-2 -2 -1;1 0 0;0 1 0];
b = [1 0 0]';
c = [0 0 1];
d = 0;
T=2;
[fzoh,gzoh,hzoh,jzoh] = zoheq(a,b,c,d,T);
[ft,gt,ht,jt] = trieq(a,b,c,d,T);
[fzp,gzp,hzp,jzp]= zpeq(a,b,c,d,T);
wn = 0:.05:2.5;
w = wn;
[magc phc] = bode(a,b,c,d,1,w);
[magzoh phzoh] = dbode(fzoh,gzoh,hzoh,jzoh,1,w*T);
[magzp phzp] = dbode(fzp,gzp,hzp,jzp,1,w*T);
[magtri phtri] = dbode(ft,gt,ht,jt,1,w*T);
clg
hold off
subplot(211),plot(wn,magc) ,grid, hold on
subplot(211),plot(wn,magzoh,'o',wn,magzp,'+',wn,magtri,'x')
subplot(211), title('zoh = o, zero-pole = + ,triangle = x')
hold off
subplot(212), plot(wn,phc),grid, hold on
subplot(212), plot(wn,phzoh,'o',wn,phzp,'+',wn,phtri,'x')
subplot(212), xlabel('normalized frequency w/wp')
hold off
