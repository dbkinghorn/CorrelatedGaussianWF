function fig34
% function to plot Fig 3.4
num = [1];
den = [1 .8 1];
w = -6:.1:6;
[mag ph] = bode(num,den,w);
clg
v = [-10 10 0 2];
axis(v);
subplot(211),plot(w,mag)
grid
title('SPECTRUM OF A SIGNAL')
text(.5,1.6,'|R|')
xlabel('Fig. 3.4(a)')
w1 = w - 2*pi;
subplot(212),plot(w,mag,'.')
hold on
subplot(212),plot(w1,mag,'.')
w2 = w + 2*pi;
subplot(212), plot(w2,mag,'.')
title('SPECTRUM OF THE SAMPLED SIGNAL AND ITS COMPONENTS')
text(.5, 1.6,'|R*|')
grid
xlabel('Fig. 3.4(b)')
x = [2.5 2.5];
y = [0 .75];
subplot(212), plot(x,y)
text(2.4,1.,'w1')
[a,b,c,d] = tf2ss(num,den);
phi = expm(a);
w = -10:.1:10;
[dmag dph] = dbode(phi,b,c,d,1,w);
subplot(212), plot(w,dmag)
hold off
