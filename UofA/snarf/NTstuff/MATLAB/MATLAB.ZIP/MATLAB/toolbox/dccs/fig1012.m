%FIG1012.M          Fig. 10.12
clg
w2=60*2*pi;
w1=2*pi;
T=1/480;
t=0:T:2;
x=sin(w1*t)+.2*sin(w2*t);
axis([0 2 -1.5 1.5])
subplot(221),plot(t,x),grid
title('(a) signal + noise')
xlabel('time (sec)')
Wp=20;   %prefilter breakpoint, rad/sec
x=sin(w1*t)+.2*Wp/w2*sin(w2*t);  % assumes 1st order filter
subplot(222),plot(t,x),grid
title('(c) prefiltered (a)')
xlabel('time (sec)')
T=1/28;
t=0:T:2;
x=sin(w1*t)+.1*sin(w2*t);
subplot(223),plot(t,x,'o'),grid
title('(b) 28 Hz sampled (a)')
xlabel('time (sec)')
x=sin(w1*t)+.1*Wp/w2*sin(w2*t);
subplot(224),plot(t,x,'o'),grid
title('(d) 28 Hz sampled (c)')
xlabel('time (sec)')
hold off
axis
