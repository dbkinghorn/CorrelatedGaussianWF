function fig38
% *.m file to plot Fig. 3.8; normalized  response of ZOH.
w = 0:.1:15;
zoh = sin(w/2)./(w/2);
v = [0 15 0 2]
axis(v)
subplot(211),plot(w,abs(zoh))
hold on
a = ones(w);
foh = (sqrt(a+w.*w)).*zoh.*zoh;
subplot(211), plot(w,foh,'--')
title('MAGNITUDE RESPONSE OF ZOH AND FOH')
grid
hold off
ph = zeros(w);
ph(1:63) = -.5*w(1:63);
ph(64:126) = -.5*w(64:126) +pi;
ph(127:151) = -.5*w(127:151) + 2*pi;
v = [0 15 -4 0];
axis(v)
subplot(212), plot(w,ph)
hold on
ph1 = atan(w) - w;
subplot(212), plot(w,ph1,'--')
title('PHASE RESPONSE OF ZOH AND FOH')
xlabel('Fig.3.8                 wT')
grid
axis
shg
hold off

