% FIG526.M   Fig. 5.26
clg
w=logspace(-2,3);
l=length(w);
one=ones(l,1);
oeighty=-180*one;

% Uncompensated 
z=[120;-2];
p=[0;.0999];
ko=.0999/(120*2);
[num,den]=zp2tf(z,p,ko);
[mag,phase]=bode(num,den,w);
phase=-(phase+90)-90;
axis([-2 3 -2 2]);
subplot(211),loglog(w,mag,'-',w,one,'-'),grid 
ylabel('Magnitude')
xlabel('Frequency, nu (rad/sec)')
axis([-2 3 -270 -90]);
subplot(212),semilogx(w,phase,'-',w,oeighty,'-'),grid
ylabel('Phase (deg)')
xlabel('Frequency, nu (rad/sec)')

% Compensated 
z=[120;-2];
p=[0;6];
ko=6/(120*2);
[num,den]=zp2tf(z,p,ko);
[mag,phase]=bode(num,den,w);
phase=-(phase+90)-90;
axis([-2 3 -2 2]);
subplot(211),loglog(w,mag,'--')
axis([-2 3 -270 -90]);
subplot(212),semilogx(w,phase,'--')
hold off
