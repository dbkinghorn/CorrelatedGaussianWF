function xq = quant(x,q)
% xq = quant(x,q) is a function to give the rounded value of 
%  x to q decimal places.
if x > 0,
  xq = 10^(-q)*fix(x*10^q + .5);
else  xq = 10^(-q)*fix(x*10^q -.5);
end
