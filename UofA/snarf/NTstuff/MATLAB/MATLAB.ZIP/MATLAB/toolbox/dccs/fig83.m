% fig82.m generates the Fig 8.2 which shows the computation
% of a transfer function using a chirp input and the FFT.
% using known parts
clg
f = [-.25 -1 0 0;1 0 0 0; 0 1 0 0; 0 0 1 0];
g = [1;0;0;0];
h = [0 0 0 1];
j = 0;
[phi,gam] = c2d(f,g,.5);
[b,a] = ss2tf(phi,gam,h,j,1);
w1 = 0:pi/128:pi;
w = w1(2:128);
[mag ph] = dbode(b,a,w);
ph = ph - 360*ones(ph);
nk = [1 2 1];
dk = [1 -2 1];
[magk phk] = dbode(nk,dk,w);
u = chirp(.1,.75,256);
y = filter(b,a,u);
uf = filter(nk,1,u);
yf = filter(dk,1,y);
U = fft(u)/16;
Y = fft(y)/16;
Uf = fft(uf)/16;
Yf = fft(yf)/16;
Tf = Y(2:128)./U(2:128);
Tff = Yf(2:128)./Uf(2:128);
magch = abs(Tf);
phch1 = angle(Tf)*180/pi;
phch = fixphase(phch1); 
phch = phch - 360*ones(phch);
magf = abs(Tff);
phf = angle(Tff)*180/pi;
magchf = magf'.*magk;
phchf1 = phf' + phk;
phchf = fixphase(phchf1);
subplot(221), loglog(w,mag),hold on, loglog(w,magch,'x'),grid,title('Raw estimate')
hold off
subplot(223),semilogx(w,ph),hold on,semilogx(w,phch,'x'), grid
hold off
subplot(222),loglog(w,mag),hold on, loglog(w,magchf,'x'), grid
title('Estimate with filtering')
hold off
subplot(224),semilogx(w,ph),hold on, semilogx(w,phchf,'x') ,grid
hold off
