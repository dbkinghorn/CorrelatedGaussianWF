% fig621.m      Fig. 6.21
%   example response using OUTPUT ERROR command
%   with the reduce-order estimator,
%   Uses transfer functions
clg
f=[0 1;
0 0];
g=[0;1];
h=[1 0];
T=.1;
[phi,gam]=c2d(f,g,T);
z=eig(phi);
zol = z'
[gz,gp,kp]=ss2zp(phi,gam,h,0,1);
dz=.819;                          % D(z) zero
dp=.238;                        % D(z) pole
p=[gp;dp] % poles
z=[gz;dz]; % zeros
z(1)=inf
[nud,ded] = zp2tf(z,p,kp);  % kp = plant gain
kd=27.5;                      % kd = D(z) gain
r=rlocus(nud,ded,kd);
[nu,de] = zp2tf(z,r',kp*kd);  % c.l. y transfer function
y=dstep(nu,de,n);
zu=[dz;gp];
[nu,de] = zp2tf(zu,r',kd);  % c.l. u transfer function
u=dstep(nu,de,n);
zv=[zu;0];
pv=[r';1];
[nu,de]= zp2tf(zv,pv,kd*T)  % c.l. v transfer function
v=dstep(nu,de,n);
n=31;
t=0:T:(n-1)*T;
axis([0 3 -5 5])
plot(t,y,'o',t,v,'x'),grid
hold on
plot(t,y,'-',t,v,'-')
us=u/10;
zohplot(t',us,'-')
hold off
ylabel('OUTPUTS')
xlabel('TIME   (SEC)')
title('Fig. 6.21')
text(2.1,-3,'--o---  X1')
text(2.1,-3.5,'--x---  X2')
text(2.1,-2.5,'------  U/10')
pause
axis
