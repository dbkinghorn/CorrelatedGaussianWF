function [numw,denw] = z2w(numz,denz,T)
% [numw,denw] = z2w(numz,denz,T)
% THIS FUNCTION COMPUTES THE W-TRANSFORM OF A GIVEN DISCRETE
% SYSTEM IN TRANSFER FUNCTION FORM WITH SAMPLING PERIOD T.
% The numerator is padded with leading zeros, if neccesary,
% to make it the same length as the denominator.
[m,n] = size(numz);
numz=[zeros(m,length(denz)-n) numz];
[phi,gamma,H,J] = tf2ss(numz,denz);
[n,m] = size(phi);
I = eye(n);
r = sqrt(T);
Q = I + inv(I + phi)*(I - phi);
A = 2/T*(I - Q);
B = 1/r*Q*gamma;
C = 1/r*H*Q;
D = J - H*Q*gamma/2;
[numw,denw] = ss2tf(A,B,C,D,1);
