% fig81.m generates the Fig 8.1 which shows the computation
% of a transfer function using a chirp input and the FFT.
f = [-.25 -1 0 0;1 0 0 0; 0 1 0 0; 0 0 1 0];
clg
g = [1;0;0;0];
h = [0 0 0 1];
j = 0;
[phi,gam] = c2d(f,g,.5);
[b,a] = ss2tf(phi,gam,h,j,1);
w1 = 0:pi/128:pi;
w = w1(2:128);
[mag ph] = dbode(b,a,w);
u = chirp(.1,.75,256);
y = filter(b,a,u);
U = fft(u)/16;
Y = fft(y)/16;
Tf = Y(2:128)./U(2:128);
magch = abs(Tf);
phch1 = angle(Tf)*180/pi;
phch = fixphase(phch1);
subplot(221), plot(u),grid,title('chirp')
subplot(223),loglog(w,abs(U(2:128))), grid,title('chirp spectrum')
subplot(222), loglog(w,mag),hold on, grid, loglog(w ,magch, 'x')
title('Transfer function')
hold off
subplot(224), semilogx(w,ph),grid,hold, semilogx(w,phch,'x')
hold off
