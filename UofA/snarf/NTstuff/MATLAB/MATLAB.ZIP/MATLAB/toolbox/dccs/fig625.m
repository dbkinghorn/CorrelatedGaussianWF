% fig625.m      Fig. 6.25
%     response with integral control, full state feedback
%     with STATE COMMAND structure
clg
f=[0 1;
0 0];
g=[0;1];
h=[1 0];
T=.1;
[phi,gam]=c2d(f,g,T);
z=eig(phi);
zol = z'
phia=[1 h;[0;0] phi];
gama=[0;gam];
i=sqrt(-1);
zd2=[.8+i*.25;.8-i*.25;.9];
zd = zd2'
ka=acker(phia,gama,zd2)
k=[ka(2) ka(3)];
[Nx,Nu,Nbar]=refi(phi,gam,h,k)
gk=gam*k;
phic=[1 h ;
       -gam*ka(1) phi-gk]
z=eig(phic);
zcl = z'
n=61;
m=20;
% step command at t=0; disturbance, w, step of 5 at n
w=[zeros(m,1);5*ones(n-m,1)];
input=[ones(n,1) w];
hec= -ka        % output is  u
gnb=gam*Nbar;
B=[-1 0;gnb gam];
d=[Nbar 0];
[y,x]=dlsim(phic,B,hec,d,input);
u=y(:,1);
t=0:T:(n-1)*T;
axis([0 6 -3 3])
plot(t,ka(1)*x(:,1)/2,'+',t,x(:,2),'o',t,x(:,3),'x'),grid
hold on
plot(t,x(:,2),'-',t,x(:,3),'-')
zohplot(t',w/2,'-.')
us=u/5;
zohplot(t',us,'-')
hold off
ylabel('OUTPUTS')
xlabel('TIME   (SEC)')
title('Fig. 6.25')
text(4.1,-2.33,'--o---  X1')
text(4.1,-2.67,'--x---  X2')
text(4.1,-3,'+  +  +  KI*XI/2')
text(4.1,-2,'------  U/5')
text(4.1,-1.67,'_._._._  w/2')
pause
axis
