function readme7(n)

% The files contained on this diskette constitute the "Digital Control
% of Dynamic Systems Toolbox" and are designed for use with the "Digital
% Control of Dynamic Systems" textbook, authored by Franklin, Powell, and
% Workman, and published by Addison-Wesley.
%
% The Toolbox consists of M-files (functions) written by the textbook authors
% and referred to in the text.  In addition, the Toolbox includes scripts that
% were used to create many of the figures in the textbook.
%
% The Toolbox is a collection of functions written in the MATLAB language.  It
% requires that you have the MATLAB program to execute each function.
%
% NOTE:  These M-files are User Contributed Routines that have been contributed
% to The MathWorks and which are being redistributed by The MathWorks, upon
% request, on an "as is" basis.  A User Contributed Routine is not a Product of
% The MathWorks, Inc. and MathWorks assumes no responsibility for any errors 
% that may exist in the Toolbox.
%
% 1. Digital Control of Dynamic Systems Toolbox M-Files
% backwd	Discrete equivalent via backward rectangular rule
% bertram	Bertram worst case bound for quantization errors
% bilinr	Bilinear tranformation
% c2dd		Continuous to discrete tranformation with delay on control
% c2dzp		Zero-Pole form of c2d
% chirp		Chirp from discrete radian frequency
% dclqr		Discrete feedback LQR gain from continuous cost
% disrw		Discrete equivalent of continuous noise
% dzfr		Discrete z-plane frequency response
% fig21.m-fig600.m	Generate figures in the textbook
% forwd		Discrete equivalent via forward rectangular rule
% jdequiv	Discrete equivalent of continuous cost
% jury		Jury's polynomial stability test
% output	Intersample output and control
% quant		Round to q decimal places
% refi		Compute reference command input matrices
% trieq		Triangle hold discrete equivalent
% widrow	RMS error due to round-off error
% z2w		W-transform of a discrete system
% zlocus	Z-plane root-locus
% zoheq		C2D, except C and D are returned too.
% zohplot	ZOH plot
% zpeq		Discrete equivalent via pole-zero mapping

%
% Use HELP on these files, or TYPE them for more information.
disp('Digital Control of Dynamic Systems Toolbox Version 1.00  11-Dec-1989')
if ~nargin
	disp('Press any key to see readme file'),pause
	clc, help readme7
end
