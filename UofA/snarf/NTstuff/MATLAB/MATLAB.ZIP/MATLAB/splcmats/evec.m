function v = evec(i,n)
% EVEC	evec(i,n) Returns the ith column of the nxn indentity matrix
In = eye(n);
v = In(:,i);
