
README.TXT file for MATLAB(R) Version 4.0 and SIMULINK(TM) Version 1.2c 
for Microsoft Windows
(C) Copyright 1993, The MathWorks, Inc.


The following features, bugs, and documentation errors in MATLAB 4.0 for 
Microsoft Windows were discovered after the paper documentation went to 
press.
========================================================================
1.  Typo in External Interface Guide regarding Watcom C/386 Compiler.
2.  GPF with ATI Graphics Ultra card and Mach 32 driver.
3.  Setting the Pointer property from an M-file.
4.  SelectionType improperly documented.
5.  exp(Inf) returns NaN, not Inf.
6.  Some demos don't clear the figure before starting.
7.  Mask indexing doesn't work on sparse matrices.
8.  How to change the ticks on logarithmic axes.
9.  Special keys lost when typing ahead.
10. Printing may crash MATLAB when under Norton Desktop.
11. Graphics may be off one or two pixels.
12. Displaying the value 7 as a character does not beep the beeper.
13. MATLAB's prompt is not captured in diary files.
14. Command window occasionally jumps back while scrolling.
15. Changing dots-per-inch when printing may fail.
16. WATCOM C/386 compiler does not support NaN correctly.
17. fopen defaults to binary, not ASCII.
18. No movie, getframe, or interpolated shading on 16-color machines.
19. One point at which MATLAB doesn't yield to Background Processing.
20. Re-starting a demo after an interruption may fail.
21. Denormalized numbers display incorrectly.

========================================================================
1. Typo in External Interface Guide regarding WATCOM C/386 Compiler.

Page 1-33, External Interface Guide, lines 7-11 should be replaced with

To use the WATCOM C/386 Compiler, make sure that your PATH and INCLUDE 
environment variables are set as described in the _WATCOM_ 
_C/386_User's_Guide_.  In addition, you will need to set your WATCOM 
environment variable as follows:

SET WATCOM=<watcom>;<watcom>\LIB386;<watcom>\LIB386\DOS

Then type (all on one line):

WCL386 -p -3s -7 -l=dos4g -I<matlab>\EXTERN\INCLUDE MATTEST1.C
     <matlab>\EXTERN\LIB\LIBMATWC.LIB

Remember to replace <watcom> and <matlab> with the actual path 
specifiers for your WATCOM and MATLAB root directories.
----------
2. GPF with ATI Graphics Ultra card and Mach 32 driver.
 
Running MATLAB graphics on a machine with the ATI Graphics Ultra 
accelerator card and the Mach 32 driver may cause General Protection 
Faults, especially at 'movie' or 'getframe' commands.  We suggest that 
users use the 8514/a driver instead of the Mach 32.  We have contacted 
ATI and are working with them to solve the problem.
----------
3. Setting the Pointer property from an M-file.

If an M-file sets the figure property Pointer, this change will not take 
effect unless followed by a 'pause' command with no arguments.  Setting 
the Pointer property from the command line works.
----------
4. SelectionType improperly documented.

A figure property called SelectionType exists and is documented in the 
Reference Guide.  The documentation is correct for UNIX but wrong for 
Windows.

SelectionType 'open' is not supported.  Pressing the left button returns 
'normal'.  Pressing the right button or control-left button returns 
'extend'.  Pressing the middle button (or both buttons of a two-button 
mouse) or shift-left button returns 'alt'.
----------
5. exp(Inf) returns NaN, not Inf.

exp(Inf) returns NaN instead of Inf.  This causes a similar error in 
functions which call exp.  For example, sinh(Inf) and cosh(Inf) return 
NaN instead of Inf.
----------
6. Some demos don't clear the figure before starting.

Some of the demos don't clear the current figure before they 
start up.  For best results, clear the current figure (by typing 'clf 
reset') before typing 'demo' at the command line.
----------
7. Mask indexing doesn't work on sparse matrices.

Mask indexing (using indices that are all zeros and ones to select only 
certain elements of a matrix) does not work for sparse matrices.  For 
example, if A is a full 3x3 matrix, then A([1 0 0],:) returns the first 
row of A.  If S is a sparse 3x3 matrix, then S([1 0 0],:) generates an 
error.
----------
8. How to change the ticks on logarithmic axes.

The default axis label for a logarithmic axis is simply "ten to the N" 
for some integer n.  If you change a logarithmic axis's Tick property to 
include non-powers of ten, then you must also specify that axis's Label 
property.
----------
9. Special keys lost when typing ahead.

You may type ahead while MATLAB is busy processing.  Arrow keys and 
control characters may be lost, however.
----------
10. Printing may crash MATLAB when under Norton Desktop.

We have observed intermittent failures with print commands when running 
MATLAB under Norton Desktop.  We're still isolating the specific 
problems and will keep you informed of any new discoveries.
----------
11. Graphics may be off one or two pixels.

If you set the Units property of a figure or an axes to 'pixels', you 
may see slight inaccuracies (one or two pixels) in the resulting display 
of some objects.  For example, an image will be one or two pixels 
smaller in both dimensions than expected if its parent axes is expressed 
in pixels.
----------
12. Displaying the value 7 as a character does not beep the beeper.
For example, if you type 'setstr(7)' at the command line, MATLAB won't 
beep the beeper.
----------
13. MATLAB's prompt is not captured in diary files.
----------
14. Command window occasionally jumps back while scrolling.

If you display a large amount of text to the command window, it may 
occasionally jump to the top of the buffer while scrolling.
----------
15. Changing dots-per-inch when printing may fail.

Some print drivers allow you to specify resolution in dots per inch.  
Changing the value from its default may cause the plot to not print or 
print incorrectly.
----------
16. WATCOM C/386 compiler does not support NaN correctly.

User-written MEX files that are compiled with the WATCOM compiler may 
handle NaN incorrectly.  Since this version of MATLAB was written with 
the WATCOM C/386 compiler, we have attempted to work around the NaN 
problems, but a few bugs still remain:  Any NaNs in sparse matrices 
loaded from .mat files will turn into zeros or denormalized numbers.  
Attempting to set an element of a sparse matrix to NaN from the command 
line will actually set it to zero.  Functions on sparse matrices will 
usually return zeros in place of NaN but are unpredictable.  

We have contacted WATCOM with regard to these problems and do not know 
when they will be fixed.  Users are advised to take care to check their 
inputs with the �isnan� and/or �finite� functions if they want to 
guarantee proper handling of NaNs.
----------
17. fopen defaults to binary, not ASCII.

MATLAB is one of the few applications that will open a file as binary by 
default.  This represents a change from MATLAB 3.5.  Please see HELP 
FOPEN.
----------
18. No movie, getframe, or interpolated shading on 16-color machines.

The movie and getframe commands are unavailable on 16-color machines.  
Interpolated shading does not work on 16-color machines.  Objects will 
come up some solid color, usually black, instead.
----------
19. One point at which MATLAB doesn't yield to Background Processing.

The "Background Processing Enabled" mode will allow you to work in other 
windows while MATLAB is processing.  Once a figure window begins drawing 
a plot, however, it may not yield to other processes until it is done.
----------
20. Re-starting a demo after an interruption may fail.

The 'demo' command depends on some global variables to keep track of 
where it is.  Aborting out of a demo sequence and then typing 'demo' 
again will result in unpredictable behavior unless you typed 'clear 
global' before starting the second demo.
----------
21. Denormalized numbers display incorrectly.

Denormalized numbers (numbers with absolute value less than about 
1e-308) will not display correctly when  format short  or  
format short e  is in effect.

========================================================================

MATLAB is a registered trademark, and SIMULINK is a trademark of The 
MathWorks, Inc.

Microsoft is a registered trademark, and Windows is a trademark of 
Microsoft Corporation.

ATI and Graphics Ultra are trademarks of ATI Technologies Inc.

Norton Desktop is a trademark of Symantec Corporation.



