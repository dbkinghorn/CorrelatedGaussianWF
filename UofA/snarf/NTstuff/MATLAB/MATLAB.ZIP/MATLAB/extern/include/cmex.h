/*
 * CMEX.H	- Include file for C-language MEX-files built under MATLAB
 *		  3.5 or earlier. 
 *
 * By:		Martin Knapp-Cordes
 * Date:	Feb 92 - 24
 *		Dec 92 - 23
 *
 * Copyright (c) 1992 The MathWorks, Inc.
 * All rights Reserved
 *
 * Note(s):	1. This file allows a user to compile without change
 *		   MEX files built to run under earlier versions of MATLAB
 *		   
 */

#ifndef cmex_h
#define cmex_h

#ifdef OLDSTYLE

#define malloc(N)       mex_calloc(N,1)
#define calloc(N,S)     mex_calloc(N,S)
#define free(P)         mex_free(P)

#endif

#include "mex.h"

#endif /* cmex_h */
