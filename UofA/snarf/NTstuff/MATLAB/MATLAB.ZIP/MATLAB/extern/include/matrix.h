#ifdef DLLMEX
#include "dllmatrx.h"
#else 
#include "mx3matrx.h"
#endif
