/*
 *	MATTEST4
 *
 *	Simple program that illustrates how to call the MAT-file Library
 *	from a C program.  
 *
 *	The example reads the Matrix "A" from one MAT-file and writes it 
 *	out to another.
 *	
 */
#include <stdlib.h>
#include "mat.h"

main()
{
	MATFile *fp1, *fp2;
	int m, n;
	double *pr, *pi;

	fp1 = matOpen("foo.mat", "r");
	fp2 = matOpen("foo1.mat", "w");
	matGetFull(fp1, "A", &m, &n, &pr, &pi);
	matPutFull(fp2, "A", m, n, pr, pi);
	matClose(fp1);
	matClose(fp2);
	exit(0);
}
