/*
 *	MATTEST1
 *
 *	Simple program that illustrates how to call the MAT-file Library
 *	from a C program.  
 *
 *	The example writes a simple 3-by-2 real matrix into a MAT-file.
 *	The matrix is named, "A", and the MAT-file is named, "foo.mat".
 *	
 */
#include <stdlib.h>
#include <string.h>
#include "mat.h"

static double Areal[6] = { 1, 2, 3, 4, 5, 6 };

main()
{
	MATFile *fp;
	Matrix *a;

	fp = matOpen("foo.mat", "w");
	a = mxCreateFull(3, 2, REAL);
    memcpy(mxGetPr(a), Areal, 6*sizeof(double));
	mxSetName(a, "A");
	matPutMatrix(fp, a);
	matClose(fp);
	mxFreeMatrix(a);
	exit(0);
}
