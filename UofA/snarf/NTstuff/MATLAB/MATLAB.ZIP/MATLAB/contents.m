% Establish MATLAB session parameters.
%
%   matlabrc  - Master startup M-file.
%   printopt  - Set up printing options.
